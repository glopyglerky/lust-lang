/workspace/scratch/92a35dfe3ee0/native-upstream-corpus-full/cases/pass/core_destructuring_assign_order/native/core_destructuring_assign_order: /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/bin/tcc /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/bcheck.o /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/bcheck_run.o /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/bt-exe.o /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/bt-log.o /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/float.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdalign.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdarg.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdatomic.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdbool.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stddef.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdnoreturn.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/tccdefs.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/tcclib.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/tgmath.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/varargs.h /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/libtcc1.a /workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/runmain.o /workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/env.rs /workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/ffi.rs /workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/fs.rs /workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/io.rs /workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/os.rs /workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/path.rs /workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/platform.rs /workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/process_os.rs /workspace/scratch/92a35dfe3ee0/lustr/compiler/native/tests/pass/core_destructuring_assign_order.rs /workspace/scratch/92a35dfe3ee0/native-upstream-corpus-full/compilers/native/bin/lustr-native

/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/bin/tcc:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/bcheck.o:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/bcheck_run.o:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/bt-exe.o:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/bt-log.o:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/float.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdalign.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdarg.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdatomic.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdbool.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stddef.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/stdnoreturn.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/tccdefs.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/tcclib.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/tgmath.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/include/varargs.h:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/libtcc1.a:
/workspace/scratch/0fa08655b84f/lustr-package-work/build/compiler/native/third_party/tcc/lib/tcc/runmain.o:
/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/env.rs:
/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/ffi.rs:
/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/fs.rs:
/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/io.rs:
/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/os.rs:
/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/path.rs:
/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/platform.rs:
/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/library/std/src/process_os.rs:
/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/tests/pass/core_destructuring_assign_order.rs:
/workspace/scratch/92a35dfe3ee0/native-upstream-corpus-full/compilers/native/bin/lustr-native:
# env-dep:LUST_ASM_PARTS
# env-dep:LUST_B1
# env-dep:LUST_B1_OBSERVE
# env-dep:LUST_B3_OBSERVE
# env-dep:LUST_B3_READS
# env-dep:LUST_BCK_DEBUG
# env-dep:LUST_BODY
# env-dep:LUST_BS_TEST_ENV
# env-dep:LUST_BS_TEST_LOG
# env-dep:LUST_BS_TEST_LOG2
# env-dep:LUST_BUILD_HASH
# env-dep:LUST_CACHE_COMPILER_ID
# env-dep:LUST_CACHE_DIR=/workspace/scratch/92a35dfe3ee0/native-upstream-corpus-full/cases/pass/core_destructuring_assign_order/sandbox/cache
# env-dep:LUST_CACHE_MAX_BYTES
# env-dep:LUST_CC
# env-dep:LUST_CC_STREAM
# env-dep:LUST_CC_STREAM_EARLY
# env-dep:LUST_CC_STREAM_JOBS
# env-dep:LUST_CHECK_B1
# env-dep:LUST_CHECK_EXPKEY
# env-dep:LUST_CHECK_FPMEMO
# env-dep:LUST_CHECK_GENREUSE
# env-dep:LUST_CHECK_GLOB_SKIP
# env-dep:LUST_CHECK_ITEMPATCH
# env-dep:LUST_CHECK_PARDISC
# env-dep:LUST_CHECK_PREJUDGE
# env-dep:LUST_CHECK_READS
# env-dep:LUST_CHECK_RESOLVE
# env-dep:LUST_CHECK_UNIT_FP
# env-dep:LUST_CXX
# env-dep:LUST_DAEMON_HANG
# env-dep:LUST_DAEMON_IDLE
# env-dep:LUST_DAEMON_LOCK_FD
# env-dep:LUST_DAEMON_PREWARM
# env-dep:LUST_DAEMON_PREWARM_AFTER
# env-dep:LUST_DAEMON_SESSIONS
# env-dep:LUST_DAEMON_SOCKET
# env-dep:LUST_DEBUG_PAT
# env-dep:LUST_DEPS_TEST_UNSET
# env-dep:LUST_DERIVE_CENSUS
# env-dep:LUST_DERIVE_KEYLOG
# env-dep:LUST_DERIVE_LOG
# env-dep:LUST_DROPFLAGS
# env-dep:LUST_EXPAND_DEBUG
# env-dep:LUST_EXPAND_STATS
# env-dep:LUST_FLAG_PREC
# env-dep:LUST_FLAG_WIDTH
# env-dep:LUST_FRONT_
# env-dep:LUST_FRONT_ARENA
# env-dep:LUST_FRONT_CENSUS
# env-dep:LUST_FRONT_COMPACT
# env-dep:LUST_FRONT_COMPACT_RATIO
# env-dep:LUST_FRONT_LOCK_FD
# env-dep:LUST_FRONT_READERS
# env-dep:LUST_FRONT_RESTORE
# env-dep:LUST_FRONT_SAVE
# env-dep:LUST_FRONT_SAVE_EARLY
# env-dep:LUST_FRONT_SAVE_IDLE
# env-dep:LUST_FRONT_STATE
# env-dep:LUST_FRONT_STATE_VERBOSE
# env-dep:LUST_FRONT_TAKEOVER
# env-dep:LUST_FRONT_TOUCHED
# env-dep:LUST_FRONT_WAIT_PID
# env-dep:LUST_FRONT_ZSTD
# env-dep:LUST_FRONT_ZSTD_LEVEL
# env-dep:LUST_GUARD_HOLD_MS
# env-dep:LUST_IMPL
# env-dep:LUST_ITEMPATCH_LOG
# env-dep:LUST_KDATA
# env-dep:LUST_LIBRARY
# env-dep:LUST_LINK_PREFETCH
# env-dep:LUST_LL_
# env-dep:LUST_LL_ADAPT
# env-dep:LUST_LL_BITS
# env-dep:LUST_LL_COPY
# env-dep:LUST_LL_COPY_MIN
# env-dep:LUST_LL_FACTS
# env-dep:LUST_LL_FLAGMEM
# env-dep:LUST_LL_HUGE
# env-dep:LUST_LL_INLINE
# env-dep:LUST_LL_INLINE_DEPTH
# env-dep:LUST_LL_INLINE_HINT
# env-dep:LUST_LL_INLINE_PATH
# env-dep:LUST_LL_INLINE_TINY
# env-dep:LUST_LL_INLINE_TINY_DEPTH
# env-dep:LUST_LL_NATIVE
# env-dep:LUST_LL_OPT
# env-dep:LUST_LL_PAIR
# env-dep:LUST_LL_RTINL
# env-dep:LUST_NO_CACHE=1
# env-dep:LUST_NO_DAEMON=1
# env-dep:LUST_NO_PARDISC
# env-dep:LUST_ORDER_FUZZ
# env-dep:LUST_PARDISC_STATS
# env-dep:LUST_PGO_BITS
# env-dep:LUST_PGO_CC
# env-dep:LUST_PGO_CGPROFILE
# env-dep:LUST_PGO_COPIES
# env-dep:LUST_PGO_COPY_MIN
# env-dep:LUST_PGO_GEN
# env-dep:LUST_PGO_PREINLINE
# env-dep:LUST_PGO_USE
# env-dep:LUST_PROBE_FAKE_DIR
# env-dep:LUST_PROFDATA
# env-dep:LUST_PROGRAM_DIGEST
# env-dep:LUST_READCOVER_BT
# env-dep:LUST_READCOVER_LOG
# env-dep:LUST_RELEASE_
# env-dep:LUST_RELEASE_AGG_PARAM
# env-dep:LUST_RELEASE_AGG_RET
# env-dep:LUST_RELEASE_ALLOC
# env-dep:LUST_RELEASE_BACKEND
# env-dep:LUST_RELEASE_BLOCKS
# env-dep:LUST_RELEASE_C
# env-dep:LUST_RELEASE_FRAME_INLINE
# env-dep:LUST_RELEASE_INLINE
# env-dep:LUST_RELEASE_INLINE_GLUE_KB
# env-dep:LUST_RELEASE_INPLACE
# env-dep:LUST_RELEASE_LDFLAGS
# env-dep:LUST_RELEASE_MEM
# env-dep:LUST_RELEASE_SHARD_KB
# env-dep:LUST_RELEASE_STATICS_KB
# env-dep:LUST_RELEASE_UNIT_CAP_KB
# env-dep:LUST_RELEASE_UNIT_KB
# env-dep:LUST_RELEASE_UNREACHABLE
# env-dep:LUST_RESOLVE_LOG
# env-dep:LUST_SIGDELTA_CENSUS
# env-dep:LUST_SIGDELTA_LOG
# env-dep:LUST_SIGDELTA_SELFTEST
# env-dep:LUST_SOURCES_READY
# env-dep:LUST_STATS
# env-dep:LUST_STD_SRC
# env-dep:LUST_TCC_BIN
# env-dep:LUST_TCC_HOME
# env-dep:LUST_TCC_LIB_PATH
# env-dep:LUST_THREADS
# env-dep:LUST_TYPE_POOL
# env-dep:LUST_UNW
# env-dep:LUST_UNWIND_TABLES
# env-dep:LUST_UNW_ABORT
# env-dep:LUST_VISITS_LOG
