typedef signed char int8_t; typedef unsigned char uint8_t; typedef short int16_t; typedef unsigned short uint16_t;
typedef int int32_t; typedef unsigned int uint32_t;
#ifdef __INT64_TYPE__
typedef __INT64_TYPE__ int64_t; typedef unsigned __INT64_TYPE__ uint64_t;
#else
typedef long long int64_t; typedef unsigned long long uint64_t;
#endif
#ifdef __SIZE_TYPE__
typedef __SIZE_TYPE__ size_t; typedef __PTRDIFF_TYPE__ ptrdiff_t; typedef __UINTPTR_TYPE__ uintptr_t; typedef __INTPTR_TYPE__ intptr_t;
#else
typedef unsigned long size_t; typedef long ptrdiff_t; typedef unsigned long uintptr_t; typedef long intptr_t;
#endif
#define INT64_MIN (-9223372036854775807LL-1)
#ifndef NULL
#define NULL ((void*)0)
#endif
extern const char *lust_file;
extern const uint32_t *lust_fn_line;
extern const char *const *lust_files;
extern const uint32_t *lust_slot_file;
static const uint32_t lines[18] = {17,8,3,1,5,15,6,16,7,14,19,11,4,13,12,2,10,9};
void lust_loc_init(void) {
  lust_file = "/tmp/lustr-small-units-before/unsafe_many_16/main.rs";
  lust_fn_line = lines;
  lust_files = 0;
  lust_slot_file = 0;
}
const uint64_t lust_so_tab[18] __attribute__((aligned(8))) = {0ull,1099511627776ull,2199023255552ull,3298534883328ull,4398046511104ull,5497558138880ull,6597069766656ull,7696581394432ull,8796093022208ull,9895604649984ull,10995116277760ull,12094627905536ull,13194139533312ull,14293651161088ull,15393162788864ull,16492674416640ull,17592186044416ull,18691697672192ull};
__asm__(
".globl lust_so_028669240540c67a\n.set lust_so_028669240540c67a, lust_so_tab+0\n"
".globl lust_so_09d65e2e646ed4d3\n.set lust_so_09d65e2e646ed4d3, lust_so_tab+8\n"
".globl lust_so_169c6bf7e084b9e9\n.set lust_so_169c6bf7e084b9e9, lust_so_tab+16\n"
".globl lust_so_1a322d278a09c169\n.set lust_so_1a322d278a09c169, lust_so_tab+24\n"
".globl lust_so_39fb8355417e8d2f\n.set lust_so_39fb8355417e8d2f, lust_so_tab+32\n"
".globl lust_so_3d025fcc67239260\n.set lust_so_3d025fcc67239260, lust_so_tab+40\n"
".globl lust_so_424fa8dbb2fc1198\n.set lust_so_424fa8dbb2fc1198, lust_so_tab+48\n"
".globl lust_so_4a4d16801543abe3\n.set lust_so_4a4d16801543abe3, lust_so_tab+56\n"
".globl lust_so_4cf6ccee27f82116\n.set lust_so_4cf6ccee27f82116, lust_so_tab+64\n"
".globl lust_so_5a0a3ea6192e4b6c\n.set lust_so_5a0a3ea6192e4b6c, lust_so_tab+72\n"
".globl lust_so_5b26132ea5f68786\n.set lust_so_5b26132ea5f68786, lust_so_tab+80\n"
".globl lust_so_5fe9c9200906faa8\n.set lust_so_5fe9c9200906faa8, lust_so_tab+88\n"
".globl lust_so_6f8351f0d1876c83\n.set lust_so_6f8351f0d1876c83, lust_so_tab+96\n"
".globl lust_so_7ac86b8bf5e3e5e1\n.set lust_so_7ac86b8bf5e3e5e1, lust_so_tab+104\n"
".globl lust_so_950c5ea338cc59dd\n.set lust_so_950c5ea338cc59dd, lust_so_tab+112\n"
".globl lust_so_deebb244ae283b29\n.set lust_so_deebb244ae283b29, lust_so_tab+120\n"
".globl lust_so_fa7847595ca32ce4\n.set lust_so_fa7847595ca32ce4, lust_so_tab+128\n"
".globl lust_so_fe8a87589a62b904\n.set lust_so_fe8a87589a62b904, lust_so_tab+136\n"
);
