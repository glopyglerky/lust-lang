 
typedef signed char int8_t; typedef unsigned char uint8_t; typedef short int16_t; typedef unsigned short uint16_t;
typedef int int32_t; typedef unsigned int uint32_t;
#ifdef __INT64_TYPE__
typedef __INT64_TYPE__ int64_t; typedef unsigned __INT64_TYPE__ uint64_t;
#else
typedef long long int64_t; typedef unsigned long long uint64_t;
#endif
#ifdef __SIZE_TYPE__
typedef __SIZE_TYPE__ size_t; typedef __PTRDIFF_TYPE__ ptrdiff_t; typedef __UINTPTR_TYPE__ uintptr_t; typedef __INTPTR_TYPE__ intptr_t;
#else
typedef unsigned long size_t; typedef long ptrdiff_t; typedef unsigned long uintptr_t; typedef long intptr_t;
#endif
#define INT64_MIN (-9223372036854775807LL-1)
#ifndef NULL
#define NULL ((void*)0)
#endif
void free(void *);
void abort(void);
void *memset(void *, int, size_t);
void *memcpy(void *, const void *, size_t);
#define LUST_BODY(...) ;

 
#ifdef __TINYC__
#define lust_black_box(p) ((void)(p))
#else
#define lust_black_box(p) __asm__ __volatile__("" : : "r"(p) : "memory")
#endif

 
#ifdef __TINYC__
#define lust_copy_small(d, s, n) lust_memmove((d), (s), (n))
#else
static inline __attribute__((always_inline)) void lust_copy_small(void *d, const void *s, uint64_t n) {
    unsigned char *dp = (unsigned char *)d;
    const unsigned char *sp = (const unsigned char *)s;
    if (__builtin_expect(n > 32, 0)) {
        __builtin_memmove(d, s, (size_t)n);
    } else if (n > 16) {
        uint64_t a, b, c, e;
        __builtin_memcpy(&a, sp, 8);
        __builtin_memcpy(&b, sp + 8, 8);
        __builtin_memcpy(&c, sp + n - 16, 8);
        __builtin_memcpy(&e, sp + n - 8, 8);
        __builtin_memcpy(dp, &a, 8);
        __builtin_memcpy(dp + 8, &b, 8);
        __builtin_memcpy(dp + n - 16, &c, 8);
        __builtin_memcpy(dp + n - 8, &e, 8);
    } else if (n >= 8) {
        uint64_t a, e;
        __builtin_memcpy(&a, sp, 8);
        __builtin_memcpy(&e, sp + n - 8, 8);
        __builtin_memcpy(dp, &a, 8);
        __builtin_memcpy(dp + n - 8, &e, 8);
    } else if (n >= 4) {
        uint32_t a, e;
        __builtin_memcpy(&a, sp, 4);
        __builtin_memcpy(&e, sp + n - 4, 4);
        __builtin_memcpy(dp, &a, 4);
        __builtin_memcpy(dp + n - 4, &e, 4);
    } else if (n) {
        unsigned char a = sp[0], b = sp[n >> 1], c = sp[n - 1];
        dp[0] = a;
        dp[n >> 1] = b;
        dp[n - 1] = c;
    }
}
#endif

 
#ifdef __TINYC__
#define lust_vec_fits(n, elem) ((uint64_t)(n) <= 9223372036854775807ull / (uint64_t)(elem))
#else
static inline __attribute__((always_inline)) int lust_vec_fits(uint64_t n, uint64_t elem) {
    uint64_t bytes;
    if (__builtin_constant_p(elem)) return n <= 9223372036854775807ull / elem;
    return !__builtin_mul_overflow(n, elem, &bytes) && bytes <= 9223372036854775807ull;
}
#endif



 
typedef struct { _Alignas(16) uint64_t lo; uint64_t hi; } lust_u128;
typedef struct { _Alignas(16) uint64_t lo; uint64_t hi; } lust_i128;

 
typedef struct { } lust_Unit;
_Static_assert(sizeof(lust_Unit) == 0 && _Alignof(lust_Unit) == 1, "unit layout");

typedef struct { uint8_t *ptr; uint64_t len; } lust_str;
typedef struct { uint8_t *ptr; uint64_t len; uint64_t cap; } lust_String;
typedef struct { void *ptr; uint64_t len; uint64_t cap; } lust_Vec;
 
typedef struct { void *ptr; uint64_t len; uint64_t cap; uint64_t front; } lust_VecIter;
 
typedef struct { void *vec; uint64_t start; uint64_t front; uint64_t back; uint64_t tail_start; uint64_t tail_len; } lust_VecDrain;
 
typedef struct { void *data; const void *const *vt; } lust_dyn;

 
extern int lust_argc;
extern char **lust_argv;
extern const char *lust_file;

 
typedef void (*lust_fnptr)(void);
extern lust_fnptr lust_fns[];
 
extern lust_fnptr lust_tramps[];
 
extern int (*lust_main_entry_p)(void);
void lust_base_init(void);
 
int32_t lust_unw_try(void (*f)(void *), void *ctx);
int32_t lust_unw_main_caught(void);
void lust_unw_dtry(void (*f)(void *), void *arg, void **ux);
void lust_unw_reraise(void *ux);

 
typedef uint64_t lust_loc;
 
#define LUST_SO(x) (*(const volatile uint64_t *)&(x))
 
extern const uint64_t lust_so_none;
extern const uint32_t *lust_fn_line;
 
#define LUST_TLS_FAST 512

 
void *aligned_alloc(size_t alignment, size_t size);
int posix_memalign(void **memptr, size_t alignment, size_t size);

 
int32_t lust_bt_style(void) ;

 
void lust_bt_tail(int32_t style, int32_t off_note) ;

 
void lust_oom(void) ;

 
void lust_panic_std(const char *msg, const char *where);  
void lust_panic_std_lit(const char *msg, const char *where);
void lust_vec_capacity_overflow(void) ;

 
void lust_oom_size(uint64_t n) ;

 
void *lust_alloc(uint64_t size, uint64_t align) ;

 
void *lust_alloc_zeroed(uint64_t size, uint64_t align) ;

 
int32_t lust_is_zeroed(const void *p, uint64_t n) ;

void lust_dealloc(void *ptr, uint64_t size, uint64_t align) ;

 
#define lust_rc_free(ptr, align) lust_dealloc((void *)(ptr), 1, (align))

 
void *lust_realloc(void *ptr, uint64_t old_size, uint64_t align, uint64_t new_size) ;

 
void lust_memcpy(void *dst, const void *src, uint64_t n) ;
void lust_memmove(void *dst, const void *src, uint64_t n) ;
void lust_memset(void *dst, uint32_t byte, uint64_t n) ;
int32_t lust_memcmp(const void *a, const void *b, uint64_t n) ;
void lust_ptr_read(void *dst, const void *src, uint64_t size) ;
void lust_ptr_write(void *dst, const void *src, uint64_t size) ;
void *lust_ptr_offset(void *ptr, uint64_t offset) ;

 

 
lust_String lust_string_new(void) ;

 
void lust_string_reserve(lust_String *s, uint64_t extra) ;

void lust_string_reserve_exact(lust_String *s, uint64_t extra) ;

lust_String lust_string_with_capacity(uint64_t n) ;

void lust_string_push_bytes(lust_String *s, const void *p, uint64_t n) ;

void lust_string_push_str(lust_String *s, lust_str x) ;

void lust_string_push_cstr(lust_String *s, const char *c) ;

void lust_string_push_char(lust_String *s, uint32_t c) ;

lust_String lust_string_from(lust_str x) ;

lust_str lust_string_as_str(lust_String *s) ;
lust_String lust_string_clone(lust_String *s) ;
void lust_string_drop(lust_String *s) ;

int lust_str_cmp(lust_str a, lust_str b) ;
uint8_t lust_str_eq(lust_str a, lust_str b) ;

 


 
typedef struct {
    uint32_t kind;  
    lust_str s;     
    lust_dyn box;   
} lust_exc;
#define LUST_EXC_STR 0u
#define LUST_EXC_STRING 1u
#define LUST_EXC_BOX 2u
extern int32_t lust_unwind_mode;
extern int32_t lust_unw_pending;
 
#define LUST_UNW(b) if (lust_unw_pending && lust_unw_take(&ex)) goto bb##b
#define LUST_UNW_ABORT() if (lust_unw_pending && lust_unw_mine()) lust_unw_cleanup_abort()

 
int32_t lust_unw_take(lust_exc *ex) ;

 
void lust_unw_resume(lust_exc *ex) ;

 
uint8_t lust_unw_panicking(void) ;

 
int32_t lust_unw_mine(void) ;

 
void lust_unw_cleanup_abort(void) ;

 
void lust_unw_dstep(lust_exc *ex, int32_t *u) ;


 
void lust_unw_init(int32_t unwind, uint64_t str_lo, uint64_t str_hi, uint64_t string_lo, uint64_t string_hi) ;


 
void lust_hook_swap(void *v, uint64_t n) ;

 
void *lust_hook_slot(void) ;

 
void lust_hook_set_runner(lust_fnptr f) ;

 
lust_dyn lust_hook_payload(void) ;
void *lust_hook_location(void) ;

 
void lust_hook_custom(uint8_t on) ;

 
void lust_hook_default(lust_str file, uint32_t line, uint32_t col, lust_str msg) ;

 
lust_dyn lust_unw_catch(void) ;

 
struct lust_dguard { void (*drop)(void *); void *p; int32_t armed; };
void lust_dguard_end(struct lust_dguard *g) ;
 
struct lust_retain_guard { lust_Vec *v; uint64_t *r; uint64_t *w; uint64_t es; int32_t armed; };
void lust_retain_guard_end(struct lust_retain_guard *g) ;

 
int32_t lust_unw_main_caught(void) ;

 
void lust_unw_resume_box(lust_dyn b) ;

 
int32_t lust_unw_main_exit(void) ;

 
void lust_panic_at(const uint8_t *msg, uint64_t len, const char *file, uint32_t line, uint32_t col) ;

 
#define LUST_STD_SLOT 0xFFFF00u
#define LUST_STD_POW 0x40u

 
extern const char *const *lust_files;
extern const uint32_t *lust_slot_file;


 
void lust_panic(lust_String *msg, lust_loc loc) ;

 
void lust_panic_lit(lust_String *msg, lust_loc loc) ;

 
void lust_panic_begin(lust_loc loc) ;

void lust_panic_fmt(lust_String *msg, lust_loc loc) ;

 
void lust_panic_dyn(lust_String *msg, lust_loc loc) ;

void lust_panic_cstr_dyn(const char *msg, lust_loc loc) ;

void lust_panic_str(lust_str msg, lust_loc loc) ;

 
void lust_panic_cstr(const char *msg, lust_loc loc) ;

 
void lust_panic_cstr_owned(const char *msg, lust_loc loc) ;

 
void lust_ovf(const char *op, lust_loc loc) ;

 

 
void lust_panic_std(const char *msg, const char *where) ;

 
void lust_panic_std_lit(const char *msg, const char *where) ;

 
void lust_panic_read_buf_overrun(void) ;

 
void lust_panic_box(lust_dyn b, lust_loc loc) ;

 
void lust_loc_where(lust_loc loc, const char **file, uint32_t *line) ;

 

 
void lust_print_out(const uint8_t *p, uint64_t n) ;

 
void lust_print_flush(void) ;

 
int32_t lust_stdout_write_soft(const uint8_t *p, uint64_t n) ;
int32_t lust_stdout_flush_soft(void) ;

 

 
void lust_rt_init(void) ;

 
void lust_print_failed(int to_stderr, lust_String *s) ;
 

 
void *lust_tls_cell(uint64_t *key, uint64_t size, uint64_t align);
 
void lust_tls_register(void *cell, void (*dtor)(void *));
 
void lust_tls_exit(void);


void *lust_tls_cell(uint64_t *key, uint64_t size, uint64_t align) ;

void lust_tls_register(void *cell, void (*dtor)(void *)) ;

void lust_tls_exit(void) ;
 

const void *lust_kintern(const void **cache, const void *p, uint64_t n, uint64_t align, const uint64_t *desc);
void lust_kreg(const void *p, uint64_t n, uint64_t align, const uint64_t *desc);
void lust_kreg_h(const void *p, uint64_t n, uint64_t align, uint64_t kind, uint64_t hash);


 
const void *lust_kintern(const void **cache, const void *p, uint64_t n, uint64_t align, const uint64_t *desc) ;

 
void lust_kreg(const void *p, uint64_t n, uint64_t align, const uint64_t *desc) ;

 
void lust_kreg_h(const void *p, uint64_t n, uint64_t align, uint64_t kind, uint64_t hash) ;
 

void lust_fmt_u64(lust_String *out, uint64_t v) ;

void lust_fmt_i64(lust_String *out, int64_t v) ;

void lust_fmt_bool(lust_String *out, uint8_t v) ;


 
void lust_fmt_fnptr_debug(lust_String *out, const void *p) ;

void lust_fmt_escape(lust_String *out, uint32_t c, uint32_t quote) ;

 
uint32_t lust_utf8_next(const uint8_t *p, uint64_t *i) ;

void lust_fmt_str_debug(lust_String *out, lust_str s) ;

void lust_fmt_char_debug(lust_String *out, uint32_t c) ;

 
void lust_write(int to_stderr, lust_String *s) ;

void lust_flush(void) ;

 
void lust_exit(int32_t code) ;

 

 
void lust_vec_grow_to(lust_Vec *v, uint64_t new_cap, uint64_t elem, uint64_t align) ;

void lust_vec_set_zst(lust_Vec *v, uint64_t align) ;

void lust_vec_reserve(lust_Vec *v, uint64_t extra, uint64_t elem, uint64_t align) ;

void lust_vec_reserve_exact(lust_Vec *v, uint64_t extra, uint64_t elem, uint64_t align) ;

lust_Vec lust_vec_with_capacity(uint64_t n, uint64_t elem, uint64_t align) ;

 
lust_Vec lust_vec_with_capacity_zeroed(uint64_t n, uint64_t elem, uint64_t align) ;

void lust_vec_shrink_to(lust_Vec *v, uint64_t min_cap, uint64_t elem, uint64_t align) ;

void *lust_vec_push_slot(lust_Vec *v, uint64_t elem, uint64_t align) ;

 
void lust_panic_nn(const char *a, uint64_t n, const char *b, uint64_t m, const char *c, lust_loc loc) ;

 
uint64_t lust_slice_range(uint64_t lo, uint64_t hi, int inclusive, uint64_t len, lust_loc loc) ;


 
uint64_t lust_str_range(const uint8_t *ptr, uint64_t lo, uint64_t hi, int inclusive, uint64_t len, lust_loc loc) ;

 
static lust_loc lust_std_loc(uint32_t file, uint32_t line, uint32_t col) {
    return (((uint64_t)(LUST_STD_SLOT + file)) << 40) | ((uint64_t)line << 20) | (uint64_t)col;
}

 
static void lust_range_bounds_check(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t *out_s, uint64_t *out_e) ;

 
lust_VecDrain lust_vec_drain(lust_Vec *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) ;

 
lust_VecDrain lust_vec_drain_t(lust_Vec *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) ;

 
static lust_VecDrain lust_string_drain_in(lust_String *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc, int flag) ;

lust_VecDrain lust_string_drain(lust_String *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) ;

lust_VecDrain lust_string_drain_t(lust_String *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) ;

 
void lust_range_check(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t *out_s, uint64_t *out_e) ;

 
uint8_t lust_bytes_eq_ignore_ascii_case(const uint8_t *a, uint64_t an, const uint8_t *b, uint64_t bn) ;

 
#if !defined(__TINYC__) && defined(__x86_64__) && defined(__SSE2__)
typedef char lust_v16_ __attribute__((vector_size(16)));
typedef char lust_v16u_ __attribute__((vector_size(16), aligned(1)));
#endif
uint8_t lust_bytes_is_ascii(const uint8_t *p, uint64_t n) ;

 
void lust_slice_rotate_left(void *ptr, uint64_t len, uint64_t elem, uint64_t mid) ;

 
 
void lust_utf8_chunk_step(const uint8_t *p, uint64_t len, uint64_t *valid, uint64_t *used) ;

 
int lust_range_bounds_get(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t *out_s, uint64_t *out_e) ;

void lust_slice_copy_within(void *ptr, uint64_t len, uint64_t elem, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t dest, lust_loc loc) ;

 
double lust_fmod_f64(double x, double y) ;

float lust_fmod_f32(float x, float y) ;

uint64_t lust_bounds(uint64_t i, uint64_t len, lust_loc loc) ;

 

#define LUST_OVF(op) lust_ovf(op, loc)

 
#define LUST_SIGNED_NARROW(T, N, MINV, MAXV) \
T lust_add_##N(T a, T b, lust_loc loc) ; \
T lust_sub_##N(T a, T b, lust_loc loc) ; \
T lust_mul_##N(T a, T b, lust_loc loc) ; \
T lust_neg_##N(T a, lust_loc loc) ; \
T lust_div_##N(T a, T b, lust_loc loc) ; \
T lust_rem_##N(T a, T b, lust_loc loc) ;

#define LUST_UNSIGNED_NARROW(T, N, MAXV) \
T lust_add_##N(T a, T b, lust_loc loc) ; \
T lust_sub_##N(T a, T b, lust_loc loc) ; \
T lust_mul_##N(T a, T b, lust_loc loc) ; \
T lust_div_##N(T a, T b, lust_loc loc) ; \
T lust_rem_##N(T a, T b, lust_loc loc) ;

LUST_SIGNED_NARROW(int8_t, i8, -128, 127)
LUST_SIGNED_NARROW(int16_t, i16, -32768, 32767)
LUST_SIGNED_NARROW(int32_t, i32, -2147483647 - 1, 2147483647)
LUST_UNSIGNED_NARROW(uint8_t, u8, 255u)
LUST_UNSIGNED_NARROW(uint16_t, u16, 65535u)
LUST_UNSIGNED_NARROW(uint32_t, u32, 4294967295u)

int64_t lust_add_i64(int64_t a, int64_t b, lust_loc loc) ;
int64_t lust_sub_i64(int64_t a, int64_t b, lust_loc loc) ;
int64_t lust_mul_i64(int64_t a, int64_t b, lust_loc loc) ;
int64_t lust_neg_i64(int64_t a, lust_loc loc) ;
int64_t lust_div_i64(int64_t a, int64_t b, lust_loc loc) ;
int64_t lust_rem_i64(int64_t a, int64_t b, lust_loc loc) ;
uint64_t lust_add_u64(uint64_t a, uint64_t b, lust_loc loc) ;
uint64_t lust_sub_u64(uint64_t a, uint64_t b, lust_loc loc) ;
uint64_t lust_mul_u64(uint64_t a, uint64_t b, lust_loc loc) ;
uint64_t lust_div_u64(uint64_t a, uint64_t b, lust_loc loc) ;
uint64_t lust_rem_u64(uint64_t a, uint64_t b, lust_loc loc) ;

uint32_t lust_shift_amount(uint64_t b, uint32_t bits, const char *op, lust_loc loc) ;

#define LUST_POW(T, N) \
T lust_pow_##N(T a, uint32_t e, lust_loc loc) ;
#define LUST_ABS(T, N) T lust_abs_##N(T a, lust_loc loc) ;
LUST_POW(int8_t, i8) LUST_POW(int16_t, i16) LUST_POW(int32_t, i32) LUST_POW(int64_t, i64)
LUST_POW(uint8_t, u8) LUST_POW(uint16_t, u16) LUST_POW(uint32_t, u32) LUST_POW(uint64_t, u64)
LUST_ABS(int8_t, i8) LUST_ABS(int16_t, i16) LUST_ABS(int32_t, i32) LUST_ABS(int64_t, i64)

 

static uint64_t lust_mask64(unsigned bits) ;
static int64_t lust_sext64(uint64_t v, unsigned bits) ;

int lust_checked_op(uint64_t a, uint64_t b, unsigned bits, int is_signed, int op, uint64_t *out) ;

 
int lust_checked_pow(uint64_t a, uint32_t e, unsigned bits, int is_signed, uint64_t *out) ;

 
uint64_t lust_wrapping_pow(uint64_t a, uint32_t e, unsigned bits) ;

 
 
uint64_t lust_div_ceil(uint64_t a, uint64_t b, unsigned bits, lust_loc loc) ;

uint64_t lust_div_euclid(uint64_t a, uint64_t b, unsigned bits, int is_signed, lust_loc loc) ;
uint64_t lust_rem_euclid(uint64_t a, uint64_t b, unsigned bits, int is_signed, lust_loc loc) ;

uint64_t lust_isqrt64(uint64_t v) ;
uint32_t lust_count_ones64(uint64_t v) ;
uint32_t lust_leading_zeros64(uint64_t v, unsigned bits) ;
uint32_t lust_trailing_zeros64(uint64_t v, unsigned bits) ;

 

 

lust_u128 lust_u128_from_i128(lust_i128 a) ;
lust_i128 lust_i128_from_u128(lust_u128 a) ;

lust_u128 lust_u128_add(lust_u128 a, lust_u128 b) ;
lust_u128 lust_u128_sub(lust_u128 a, lust_u128 b) ;
lust_i128 lust_i128_add(lust_i128 a, lust_i128 b) ;
lust_i128 lust_i128_sub(lust_i128 a, lust_i128 b) ;

int32_t lust_u128_cmp(lust_u128 a, lust_u128 b) ;
int32_t lust_i128_cmp(lust_i128 a, lust_i128 b) ;

lust_u128 lust_u128_and(lust_u128 a, lust_u128 b) ;
lust_u128 lust_u128_or(lust_u128 a, lust_u128 b) ;
lust_u128 lust_u128_xor(lust_u128 a, lust_u128 b) ;
lust_u128 lust_u128_not(lust_u128 a) ;
lust_i128 lust_i128_and(lust_i128 a, lust_i128 b) ;
lust_i128 lust_i128_or(lust_i128 a, lust_i128 b) ;
lust_i128 lust_i128_xor(lust_i128 a, lust_i128 b) ;
lust_i128 lust_i128_not(lust_i128 a) ;

 
uint64_t lust_u128_mul64(uint64_t a, uint64_t b, uint64_t *hi) ;

lust_u128 lust_u128_mul(lust_u128 a, lust_u128 b) ;
lust_i128 lust_i128_mul(lust_i128 a, lust_i128 b) ;

lust_u128 lust_u128_shl(lust_u128 a, uint32_t n) ;
lust_u128 lust_u128_shr(lust_u128 a, uint32_t n) ;
lust_i128 lust_i128_shl(lust_i128 a, uint32_t n) ;
lust_i128 lust_i128_shr(lust_i128 a, uint32_t n) ;

uint32_t lust_u128_clz32(uint32_t x) ;

 
lust_u128 lust_u128_divmod(lust_u128 a, lust_u128 b, lust_u128 *rem) ;

 
lust_u128 lust_u128_divmod64(lust_u128 a, uint64_t b, uint64_t *rem) ;

lust_u128 lust_add_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;
lust_u128 lust_sub_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;
lust_u128 lust_mul_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;
lust_u128 lust_div_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;
lust_u128 lust_rem_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;

lust_u128 lust_i128_mag(lust_i128 a) ;

lust_i128 lust_add_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;
lust_i128 lust_sub_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;
lust_i128 lust_neg_i128(lust_i128 a, lust_loc loc) ;
lust_i128 lust_mul_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;
lust_i128 lust_div_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;
lust_i128 lust_rem_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;

lust_i128 lust_abs_i128(lust_i128 a, lust_loc loc) ;
lust_u128 lust_pow_u128(lust_u128 a, uint32_t e, lust_loc loc) ;
lust_i128 lust_pow_i128(lust_i128 a, uint32_t e, lust_loc loc) ;
 
lust_i128 lust_wrapping_abs_i128(lust_i128 a) ;
lust_u128 lust_wrapping_pow_u128(lust_u128 a, uint32_t e) ;
lust_i128 lust_wrapping_pow_i128(lust_i128 a, uint32_t e) ;

 
void lust_fmt_u128(lust_String *out, lust_u128 v) ;
void lust_fmt_i128(lust_String *out, lust_i128 v) ;

 
void lust_fmt_int_spec(lust_String *out, uint64_t lo, uint64_t hi, int negative, int mode, int plus, int alt, int zero_pad, uint32_t width, uint32_t fill, int align, int has_prec, uint32_t prec) ;

 
uint64_t lust_str_char_count(lust_str s) ;

 
void lust_fmt_pad(lust_String *out, lust_str body, uint32_t width, uint32_t fill, int align) ;

 
void lust_str_trunc_chars(lust_String *s, uint32_t chars) ;

 

void lust_vec_insert_at(lust_Vec *v, uint64_t i, uint64_t elem, uint64_t align, lust_loc loc) ;

void lust_vec_check_remove(lust_Vec *v, uint64_t i, lust_loc loc) ;

void lust_vec_remove_at(lust_Vec *v, uint64_t i, uint64_t elem) ;

 

uint8_t lust_str_starts_with(lust_str s, lust_str p) ;
uint8_t lust_str_ends_with(lust_str s, lust_str p) ;
 
uint64_t lust_memmem(const uint8_t *h, uint64_t hlen, const uint8_t *n, uint64_t nlen);
uint8_t lust_str_contains(lust_str s, lust_str p) ;

 
int64_t lust_str_find(lust_str s, lust_str p) ;
int64_t lust_str_rfind(lust_str s, lust_str p) ;

 
int lust_is_space(uint32_t c) ;

 
int lust_char_is_alphabetic(uint32_t c) ;
int lust_char_is_numeric(uint32_t c) ;
int lust_char_is_alphanumeric(uint32_t c) ;
int lust_char_is_lowercase(uint32_t c) ;
int lust_char_is_uppercase(uint32_t c) ;
int lust_char_is_control(uint32_t c) ;

lust_str lust_str_trim_start(lust_str s) ;

lust_str lust_str_trim_end(lust_str s) ;

 
 
lust_String lust_str_replacen(lust_str s, lust_str from, lust_str to, uint64_t count) ;

lust_String lust_str_replace(lust_str s, lust_str from, lust_str to) ;

lust_String lust_str_repeat(lust_str s, uint64_t n, lust_loc loc) ;

void lust_string_shrink_to(lust_String *s, uint64_t min_cap) ;

 
static uint64_t lust_str_prev_start(const uint8_t *p, uint64_t end) {
    uint64_t k = end - 1;
    while (k > 0 && (p[k] & 0xC0) == 0x80) k--;
    return k;
}

uint32_t lust_string_pop(lust_String *s) ;

 
static void lust_string_check_boundary(lust_String *s, uint64_t idx, const char *what, lust_loc loc) {
    if (idx > s->len || (idx < s->len && (s->ptr[idx] & 0xC0) == 0x80)) {
        lust_String m = lust_string_new();
        lust_string_push_cstr(&m, "assertion failed: self.is_char_boundary(");
        lust_string_push_cstr(&m, what);
        lust_string_push_cstr(&m, ")");
        lust_panic(&m, loc);
    }
}

 
uint32_t lust_string_remove(lust_String *s, uint64_t idx, lust_loc loc) ;

void lust_string_insert_bytes(lust_String *s, uint64_t idx, const uint8_t *p, uint64_t n, lust_loc loc) ;

void lust_string_insert_char(lust_String *s, uint64_t idx, uint32_t c, lust_loc loc) ;

void lust_string_truncate(lust_String *s, uint64_t n, lust_loc loc) ;

lust_String lust_string_split_off(lust_String *s, uint64_t at, lust_loc loc) ;

lust_str lust_str_trim(lust_str s) ;

 
lust_String lust_str_ascii_case(lust_str s, int upper) ;

typedef struct { lust_str s; uint64_t pos; } lust_Chars;
lust_Chars lust_chars(lust_str s) ;
uint64_t lust_chars_count(lust_Chars c) ;
 
uint32_t lust_utf8_prev(const uint8_t *p, uint64_t *end) ;

 
typedef struct { lust_str hay; uint64_t start, end, fpos, bpos, flags, count; } lust_split;
typedef struct {
    uint8_t kind;
    uint32_t ch;
    lust_str needle;
    const uint32_t *set;
    uint64_t n;
    uint8_t (*pred)(void *, uint32_t);
    void *env;
} lust_pat;
enum { LUST_PAT_CHAR, LUST_PAT_STR, LUST_PAT_SET, LUST_PAT_PRED, LUST_PAT_SPACE, LUST_PAT_ASCII_SPACE };
enum { LUST_SPLIT_FINISHED = 1, LUST_SPLIT_TRAILING = 2, LUST_SPLIT_MATCH_FW = 4, LUST_SPLIT_MATCH_BW = 8, LUST_SPLIT_EMPTY_DONE = 16 };

 
int lust_pat_hit(const lust_pat *p, uint32_t c) ;

 
int lust_split_match_fw(lust_split *s, const lust_pat *p, uint64_t *a, uint64_t *b) ;

 
int lust_split_match_bw(lust_split *s, const lust_pat *p, uint64_t *a, uint64_t *b) ;

lust_str lust_split_sub(lust_str h, uint64_t a, uint64_t b) ;

 
int lust_split_get_end(lust_split *s, lust_str *out) ;

 
int lust_split_fw(lust_split *s, const lust_pat *p, int incl, lust_str *out) ;

 
int lust_split_bw(lust_split *s, const lust_pat *p, int incl, lust_str *out) ;

 
int lust_split_step(lust_split *s, const lust_pat *p, uint8_t mode, int back, lust_str *out) ;

 
uint64_t lust_split_upper(const lust_split *s) ;

 
int lust_str_split_once(lust_str hay, const lust_pat *p, int back, lust_str *a, lust_str *b) ;

 

 
int lust_pat_match(lust_str hay, const lust_pat *p, int back, uint64_t *a, uint64_t *b) ;

 
int lust_pat_prefix(lust_str hay, const lust_pat *p, uint64_t *end) ;

 
int lust_pat_suffix(lust_str hay, const lust_pat *p, uint64_t *start) ;

 
lust_str lust_pat_trim_start(lust_str hay, const lust_pat *p) ;

 
lust_str lust_pat_trim_end(lust_str hay, const lust_pat *p) ;

 
int lust_matches_step(lust_split *s, const lust_pat *p, int back, uint64_t *idx, lust_str *out) ;

 
lust_String lust_pat_replacen(lust_str hay, const lust_pat *p, lust_str to, uint64_t count, uint64_t cap) ;

 
int lust_parse_int_radix(lust_str s, uint32_t radix, int is_signed, int bits, uint64_t *lo, uint64_t *hi, int *kind) ;

int lust_parse_int(lust_str s, int is_signed, int bits, uint64_t *lo, uint64_t *hi, int *kind) ;

 
void lust_radix_check(uint32_t radix, lust_loc loc) ;

 
int lust_parse_f64(lust_str s, double *out);
int lust_parse_f32(lust_str s, float *out);

 
int lust_str_parse_f64(lust_str s, double *out, int *kind) ;

int lust_str_parse_f32(lust_str s, float *out, int *kind) ;

 
int lust_parse_bool(lust_str s, uint8_t *out) ;

 
int lust_parse_char(lust_str s, uint32_t *out, int *kind) ;

 
lust_String lust_string_from_utf16_lossy(const uint16_t *v, uint64_t n) ;

 

static int lust_case_in(const uint32_t (*t)[2], uint64_t n, uint32_t c) ;
static const uint32_t *lust_case_map(const uint32_t (*t)[4], uint64_t n, uint32_t c) ;
 
static int lust_ci_then_cased(lust_str s, uint64_t i, int back) ;
lust_String lust_str_case(lust_str s, int upper) ;

 
lust_u128 lust_char_case(uint32_t c, uint8_t upper) ;

 
static void lust_encode_panic(const char *what, uint64_t need, uint32_t c, uint64_t have, lust_loc loc) ;

 
uint64_t lust_char_encode_utf8(uint32_t c, uint8_t *dst, uint64_t dst_len, lust_loc loc) ;

 
uint64_t lust_char_encode_utf16(uint32_t c, uint16_t *dst, uint64_t dst_len, lust_loc loc) ;

 
int lust_utf8_check(const uint8_t *v, uint64_t len, uint64_t *valid_up_to, uint8_t *error_len) ;

 
lust_String lust_env_arg(uint64_t i, int back) ;

 
void lust_fmt_utf8_error(lust_String *out, uint64_t valid_up_to, uint32_t has_len, uint64_t len) ;

 
uint32_t lust_digit(uint32_t c, uint32_t radix, lust_loc loc) ;

 
uint32_t lust_from_digit(uint32_t digit, uint32_t radix, lust_loc loc) ;

 
 
#ifndef LUST_RT_FLOAT_H
#define LUST_RT_FLOAT_H

 
#define LUST_FLOAT_DISPLAY 0
#define LUST_FLOAT_DEBUG 1
#define LUST_FLOAT_LOWER_EXP 2
#define LUST_FLOAT_UPPER_EXP 3

 
#define LUST_FLOAT_NO_PRECISION 0xFFFFFFFFu

 
typedef struct {
    uint32_t precision;
    uint32_t width;
    uint32_t fill;  
    uint8_t align;  
    uint8_t plus;   
    uint8_t zero_pad;
    uint8_t alt;
    uint8_t mode;
} lust_float_spec;

 
void lust_fmt_f64(lust_String *out, double v, lust_float_spec spec);
void lust_fmt_f32(lust_String *out, float v, lust_float_spec spec);

 
void lust_fmt_f64_display(lust_String *out, double v);
void lust_fmt_f64_debug(lust_String *out, double v);
void lust_fmt_f32_display(lust_String *out, float v);
void lust_fmt_f32_debug(lust_String *out, float v);

 
void lust_fmt_js_f64(lust_String *out, double v);
void lust_fmt_js_f32(lust_String *out, float v);
 
uint64_t lust_fmt_js_f64_buf(char *buf, double v);
uint64_t lust_fmt_js_f32_buf(char *buf, float v);

 
int lust_parse_f64(lust_str s, double *out);
int lust_parse_f32(lust_str s, float *out);

 
int8_t lust_f64_to_i8(double v);
int16_t lust_f64_to_i16(double v);
int32_t lust_f64_to_i32(double v);
int64_t lust_f64_to_i64(double v);
uint8_t lust_f64_to_u8(double v);
uint16_t lust_f64_to_u16(double v);
uint32_t lust_f64_to_u32(double v);
uint64_t lust_f64_to_u64(double v);
int8_t lust_f32_to_i8(float v);
int16_t lust_f32_to_i16(float v);
int32_t lust_f32_to_i32(float v);
int64_t lust_f32_to_i64(float v);
uint8_t lust_f32_to_u8(float v);
uint16_t lust_f32_to_u16(float v);
uint32_t lust_f32_to_u32(float v);
uint64_t lust_f32_to_u64(float v);
 
void lust_f64_to_i128(double v, uint64_t *lo, uint64_t *hi);
void lust_f64_to_u128(double v, uint64_t *lo, uint64_t *hi);
void lust_f32_to_i128(float v, uint64_t *lo, uint64_t *hi);
void lust_f32_to_u128(float v, uint64_t *lo, uint64_t *hi);

 
double lust_i64_to_f64(int64_t v);
double lust_u64_to_f64(uint64_t v);
float lust_i64_to_f32(int64_t v);
float lust_u64_to_f32(uint64_t v);
double lust_i128_to_f64(uint64_t lo, uint64_t hi);
double lust_u128_to_f64(uint64_t lo, uint64_t hi);
float lust_i128_to_f32(uint64_t lo, uint64_t hi);
float lust_u128_to_f32(uint64_t lo, uint64_t hi);

 
double lust_fmod_f64(double, double);
float lust_fmod_f32(float, float);

 
float lust_f64_to_f32(double v);
double lust_f32_to_f64(float v);


 
double sqrt(double);
float sqrtf(float);
double pow(double, double);
float powf(float, float);
double exp(double);
float expf(float);
double log(double);
float logf(float);
double log2(double);
float log2f(float);
double log10(double);
float log10f(float);
double floor(double);
float floorf(float);
double ceil(double);
float ceilf(float);
double round(double);
float roundf(float);
double trunc(double);
float truncf(float);
double fma(double, double, double);
float fmaf(float, float, float);
double fabs(double);
float fabsf(float);
double copysign(double, double);
float copysignf(float, float);

double lust_f64_powi(double a, int32_t e);
float lust_f32_powi(float a, int32_t e);
double lust_f64_min(double a, double b);
double lust_f64_max(double a, double b);
float lust_f32_min(float a, float b);
float lust_f32_max(float a, float b);
double lust_f64_signum(double a);
float lust_f32_signum(float a);
uint64_t lust_f64_to_bits(double v);
uint32_t lust_f32_to_bits(float v);
double lust_f64_from_bits_of(uint64_t b);
float lust_f32_from_bits_of(uint32_t b);


#endif


 
 
#ifndef LUST_RT_FMT_H
#define LUST_RT_FMT_H

 
#define LUST_ALIGN_LEFT 0u
#define LUST_ALIGN_RIGHT 1u
#define LUST_ALIGN_CENTER 2u
#define LUST_ALIGN_UNKNOWN 3u

 
#define LUST_FLAG_PLUS 1u
#define LUST_FLAG_MINUS 2u
#define LUST_FLAG_ALT 4u
#define LUST_FLAG_ZERO 8u
#define LUST_FLAG_DEBUG_LOWER_HEX 16u
#define LUST_FLAG_DEBUG_UPPER_HEX 32u
#define LUST_FLAG_WIDTH 64u
#define LUST_FLAG_PREC 128u

 
typedef struct lust_sink lust_sink;
struct lust_sink {
    int (*write)(lust_sink *self, const uint8_t *p, uint64_t n);
    lust_String *direct;
};

 
typedef struct {
    lust_sink base;
    lust_sink *inner;
    uint8_t *on_newline;
} lust_pad_sink;

 
typedef struct {
    lust_sink *buf;
    uint32_t fill;
    uint8_t align;
    uint8_t flags;
    uint16_t width;
    uint16_t prec;
} lust_Formatter;

 
typedef struct {
    lust_pad_sink pad;
    lust_Formatter f;
    uint8_t state;
} lust_fmt_slot;

 
typedef struct {
    lust_Formatter *fmt;
    uint8_t err;
    uint8_t has_fields;
} lust_DebugStruct;
typedef struct {
    lust_Formatter *fmt;
    uint64_t fields;
    uint8_t err;
    uint8_t empty_name;
} lust_DebugTuple;
 
typedef struct {
    lust_Formatter *fmt;
    uint8_t err;
    uint8_t has_fields;
    uint8_t set;
} lust_DebugList;
typedef struct {
    lust_Formatter *fmt;
    uint8_t err;
    uint8_t has_fields;
    uint8_t has_key;
    uint8_t state;
} lust_DebugMap;

 
typedef struct {
    int (*fmt)(const void *env, lust_sink *k);
    const void *env;
    const char *text;
    uint64_t len;
    uint64_t cap;
} lust_Arguments;

 
_Static_assert(sizeof(lust_Formatter) == 24 && sizeof(lust_DebugTuple) == 24, "fmt layout");
_Static_assert(sizeof(lust_Arguments) == 40, "fmt layout");
_Static_assert(sizeof(lust_DebugStruct) == 16 && sizeof(lust_DebugList) == 16 && sizeof(lust_DebugMap) == 16, "fmt layout");

 
void lust_sink_string(lust_sink *k, lust_String *s);
 
void lust_print_begin(lust_sink *k, int to_stderr);
void lust_print_end(int to_stderr);
 
typedef struct {
    lust_sink base;
    int32_t err;
} lust_io_sink;
void lust_io_begin(lust_io_sink *k, int to_stderr);
void lust_f_init(lust_Formatter *f, lust_sink *buf);
 
int lust_args_write(const lust_Arguments *a, lust_sink *k);
int lust_f_args(lust_Formatter *f, const lust_Arguments *a);
lust_String lust_args_to_string(const lust_Arguments *a);
 
void lust_f_set(lust_Formatter *f, uint32_t fill, uint32_t align, uint32_t flags, uint32_t width, uint32_t prec);

int lust_f_write(lust_Formatter *f, const void *p, uint64_t n);
int lust_f_write_str(lust_Formatter *f, lust_str s);
int lust_f_write_char(lust_Formatter *f, uint32_t c);
 
int lust_f_pad(lust_Formatter *f, lust_str s);
int lust_f_pad_integral(lust_Formatter *f, int nonneg, lust_str prefix, lust_str digits);

 
int lust_f_u64(lust_Formatter *f, uint64_t v);
int lust_f_i64(lust_Formatter *f, int64_t v);
int lust_f_u128(lust_Formatter *f, lust_u128 v);
int lust_f_i128(lust_Formatter *f, lust_i128 v);
int lust_f_radix(lust_Formatter *f, uint64_t lo, uint64_t hi, uint32_t mode);
int lust_f_dbg_u64(lust_Formatter *f, uint64_t v);
int lust_f_dbg_i64(lust_Formatter *f, int64_t v, uint64_t mask);
int lust_f_dbg_u128(lust_Formatter *f, lust_u128 v);
int lust_f_dbg_i128(lust_Formatter *f, lust_i128 v);
 
int lust_f_f64(lust_Formatter *f, double v, uint32_t mode);
int lust_f_f32(lust_Formatter *f, float v, uint32_t mode);
 
int lust_f_bool(lust_Formatter *f, uint8_t v);
int lust_f_char(lust_Formatter *f, uint32_t c);
int lust_f_dbg_char(lust_Formatter *f, uint32_t c);
int lust_f_dbg_str(lust_Formatter *f, lust_str s);
int lust_f_unit(lust_Formatter *f);
int lust_f_fnptr(lust_Formatter *f, const void *p);
int lust_f_pointer(lust_Formatter *f, const void *p);
uint32_t lust_f_count(uint64_t n, lust_loc loc);

 
void lust_dstruct_new(lust_DebugStruct *d, lust_Formatter *f, lust_str name);
lust_Formatter *lust_dstruct_field(lust_DebugStruct *d, lust_fmt_slot *s, lust_str name);
void lust_dstruct_field_end(lust_DebugStruct *d, lust_fmt_slot *s, int err);
int lust_dstruct_finish(lust_DebugStruct *d);
int lust_dstruct_finish_ne(lust_DebugStruct *d);
void lust_dtuple_new(lust_DebugTuple *d, lust_Formatter *f, lust_str name);
lust_Formatter *lust_dtuple_field(lust_DebugTuple *d, lust_fmt_slot *s);
void lust_dtuple_field_end(lust_DebugTuple *d, lust_fmt_slot *s, int err);
int lust_dtuple_finish(lust_DebugTuple *d);
int lust_dtuple_finish_ne(lust_DebugTuple *d);
void lust_dlist_new(lust_DebugList *d, lust_Formatter *f, int set);
lust_Formatter *lust_dlist_entry(lust_DebugList *d, lust_fmt_slot *s);
void lust_dlist_entry_end(lust_DebugList *d, lust_fmt_slot *s, int err);
int lust_dlist_finish(lust_DebugList *d);
int lust_dlist_finish_ne(lust_DebugList *d);
void lust_dmap_new(lust_DebugMap *d, lust_Formatter *f);
lust_Formatter *lust_dmap_key(lust_DebugMap *d, lust_fmt_slot *s, lust_loc loc);
void lust_dmap_key_end(lust_DebugMap *d, lust_fmt_slot *s, int err);
lust_Formatter *lust_dmap_value(lust_DebugMap *d, lust_fmt_slot *s, lust_loc loc);
void lust_dmap_value_end(lust_DebugMap *d, lust_fmt_slot *s, int err);
int lust_dmap_finish(lust_DebugMap *d, lust_loc loc);
int lust_dmap_finish_ne(lust_DebugMap *d, lust_loc loc);

 
void lust_fmt_failed(uint32_t what, lust_loc loc);


#endif


 
 

typedef uint8_t (*lust_less_fn)(void *ctx, const void *a, const void *b);

typedef struct {
    uint64_t size, align;
    uint8_t freeze, copy;
    void *ctx;
    lust_less_fn less;
} lust_sort_cx;

#define LS_AT(p, i) ((uint8_t *)(p) + (uint64_t)(i) * s->size)
#define LS_LESS(a, b) (s->less(s->ctx, (a), (b)) != 0)

uint32_t lust_sort_ilog2(uint64_t n) ;

void lust_sort_swap(lust_sort_cx *s, uint8_t *a, uint8_t *b) ;

void lust_sort_reverse(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 
typedef struct { uint8_t *p; uint8_t local[64] __attribute__((aligned(16))); } lust_sort_tmp;
uint8_t *lust_sort_tmp_get(lust_sort_cx *s, lust_sort_tmp *t) ;
void lust_sort_tmp_free(lust_sort_tmp *t) ;

 
uint64_t lust_sort_find_run(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *was_reversed) ;

 
void lust_sort_insert_tail(lust_sort_cx *s, uint8_t *begin, uint8_t *tail) ;

void lust_sort_insertion_shift_left(lust_sort_cx *s, uint8_t *v, uint64_t len, uint64_t offset) ;

 
void lust_sort_sort4_stable(lust_sort_cx *s, uint8_t *v, uint8_t *dst) ;

void lust_sort_ord_violation(void) ;

 
void lust_sort_bidir_merge(lust_sort_cx *s, uint8_t *src, uint64_t len, uint8_t *dst) ;

void lust_sort_sort8_stable(lust_sort_cx *s, uint8_t *v, uint8_t *dst, uint8_t *scratch) ;

 
void lust_sort_small_general(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch) ;

 
void lust_sort_swap_if_less(lust_sort_cx *s, uint8_t *v, uint64_t a_pos, uint64_t b_pos) ;

void lust_sort_net(lust_sort_cx *s, uint8_t *v, const uint8_t *pairs, int n) ;

 
void lust_sort_small_network(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 
uint8_t *lust_sort_median3(lust_sort_cx *s, uint8_t *a, uint8_t *b, uint8_t *c) ;
uint8_t *lust_sort_median3_rec(lust_sort_cx *s, uint8_t *a, uint8_t *b, uint8_t *c, uint64_t n) ;
uint64_t lust_sort_choose_pivot(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 

uint64_t lust_sort_stable_threshold(lust_sort_cx *s) ;

void lust_sort_stable_small(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch) ;

 
void lust_sort_merge(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint64_t mid) ;

void lust_sort_drift(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint8_t eager_sort);

 
uint64_t lust_sort_stable_partition(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len,
                                           uint64_t pivot_pos, uint8_t pivot_goes_left, uint8_t inv) ;

 
void lust_sort_stable_quick(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint32_t limit,
                                   uint8_t *left_ancestor_pivot) ;

void lust_sort_stable_quicksort(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len) ;

 
void lust_sort_drift(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint8_t eager_sort) ;

 
void lust_sort_stable(void *v, uint64_t len, uint64_t size, uint64_t align, uint8_t freeze, void *ctx, lust_less_fn less) ;

 

uint8_t lust_sort_network_ok(lust_sort_cx *s) ;

uint64_t lust_sort_unstable_threshold(lust_sort_cx *s) ;

void lust_sort_unstable_small(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 
void lust_sort_sift_down(lust_sort_cx *s, uint8_t *v, uint64_t len, uint64_t node) ;
void lust_sort_heapsort(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 
uint8_t lust_sort_cmp(lust_sort_cx *s, uint8_t *a, uint8_t *b, uint8_t inv) ;

uint64_t lust_sort_lomuto(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *pivot, uint8_t inv) ;

uint64_t lust_sort_hoare(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *pivot, uint8_t inv) ;

uint64_t lust_sort_partition(lust_sort_cx *s, uint8_t *v, uint64_t len, uint64_t pivot, uint8_t inv) ;

void lust_sort_unstable_quick(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *ancestor_pivot, uint32_t limit) ;

 
void lust_sort_unstable(void *v, uint64_t len, uint64_t size, uint64_t align, uint8_t freeze, uint8_t copy, void *ctx, lust_less_fn less) ;

#undef LS_AT
#undef LS_LESS

 
typedef int32_t (*lust_cmp_fn)(void *ctx, const void *p);
int64_t lust_binary_search(void *v, uint64_t len, uint64_t size, void *ctx, lust_cmp_fn cmp) ;


 


 
 
#ifndef LUST_RT_DEPS_H
#define LUST_RT_DEPS_H

 
uint64_t lust_memchr(uint32_t needle, const uint8_t *p, uint64_t len);
uint64_t lust_memrchr(uint32_t needle, const uint8_t *p, uint64_t len);
uint64_t lust_memmem(const uint8_t *h, uint64_t hlen, const uint8_t *n, uint64_t nlen);
 
uint64_t lust_memchr3(uint32_t a, uint32_t b, uint32_t c, const uint8_t *p, uint64_t n);
uint64_t lust_memrchr3(uint32_t a, uint32_t b, uint32_t c, const uint8_t *p, uint64_t n);

 
uint64_t lust_xxh3_64(const uint8_t *p, uint64_t len, uint64_t seed);
lust_u128 lust_xxh3_128(const uint8_t *p, uint64_t len, uint64_t seed);


#endif


 

 
#define LUST_MO(o) ((o) == 0 ? 0 : (o) == 1 ? 3 : (o) == 2 ? 2 : (o) == 3 ? 4 : 5)
 
#define LUST_MO_CAS(s, f) (((f) == 4) ? 5 : ((f) == 2 && ((s) == 0 || (s) == 1)) ? ((s) == 0 ? 2 : 4) : LUST_MO(s))
 
#define LUST_MO_LOADPART(o) ((o) == 4 ? 5 : ((o) == 2 || (o) == 3) ? 2 : 0)


 
#define LUST_ATOMIC_RS "core/src/sync/atomic.rs:"

#define LUST_ATOMIC_WIDTH(N, U, S)                                                                                     \
    U lust_at_load_##N(U *p, uint32_t o, lust_loc loc) ;                                                                                                                 \
    void lust_at_store_##N(U *p, U v, uint32_t o, lust_loc loc) ;                                                                                                                 \
    U lust_at_swap_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    int lust_at_cas_##N(U *p, U cur, U nv, uint32_t s, uint32_t f, U *old, int weak) ;                                                                                                                 \
    U lust_at_fetch_add_##N(U *p, U v, uint32_t o) ;        \
    U lust_at_fetch_sub_##N(U *p, U v, uint32_t o) ;        \
    U lust_at_fetch_and_##N(U *p, U v, uint32_t o) ;        \
    U lust_at_fetch_or_##N(U *p, U v, uint32_t o) ;          \
    U lust_at_fetch_xor_##N(U *p, U v, uint32_t o) ;        \
    U lust_at_fetch_nand_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    U lust_at_fetch_umax_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    U lust_at_fetch_umin_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    U lust_at_fetch_smax_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    U lust_at_fetch_smin_##N(U *p, U v, uint32_t o) ;

LUST_ATOMIC_WIDTH(1, uint8_t, int8_t)
LUST_ATOMIC_WIDTH(2, uint16_t, int16_t)
LUST_ATOMIC_WIDTH(4, uint32_t, int32_t)
LUST_ATOMIC_WIDTH(8, uint64_t, int64_t)

 
uint8_t lust_at_fetch_bnand_1(uint8_t *p, uint8_t v, uint32_t o) ;

void lust_at_fence(uint32_t o, lust_loc loc) ;

void lust_at_compiler_fence(uint32_t o, lust_loc loc) ;

 

 
void lust_arc_inc(uint64_t *c) ;

 
int lust_arc_dec(uint64_t *c) ;

 
void *lust_arc_empty(void) ;

 
uint64_t lust_arc_load(uint64_t *c) ;

 
void lust_arc_downgrade(uint64_t *h) ;

 
int lust_arc_upgrade(uint64_t *h) ;

 
uint64_t lust_arc_weak_count(uint64_t *h) ;

 
uint64_t lust_arc_weak_weak_count(uint64_t *h) ;

 
int lust_arc_is_unique(uint64_t *h) ;

 
int lust_arc_make_mut_state(uint64_t *h) ;

 
int lust_arc_take_unique(uint64_t *h) ;

 

 
void lust_poison_enter(uint8_t *f) ;
void lust_poison_leave(uint8_t *f) ;

 
static void lust_lock_pause(void) {
#if !defined(__TINYC__) && (defined(__x86_64__) || defined(__i386__))
    __builtin_ia32_pause();
#elif !defined(__TINYC__) && defined(__aarch64__)
    __asm__ __volatile__("yield");
#endif
}

 
static uint32_t lust_lock_spin(uint32_t *st, uint32_t busy) {
    uint32_t s;
    for (int i = 0; i < 100; i++) {
        __atomic_load(st, &s, 0);
        if (s != busy) return s;
        lust_lock_pause();
    }
    __atomic_load(st, &s, 0);
    return s;
}

 
void lust_mutex_lock(uint32_t *st) ;

 
int lust_mutex_trylock(uint32_t *st) ;

void lust_mutex_unlock(uint32_t *st) ;

 
#define LUST_RW_WRITER 0xffffffffu
void lust_rw_read(uint32_t *st) ;

int lust_rw_tryread(uint32_t *st) ;

void lust_rw_read_unlock(uint32_t *st) ;

void lust_rw_write(uint32_t *st) ;

int lust_rw_trywrite(uint32_t *st) ;

void lust_rw_write_unlock(uint32_t *st) ;

 
typedef struct lust_ThreadInfo {
    uint64_t rc;
    uint64_t id;
    const uint8_t *name;
    uint64_t name_len;
     
    uint8_t *name_buf;
     
    uintptr_t guard_lo, guard_hi;
    void *alt;
} lust_ThreadInfo;

 
typedef struct lust_Scope {
    uint32_t live;
    uint32_t panicked;  
} lust_Scope;

typedef struct lust_JoinHdr {
    uintptr_t t;  
    lust_ThreadInfo *th;
    uint32_t rc;
    uint32_t done;
    void (*run)(struct lust_JoinHdr *);
    void (*drop_ret)(struct lust_JoinHdr *);
    lust_Scope *scope;  
    uint32_t panicked;  
    lust_dyn payload;
} lust_JoinHdr;

 
#ifdef __APPLE__
#define LUST_PTHREAD_ID_P(p) ((pthread_t *)(void *)(p))
#define LUST_PTHREAD_ID(v) ((pthread_t)(uintptr_t)(v))
#else
#define LUST_PTHREAD_ID_P(p) (p)
#define LUST_PTHREAD_ID(v) (v)
#endif


 
void lust_thread_spawn(lust_JoinHdr *h, lust_loc loc) ;

 
typedef struct lust_ThreadBuilder {
    lust_String name;
    uint64_t stack;
    uint8_t has_name;
    uint8_t has_stack;
} lust_ThreadBuilder;

#if !defined(__APPLE__) && !defined(_WIN32)
int pthread_attr_init(void *attr);
int pthread_attr_destroy(void *attr);
int pthread_attr_setstacksize(void *attr, uint64_t size);
int pthread_setname_np(uintptr_t t, const char *name);
#endif

 
int lust_thread_spawn_builder(lust_JoinHdr *h, const lust_ThreadBuilder *b) ;

 

 
uint64_t lust_avail_parallelism(int32_t *err) ;

 
void lust_thread_join(lust_JoinHdr *h) ;

void lust_join_free(lust_JoinHdr *h) ;

 
void lust_join_drop(lust_JoinHdr *h) ;

int lust_join_is_finished(lust_JoinHdr *h) ;

 
lust_ThreadInfo *lust_thread_current(void) ;

lust_ThreadInfo *lust_thread_clone(lust_ThreadInfo *t) ;

void lust_thread_drop(lust_ThreadInfo *t) ;

void lust_thread_yield(void) ;

 
void lust_scope_wait(lust_Scope *sc) ;

 
typedef struct lust_Chan {
    uint32_t lock;
    uint32_t seq;
    uint32_t sleepers;
    uint64_t senders;
    uint32_t rx_alive;
    uint32_t rx_waiting;
    uint32_t tx_waiting;
    uint32_t rx_claim;
    int64_t cap;
    uint64_t esize;
    uint64_t ealign;
    uint8_t *buf;
    uint64_t head, len, bufcap;
    uint64_t taken;
    void (*drop_elem)(void *);
} lust_Chan;



lust_Chan *lust_chan_new(uint64_t esize, uint64_t ealign, int64_t cap, void (*drop_elem)(void *)) ;

 
int lust_chan_send(lust_Chan *c, const void *v) ;

 
int lust_chan_try_send(lust_Chan *c, const void *v) ;

 
int lust_chan_recv(lust_Chan *c, void *out, int block) ;

lust_Chan *lust_chan_clone_sender(lust_Chan *c) ;

void lust_chan_drop_sender(lust_Chan *c) ;

void lust_chan_drop_receiver(lust_Chan *c) ;

 
void lust_cv_wait(uint32_t *cv, uint32_t *m) ;

void lust_cv_notify(uint32_t *cv, int all) ;

 
#if defined(__linux__)
#if defined(__x86_64__)
#define LUST_SYS_CLOCK_GETTIME 228
#elif defined(__aarch64__)
#define LUST_SYS_CLOCK_GETTIME 113
#endif
#endif

static void lust_mono_now(long ts[2]) ;

 
void lust_cv_start(long ts[2]) ;

 
int lust_cv_left(const long start[2], uint64_t secs, uint32_t nanos, uint64_t *rs, uint32_t *rn) ;

int lust_cv_wait_timeout(uint32_t *cv, uint32_t *m, uint64_t secs, uint32_t nanos) ;

 
int lust_chan_recv_timeout(lust_Chan *c, void *out, uint64_t secs, uint32_t nanos) ;

typedef struct lust_Barrier {
    uint32_t lock;
    uint32_t seq;
    uint64_t count;
    uint64_t gen;
    uint64_t n;
} lust_Barrier;

 
int lust_barrier_wait(lust_Barrier *b) ;

 
int lust_once_begin(uint32_t *st) ;

void lust_once_finish(uint32_t *st) ;

 
void lust_once_abort(uint32_t *st) ;

 
struct lust_once_guard { uint32_t *st; void *env; void (*drop)(void *); int32_t armed; };
void lust_once_guard_end(struct lust_once_guard *g) ;

int lust_once_is_done(uint32_t *st) ;

 
typedef struct lust_Duration {
    uint64_t secs;
    uint32_t nanos;
} lust_Duration;

 
lust_Duration lust_dur_new(uint64_t secs, uint32_t nanos, lust_loc loc) ;

 
lust_u128 lust_dur_as(lust_Duration d, uint64_t per_sec, uint64_t nanos_per) ;


 
void lust_thread_sleep(lust_Duration d) ;

 
 
#ifndef LUST_RT_SYS_H
#define LUST_RT_SYS_H

 
#ifdef __APPLE__
#define LUST_ST_ATIME(st) (st).st_atimespec
#define LUST_ST_MTIME(st) (st).st_mtimespec
#define LUST_ST_CTIME(st) (st).st_ctimespec
#define LUST_ST_BTIME(st) (st).st_birthtimespec
#else
#define LUST_ST_ATIME(st) (st).st_atim
#define LUST_ST_MTIME(st) (st).st_mtim
#define LUST_ST_CTIME(st) (st).st_ctim
#endif

 
int64_t lust_sys_write_std(int32_t fd, const uint8_t *p, uint64_t len);
int32_t lust_sys_flush_std(int32_t fd);

 
lust_Vec lust_sys_fmt_arguments_bytes(lust_Arguments args);

 
lust_str lust_sys_str_as_bytes(lust_str s);
lust_str lust_sys_bytes_as_str(const uint8_t *p, uint64_t len);
lust_String lust_sys_string_from_utf8_unchecked(lust_Vec v);
uint64_t lust_sys_utf8_valid_up_to(const uint8_t *p, uint64_t len);
void lust_sys_utf8_lossy(const uint8_t *p, uint64_t len, lust_String *out);

 
uint8_t lust_sys_getenv(const uint8_t *k, uint64_t klen, lust_Vec *out);

 
void lust_sys_environ(lust_Vec *out);
void lust_sys_argv(lust_Vec *out);
int32_t lust_sys_getcwd(lust_Vec *out);
int32_t lust_sys_chdir(const uint8_t *p, uint64_t len);
int32_t lust_sys_symlink(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen);
int32_t lust_sys_readlink(const uint8_t *p, uint64_t len, lust_Vec *out);

 
int32_t lust_sys_read_file(const uint8_t *p, uint64_t len, lust_Vec *out);
int32_t lust_sys_write_file(const uint8_t *p, uint64_t len, const uint8_t *d, uint64_t dlen);
int32_t lust_sys_path_op(const uint8_t *p, uint64_t len, int32_t op);
int32_t lust_sys_rename(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen);
int32_t lust_sys_stat(const uint8_t *p, uint64_t len, uint8_t follow, lust_Vec *out);
int32_t lust_sys_realpath(const uint8_t *p, uint64_t len, lust_Vec *out);
int32_t lust_sys_read_dir(const uint8_t *p, uint64_t len, lust_Vec *out);
int32_t lust_sys_remove_dir_all(const uint8_t *p, uint64_t len);

 
int32_t lust_sys_btime_path(const char *path, int32_t follow, int64_t *sec, int64_t *nsec);
int32_t lust_sys_btime_fd(int32_t fd, int64_t *sec, int64_t *nsec);

uint32_t lust_sys_getpid(void);

 
int32_t lust_sys_current_exe(lust_Vec *out);

 
void lust_sys_os_error_text(int32_t code, lust_String *out);


#endif

 
 
#ifndef LUST_RT_SYSIO_H
#define LUST_RT_SYSIO_H

 
int64_t lust_sys_fd_read(int32_t fd, uint64_t max, lust_Vec *out);
 
int64_t lust_sys_fd_write(int32_t fd, const uint8_t *p, uint64_t len);
 
int32_t lust_sys_fd_close(int32_t fd);
 
int32_t lust_sys_fd_dup(int32_t fd);
 
int32_t lust_sys_fd_sync(int32_t fd);
 
int32_t lust_sys_fd_sync_data(int32_t fd);
 
int32_t lust_sys_fd_truncate(int32_t fd, uint64_t len);
 
int64_t lust_sys_fd_seek(int32_t fd, int64_t off, int32_t whence);
 
int64_t lust_sys_fd_pread(int32_t fd, uint64_t max, int64_t off, lust_Vec *out);
 
int64_t lust_sys_fd_pwrite(int32_t fd, const uint8_t *p, uint64_t len, int64_t off);
 
int32_t lust_sys_fd_isatty(int32_t fd);
 
int32_t lust_sys_fd_stat(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_fd_open(const uint8_t *p, uint64_t len, int32_t flags);
 
int32_t lust_sys_fd_open_ext(const uint8_t *p, uint64_t len, int32_t flags, int32_t custom, uint32_t mode);

 
int64_t lust_sys_stdin_read(uint64_t max, lust_Vec *out);
int64_t lust_sys_stdin_fill(lust_Vec *out);
void lust_sys_stdin_consume(uint64_t n);

 
int32_t lust_sys_proc_spawn(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                            const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                            const uint8_t *fds, uint64_t fdslen, lust_Vec *out);
 
int32_t lust_sys_proc_exec(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                           const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                           const uint8_t *fds, uint64_t fdslen);
 
int64_t lust_sys_proc_wait(uint32_t pid, uint8_t block);
 
int32_t lust_sys_proc_kill(uint32_t pid);
 
int32_t lust_sys_fd_read_both(int32_t fd1, lust_Vec *out1, int32_t fd2, lust_Vec *out2);


#endif

 
 
#ifndef LUST_RT_SYSNET_H
#define LUST_RT_SYSNET_H

 
int32_t lust_sys_net_resolve(const uint8_t *host, uint64_t hostlen, uint64_t port, lust_Vec *out);
 
int32_t lust_sys_net_tcp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out);
 
int32_t lust_sys_net_udp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out);
 
int32_t lust_sys_net_tcp_connect(const uint8_t *rec, uint64_t len, lust_Vec *out);
 
int32_t lust_sys_net_tcp_connect_timeout(const uint8_t *rec, uint64_t len, int64_t timeout_us, lust_Vec *out);
 
int32_t lust_sys_net_connect_fd(int32_t fd, const uint8_t *rec, uint64_t len);
 
int32_t lust_sys_net_accept(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_net_addr_of(int32_t fd, int32_t peer, lust_Vec *out);
 
int32_t lust_sys_net_shutdown(int32_t fd, int32_t how);
 
int32_t lust_sys_net_setopt(int32_t fd, int32_t opt, int64_t val);
int64_t lust_sys_net_getopt(int32_t fd, int32_t opt);
 
int64_t lust_sys_net_sendto(int32_t fd, const uint8_t *p, uint64_t len, const uint8_t *rec, uint64_t rlen);
 
int64_t lust_sys_net_recvfrom(int32_t fd, uint64_t max, int32_t flags, lust_Vec *out, lust_Vec *addrout);
 
 
int32_t lust_sys_net_unix_pair(lust_Vec *out);
 
int32_t lust_sys_net_unix_bind(const uint8_t *p, uint64_t len, int32_t abstract);
 
int32_t lust_sys_net_unix_connect(const uint8_t *p, uint64_t len, int32_t abstract);
 
int32_t lust_sys_net_unix_accept(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_net_unix_addr(int32_t fd, int32_t peer, lust_Vec *out);


#endif

 
 
#ifndef LUST_RT_SYSX_H
#define LUST_RT_SYSX_H

 
int32_t lust_sys_x_kill(int32_t pid, int32_t sig);
 
int32_t lust_sys_x_getppid(void);
 
int32_t lust_sys_x_prctl_deathsig(int32_t sig);
 
int32_t lust_sys_x_waitid(int32_t idtype, int32_t id, int32_t options, lust_Vec *out);
 
int32_t lust_sys_x_sigmask(int32_t how, uint64_t set);
 
int32_t lust_sys_x_prctl_thp(int32_t mode, int32_t val);
 
int32_t lust_sys_x_getrlimit(int32_t resource, lust_Vec *out);
 
int32_t lust_sys_x_setrlimit(int32_t resource, uint64_t current, uint64_t maximum);
 
int32_t lust_sys_x_openat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mode);
 
int32_t lust_sys_x_statat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out);
 
int32_t lust_sys_x_fstat(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_x_statx(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mask, lust_Vec *out);
 
int32_t lust_sys_x_accessat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t mode, int32_t flags);
 
int32_t lust_sys_x_utimensat(int32_t dirfd, const uint8_t *p, uint64_t len, int64_t a_sec, int64_t a_nsec, int64_t m_sec, int64_t m_nsec, int32_t flags);
 
int32_t lust_sys_x_mknodat(int32_t dirfd, const uint8_t *p, uint64_t len, uint32_t mode, uint64_t dev);
 
int32_t lust_sys_x_fcntl_getfl(int32_t fd);
 
int32_t lust_sys_x_fcntl_setfl(int32_t fd, int32_t flags);
 
int32_t lust_sys_x_winsize(int32_t fd, lust_Vec *out);
 
 
int32_t lust_sys_sig_register(int32_t sig, int32_t kind, void *flag, uint64_t value);
 
int32_t lust_sys_sig_register_pipe(int32_t sig, int32_t write_fd);
 
void lust_sys_sig_unregister_pipe(int32_t write_fd);
 
int32_t lust_sys_sig_pipe(lust_Vec *out);
 
int32_t lust_sys_sig_poll_read(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_sig_read_now(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_sig_raise(int32_t sig);
 
int32_t lust_sys_sig_restore_raise(int32_t sig);
 
void lust_sys_sig_exit(int32_t status);
 
void lust_sys_sig_abort(void);
 
int32_t lust_sys_x_pipe(int32_t flags, lust_Vec *out);
 
int32_t lust_sys_x_dup2(int32_t oldfd, int32_t newfd);
 
int32_t lust_sys_x_poll(lust_Vec *recs, int64_t sec, int64_t nsec);
 
int32_t lust_sys_x_inotify_init1(int32_t flags);
 
int32_t lust_sys_x_inotify_add_watch(int32_t fd, const uint8_t *p, uint64_t len, uint32_t mask);
 
int32_t lust_sys_x_inotify_rm_watch(int32_t fd, int32_t wd);
 
int64_t lust_sys_x_getdents(int32_t fd, uint64_t max, lust_Vec *out);
 
int32_t lust_sys_x_statvfs(const uint8_t *p, uint64_t len, lust_Vec *out);
 
int32_t lust_sys_x_fstatvfs(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_x_fanotify_init(uint32_t flags, uint32_t event_f_flags);
 
int32_t lust_sys_x_fanotify_mark(int32_t fd, uint32_t flags, uint64_t mask, int32_t dirfd, int32_t has_path, const uint8_t *p, uint64_t len);
 
int32_t lust_sys_x_name_to_handle_at(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out);
 
int32_t lust_sys_x_open_by_handle_at(int32_t mount_fd, int32_t handle_type, const uint8_t *p, uint64_t len, int32_t flags);
 
int32_t lust_sys_x_kqueue(void);
 
int32_t lust_sys_x_kevent(int32_t fd, const uint8_t *changes, uint64_t clen, lust_Vec *events, int32_t has_timeout, int64_t sec, int64_t nsec);


#endif

 
 
#ifndef LUST_RT_STDC_H
#define LUST_RT_STDC_H

 
lust_u128 lust_clock_now_raw(void);
lust_u128 lust_system_time_raw(void);

 
uint32_t lust_fmt_align(lust_Formatter *f);


#endif


/* Inline fast paths of the hottest small runtime helpers, for units an optimizing C
   compiler builds (release builds have no LTO, so each helper would be a call into the
   runtime unit: atomic loads, Once checks, leading_zeros, slice ranges and division were
   about 10% of a release tsgo's cycles). Each macro keeps its function's name, arguments
   and result; a slow path (a panic, a grow, a wait) calls that function, which a
   function-like macro does not expand inside its own body. cgen appends this text after
   the runtime declarations (`unit_header`); tcc units and the runtime unit itself call
   the functions, and so does a build with -DLUST_NO_INL (for A/B timing). */
#if !defined(__TINYC__) && !defined(LUST_IMPL) && !defined(LUST_NO_INL)
/* lust's atomic ordering (0 Relaxed, 1 Release, 2 Acquire, 3 AcqRel, 4 SeqCst) as a C
   memory order, as sync.c LUST_MO. A load's Release and AcqRel orders panic: the
   function does that. */
#define lust_inl_mo_(o) ((o) == 0 ? __ATOMIC_RELAXED : (o) == 1 ? __ATOMIC_RELEASE : (o) == 2 ? __ATOMIC_ACQUIRE : (o) == 3 ? __ATOMIC_ACQ_REL : __ATOMIC_SEQ_CST)
#define lust_inl_load_(N, U, p, o, loc)                                                                     \
    __extension__({                                                                                         \
        U *lust_p_ = (p);                                                                                   \
        uint32_t lust_o_ = (o);                                                                             \
        __builtin_expect(lust_o_ == 1 || lust_o_ == 3, 0) ? lust_at_load_##N(lust_p_, lust_o_, (loc))      \
                                                          : __atomic_load_n(lust_p_, lust_inl_mo_(lust_o_)); \
    })
#define lust_at_load_1(p, o, loc) lust_inl_load_(1, uint8_t, p, o, loc)
#define lust_at_load_2(p, o, loc) lust_inl_load_(2, uint16_t, p, o, loc)
#define lust_at_load_4(p, o, loc) lust_inl_load_(4, uint32_t, p, o, loc)
#define lust_at_load_8(p, o, loc) lust_inl_load_(8, uint64_t, p, o, loc)

/* A Once is set when its state is 2 (sync.c): no compare-exchange, no wait. */
#define lust_once_is_done(st) (__atomic_load_n((st), __ATOMIC_ACQUIRE) == 2)
#define lust_once_begin(st)                                                                         \
    __extension__({                                                                                 \
        uint32_t *lust_st_ = (st);                                                                  \
        __builtin_expect(__atomic_load_n(lust_st_, __ATOMIC_ACQUIRE) == 2, 1) ? 0 : lust_once_begin(lust_st_); \
    })

#define lust_leading_zeros64(v, bits)                                                                  \
    __extension__({                                                                                    \
        uint64_t lust_v_ = (v);                                                                        \
        unsigned lust_b_ = (bits);                                                                     \
        lust_v_ ? (uint32_t)(__builtin_clzll(lust_v_) - (64 - lust_b_)) : (uint32_t)lust_b_;           \
    })

/* A slice range in bounds; the function panics in Rust's order otherwise. */
#define lust_slice_range(lo, hi, inclusive, len, loc)                                                  \
    __extension__({                                                                                    \
        uint64_t lust_lo_ = (lo), lust_hi_ = (hi), lust_len_ = (len);                                  \
        int lust_inc_ = (inclusive);                                                                   \
        uint64_t lust_end_ = lust_inc_ ? lust_hi_ + 1 : lust_hi_;                                      \
        __builtin_expect(lust_lo_ <= lust_len_ && (lust_inc_ ? lust_hi_ < lust_len_ : lust_hi_ <= lust_len_) && lust_lo_ <= lust_end_, 1) \
            ? lust_end_                                                                                \
            : lust_slice_range(lust_lo_, lust_hi_, lust_inc_, lust_len_, (loc));                       \
    })

#define lust_div_u64(a, b, loc) \
    __extension__({ uint64_t lust_a_ = (a), lust_d_ = (b); __builtin_expect(lust_d_ != 0, 1) ? lust_a_ / lust_d_ : lust_div_u64(lust_a_, lust_d_, (loc)); })
#define lust_rem_u64(a, b, loc) \
    __extension__({ uint64_t lust_a_ = (a), lust_d_ = (b); __builtin_expect(lust_d_ != 0, 1) ? lust_a_ % lust_d_ : lust_rem_u64(lust_a_, lust_d_, (loc)); })
#define lust_div_i64(a, b, loc)                                                                         \
    __extension__({                                                                                     \
        int64_t lust_a_ = (a), lust_d_ = (b);                                                           \
        __builtin_expect(lust_d_ != 0 && !(lust_a_ == INT64_MIN && lust_d_ == -1), 1) ? lust_a_ / lust_d_ : lust_div_i64(lust_a_, lust_d_, (loc)); \
    })
#define lust_rem_i64(a, b, loc)                                                                         \
    __extension__({                                                                                     \
        int64_t lust_a_ = (a), lust_d_ = (b);                                                           \
        __builtin_expect(lust_d_ != 0 && !(lust_a_ == INT64_MIN && lust_d_ == -1), 1) ? lust_a_ % lust_d_ : lust_rem_i64(lust_a_, lust_d_, (loc)); \
    })

/* The C compiler's own memcpy and memmove: a small constant copy (a from_le_bytes, a
   moved value) becomes loads and stores instead of two calls. A macro whose arguments
   may be compound literals (`&(T){a, b}`, `(lust_u128){lo, hi}`: the comma in the braces
   splits a macro argument list) takes `...`; one that names them binds them with a
   struct initializer. */
#define lust_memcpy(...) ((void)__builtin_memcpy(__VA_ARGS__))
#define lust_memmove(...) ((void)__builtin_memmove(__VA_ARGS__))

/* A push or reserve that fits the capacity; growth (and zero-sized elements) take the
   function. A reserve_exact on an empty Vec (most of them: the first buffer of a collect or
   an extend) is one malloc here, as the function would do it: the element size is the call
   site's constant, so the size check (lust_vec_fits) folds. Any other case (an alignment
   over 16, an overflow, a failed malloc) is one call of the function. */
#define lust_vec_reserve_exact(v, extra, elem, align)                                                  \
    __extension__({                                                                                    \
        lust_Vec *lust_rv_ = (v);                                                                      \
        uint64_t lust_rx_ = (extra), lust_re_ = (elem), lust_ra_ = (align);                            \
        void *lust_rp_;                                                                                \
        if (lust_re_ == 0 || lust_rv_->cap - lust_rv_->len < lust_rx_) {                               \
            if (lust_re_ != 0 && lust_rv_->cap == 0 && lust_ra_ <= 16 && lust_vec_fits(lust_rx_, lust_re_) \
                && (lust_rp_ = __builtin_malloc(lust_rx_ * lust_re_)) != 0) {                          \
                lust_rv_->ptr = lust_rp_;                                                              \
                lust_rv_->cap = lust_rx_;                                                              \
            } else {                                                                                   \
                lust_vec_reserve_exact(lust_rv_, lust_rx_, lust_re_, lust_ra_);                        \
            }                                                                                          \
        }                                                                                              \
        (void)0;                                                                                       \
    })
#define lust_vec_push_slot(v, elem, align)                                                             \
    __extension__({                                                                                    \
        lust_Vec *lust_v_ = (v);                                                                       \
        uint64_t lust_e_ = (elem);                                                                     \
        __builtin_expect(lust_e_ != 0 && lust_v_->len < lust_v_->cap, 1)                              \
            ? (void *)((char *)lust_v_->ptr + (lust_v_->len++) * lust_e_)                              \
            : lust_vec_push_slot(lust_v_, lust_e_, (align));                                           \
    })
#define lust_vec_reserve(v, extra, elem, align)                                                        \
    __extension__({                                                                                    \
        lust_Vec *lust_v_ = (v);                                                                       \
        uint64_t lust_x_ = (extra), lust_e_ = (elem);                                                  \
        if (!__builtin_expect(lust_e_ != 0 && lust_v_->cap - lust_v_->len >= lust_x_, 1))             \
            lust_vec_reserve(lust_v_, lust_x_, lust_e_, (align));                                      \
        (void)0;                                                                                       \
    })
/* Atomic stores, swaps, compare-exchanges and fetch ops: the orders that panic take
   the function, as the narrow loads above. */
#define lust_inl_mo_cas_(s, f) (((f) == 4) ? __ATOMIC_SEQ_CST : ((f) == 2 && ((s) == 0 || (s) == 1)) ? ((s) == 0 ? __ATOMIC_ACQUIRE : __ATOMIC_ACQ_REL) : lust_inl_mo_(s))
#define lust_inl_store_(N, U, p, v, o, loc)                                                             \
    __extension__({                                                                                     \
        U *lust_p_ = (p);                                                                               \
        U lust_v_ = (v);                                                                                \
        uint32_t lust_o_ = (o);                                                                         \
        if (__builtin_expect(lust_o_ == 2 || lust_o_ == 3, 0)) lust_at_store_##N(lust_p_, lust_v_, lust_o_, (loc)); \
        else __atomic_store_n(lust_p_, lust_v_, lust_inl_mo_(lust_o_));                                 \
        (void)0;                                                                                        \
    })
#define lust_at_store_1(p, v, o, loc) lust_inl_store_(1, uint8_t, p, v, o, loc)
#define lust_at_store_2(p, v, o, loc) lust_inl_store_(2, uint16_t, p, v, o, loc)
#define lust_at_store_4(p, v, o, loc) lust_inl_store_(4, uint32_t, p, v, o, loc)
#define lust_at_store_8(p, v, o, loc) lust_inl_store_(8, uint64_t, p, v, o, loc)
#define lust_inl_cas_(N, U, p, cur, nv, s, f, old, weak)                                                \
    __extension__({                                                                                     \
        U *lust_p_ = (p);                                                                               \
        U lust_c_ = (cur), lust_n_ = (nv);                                                              \
        uint32_t lust_s_ = (s), lust_f_ = (f);                                                          \
        U *lust_old_ = (old);                                                                           \
        int lust_w_ = (weak), lust_ok_;                                                                 \
        if (__builtin_expect(lust_f_ == 1 || lust_f_ == 3, 0)) {                                        \
            lust_ok_ = lust_at_cas_##N(lust_p_, lust_c_, lust_n_, lust_s_, lust_f_, lust_old_, lust_w_); \
        } else {                                                                                        \
            U lust_e_ = lust_c_;                                                                        \
            lust_ok_ = __atomic_compare_exchange_n(lust_p_, &lust_e_, lust_n_, 0, lust_inl_mo_cas_(lust_s_, lust_f_), lust_inl_mo_(lust_f_)); \
            *lust_old_ = lust_e_;                                                                       \
        }                                                                                               \
        lust_ok_;                                                                                       \
    })
#define lust_at_cas_1(p, c, n, s, f, o, w) lust_inl_cas_(1, uint8_t, p, c, n, s, f, o, w)
#define lust_at_cas_2(p, c, n, s, f, o, w) lust_inl_cas_(2, uint16_t, p, c, n, s, f, o, w)
#define lust_at_cas_4(p, c, n, s, f, o, w) lust_inl_cas_(4, uint32_t, p, c, n, s, f, o, w)
#define lust_at_cas_8(p, c, n, s, f, o, w) lust_inl_cas_(8, uint64_t, p, c, n, s, f, o, w)
#define lust_at_swap_1(p, v, o) __atomic_exchange_n((p), (v), lust_inl_mo_(o))
#define lust_at_swap_2(p, v, o) __atomic_exchange_n((p), (v), lust_inl_mo_(o))
#define lust_at_swap_4(p, v, o) __atomic_exchange_n((p), (v), lust_inl_mo_(o))
#define lust_at_swap_8(p, v, o) __atomic_exchange_n((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_add_1(p, v, o) __atomic_fetch_add((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_add_2(p, v, o) __atomic_fetch_add((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_add_4(p, v, o) __atomic_fetch_add((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_add_8(p, v, o) __atomic_fetch_add((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_sub_1(p, v, o) __atomic_fetch_sub((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_sub_2(p, v, o) __atomic_fetch_sub((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_sub_4(p, v, o) __atomic_fetch_sub((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_sub_8(p, v, o) __atomic_fetch_sub((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_and_1(p, v, o) __atomic_fetch_and((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_and_2(p, v, o) __atomic_fetch_and((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_and_4(p, v, o) __atomic_fetch_and((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_and_8(p, v, o) __atomic_fetch_and((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_or_1(p, v, o) __atomic_fetch_or((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_or_2(p, v, o) __atomic_fetch_or((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_or_4(p, v, o) __atomic_fetch_or((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_or_8(p, v, o) __atomic_fetch_or((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_xor_1(p, v, o) __atomic_fetch_xor((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_xor_2(p, v, o) __atomic_fetch_xor((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_xor_4(p, v, o) __atomic_fetch_xor((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_xor_8(p, v, o) __atomic_fetch_xor((p), (v), lust_inl_mo_(o))

/* Bit counts with the compiler's builtins (the runtime loops for tcc; same results). */
#define lust_count_ones64(v) ((uint32_t)__builtin_popcountll((uint64_t)(v)))
#define lust_trailing_zeros64(v, bits)                                                                 \
    __extension__({                                                                                    \
        uint64_t lust_v_ = (v);                                                                        \
        uint32_t lust_b_ = (bits), lust_n_ = lust_v_ ? (uint32_t)__builtin_ctzll(lust_v_) : lust_b_;   \
        lust_n_ < lust_b_ ? lust_n_ : lust_b_;                                                         \
    })

/* Narrow division and remainder: zero (and MIN / -1) take the function, which panics. */
#define lust_inl_divu_(T, N, op, a, b, loc) \
    __extension__({ T lust_a_ = (a), lust_d_ = (b); __builtin_expect(lust_d_ != 0, 1) ? (T)(lust_a_ op lust_d_) : N(lust_a_, lust_d_, (loc)); })
#define lust_inl_divs_(T, MINV, N, op, a, b, loc)                                                       \
    __extension__({                                                                                     \
        T lust_a_ = (a), lust_d_ = (b);                                                                 \
        __builtin_expect(lust_d_ != 0 && !(lust_a_ == (MINV) && lust_d_ == -1), 1) ? (T)(lust_a_ op lust_d_) : N(lust_a_, lust_d_, (loc)); \
    })
#define lust_div_u8(a, b, loc) lust_inl_divu_(uint8_t, lust_div_u8, /, a, b, loc)
#define lust_rem_u8(a, b, loc) lust_inl_divu_(uint8_t, lust_rem_u8, %, a, b, loc)
#define lust_div_u16(a, b, loc) lust_inl_divu_(uint16_t, lust_div_u16, /, a, b, loc)
#define lust_rem_u16(a, b, loc) lust_inl_divu_(uint16_t, lust_rem_u16, %, a, b, loc)
#define lust_div_u32(a, b, loc) lust_inl_divu_(uint32_t, lust_div_u32, /, a, b, loc)
#define lust_rem_u32(a, b, loc) lust_inl_divu_(uint32_t, lust_rem_u32, %, a, b, loc)
#define lust_div_i8(a, b, loc) lust_inl_divs_(int8_t, -128, lust_div_i8, /, a, b, loc)
#define lust_rem_i8(a, b, loc) lust_inl_divs_(int8_t, -128, lust_rem_i8, %, a, b, loc)
#define lust_div_i16(a, b, loc) lust_inl_divs_(int16_t, -32768, lust_div_i16, /, a, b, loc)
#define lust_rem_i16(a, b, loc) lust_inl_divs_(int16_t, -32768, lust_rem_i16, %, a, b, loc)
#define lust_div_i32(a, b, loc) lust_inl_divs_(int32_t, -2147483647 - 1, lust_div_i32, /, a, b, loc)
#define lust_rem_i32(a, b, loc) lust_inl_divs_(int32_t, -2147483647 - 1, lust_rem_i32, %, a, b, loc)

/* An uncontended Mutex lock or unlock: one compare-exchange; a contended one (a waiter to
   wake, a wait) takes the function. */
#define lust_mutex_lock(st)                                                                             \
    __extension__({                                                                                     \
        uint32_t *lust_st_ = (st), lust_z_ = 0;                                                         \
        if (!__builtin_expect(__atomic_compare_exchange_n(lust_st_, &lust_z_, 1, 0, __ATOMIC_ACQUIRE, __ATOMIC_RELAXED), 1)) \
            lust_mutex_lock(lust_st_);                                                                  \
        (void)0;                                                                                        \
    })
#define lust_mutex_unlock(st)                                                                           \
    __extension__({                                                                                     \
        uint32_t *lust_st_ = (st), lust_one_ = 1;                                                       \
        if (!__builtin_expect(__atomic_compare_exchange_n(lust_st_, &lust_one_, 0, 0, __ATOMIC_RELEASE, __ATOMIC_RELAXED), 1)) \
            lust_mutex_unlock(lust_st_);                                                                \
        (void)0;                                                                                        \
    })

/* An empty Vec with no allocation (its dangling pointer is the alignment). */
#define lust_vec_with_capacity(n, elem, align)                                                         \
    __extension__({                                                                                    \
        uint64_t lust_n_ = (n), lust_e_ = (elem), lust_al_ = (align);                                  \
        __builtin_expect(lust_n_ == 0 && lust_e_ != 0, 1)                                              \
            ? (lust_Vec){(void *)(uintptr_t)(lust_al_ ? lust_al_ : 1), 0, 0}                           \
            : lust_vec_with_capacity(lust_n_, lust_e_, lust_al_);                                      \
    })

/* A str slice range in bounds with both ends on char boundaries; the function panics in
   Rust's order otherwise. */
#define lust_str_range(ptr, lo, hi, inclusive, len, loc)                                               \
    __extension__({                                                                                    \
        const uint8_t *lust_sp_ = (ptr);                                                               \
        uint64_t lust_lo_ = (lo), lust_hi_ = (hi), lust_len_ = (len);                                  \
        int lust_inc_ = (inclusive);                                                                   \
        uint64_t lust_end_ = lust_inc_ && lust_hi_ < lust_len_ ? lust_hi_ + 1 : lust_hi_;              \
        __builtin_expect(lust_lo_ <= lust_end_ && lust_end_ <= lust_len_ && !(lust_inc_ && lust_hi_ == lust_len_) \
                             && (lust_lo_ == lust_len_ || (lust_sp_[lust_lo_] & 0xC0) != 0x80)        \
                             && (lust_end_ == lust_len_ || (lust_sp_[lust_end_] & 0xC0) != 0x80), 1)  \
            ? lust_end_                                                                                \
            : lust_str_range(lust_sp_, lust_lo_, lust_hi_, lust_inc_, lust_len_, (loc));               \
    })

#define lust_string_as_str(s) __extension__({ lust_String *lust_s_ = (s); (lust_str){lust_s_->ptr, lust_s_->len}; })
#define lust_str_eq(...)                                                                               \
    __extension__({                                                                                    \
        struct { lust_str a, b; } lust_x_ = {__VA_ARGS__};                                             \
        (uint8_t)(lust_x_.a.len == lust_x_.b.len                                                       \
                  && (lust_x_.a.len == 0 || __builtin_memcmp(lust_x_.a.ptr, lust_x_.b.ptr, lust_x_.a.len) == 0)); \
    })

/* A thread-local's cell once the thread made it: thread.c's lust_tls_fast holds the cell
   pointers of the slots below LUST_TLS_FAST (one indexed thread-local load); a slot past it,
   or a cell this thread has not made yet, takes the function. */
extern __thread void *lust_tls_fast[];
#define lust_tls_cell(key, size, align)                                                                \
    __extension__({                                                                                    \
        uint64_t *lust_k_ = (key), lust_s_ = *lust_k_;                                                 \
        void *lust_c_ = __builtin_expect(lust_s_ < LUST_TLS_FAST, 1) ? lust_tls_fast[lust_s_] : (void *)0; \
        __builtin_expect(lust_c_ != 0, 1) ? lust_c_ : lust_tls_cell(lust_k_, (size), (align));         \
    })

/* Checked add, sub and mul of 64-bit and narrower integers (op 0, 1, 2) with the
   compiler's overflow builtins; division and 128 bits take the function. As the
   function: the wrapped result, masked to `bits`, goes to *out; 1 when it fits. */
#define lust_checked_op(a, b, bits, is_signed, op, out)                                                \
    __extension__({                                                                                    \
        uint64_t lust_a_ = (a), lust_b_ = (b), *lust_o_ = (out);                                       \
        unsigned lust_n_ = (bits);                                                                     \
        int lust_sg_ = (is_signed), lust_op_ = (op), lust_ok_;                                         \
        if (lust_n_ == 64 && lust_op_ <= 2 && lust_sg_) {                                              \
            int64_t lust_r_, lust_x_ = (int64_t)lust_a_, lust_y_ = (int64_t)lust_b_;                   \
            lust_ok_ = !(lust_op_ == 0   ? __builtin_add_overflow(lust_x_, lust_y_, &lust_r_)           \
                         : lust_op_ == 1 ? __builtin_sub_overflow(lust_x_, lust_y_, &lust_r_)           \
                                         : __builtin_mul_overflow(lust_x_, lust_y_, &lust_r_));         \
            *lust_o_ = (uint64_t)lust_r_;                                                              \
        } else if (lust_n_ == 64 && lust_op_ <= 2) {                                                   \
            uint64_t lust_r_;                                                                          \
            lust_ok_ = !(lust_op_ == 0   ? __builtin_add_overflow(lust_a_, lust_b_, &lust_r_)           \
                         : lust_op_ == 1 ? __builtin_sub_overflow(lust_a_, lust_b_, &lust_r_)           \
                                         : __builtin_mul_overflow(lust_a_, lust_b_, &lust_r_));         \
            *lust_o_ = lust_r_;                                                                        \
        } else if (lust_n_ <= 32 && lust_op_ <= 2) {                                                   \
            /* Exact in 64 bits: the result fits when it is in the type's range. */                   \
            uint64_t lust_m_ = (1ull << lust_n_) - 1ull;                                               \
            lust_a_ &= lust_m_;                                                                        \
            lust_b_ &= lust_m_;                                                                        \
            if (lust_sg_) {                                                                            \
                uint64_t lust_h_ = 1ull << (lust_n_ - 1);                                              \
                int64_t lust_x_ = (int64_t)((lust_a_ ^ lust_h_) - lust_h_), lust_y_ = (int64_t)((lust_b_ ^ lust_h_) - lust_h_); \
                int64_t lust_r_ = lust_op_ == 0 ? lust_x_ + lust_y_ : lust_op_ == 1 ? lust_x_ - lust_y_ : lust_x_ * lust_y_; \
                *lust_o_ = (uint64_t)lust_r_ & lust_m_;                                                \
                lust_ok_ = lust_r_ >= -(int64_t)lust_h_ && lust_r_ < (int64_t)lust_h_;                 \
            } else {                                                                                   \
                uint64_t lust_r_ = lust_op_ == 0 ? lust_a_ + lust_b_ : lust_op_ == 1 ? lust_a_ - lust_b_ : lust_a_ * lust_b_; \
                *lust_o_ = lust_r_ & lust_m_;                                                          \
                lust_ok_ = lust_op_ == 1 ? lust_a_ >= lust_b_ : lust_r_ <= lust_m_;                    \
            }                                                                                          \
        } else                                                                                         \
            lust_ok_ = lust_checked_op(lust_a_, lust_b_, lust_n_, lust_sg_, lust_op_, lust_o_);         \
        lust_ok_;                                                                                      \
    })

#ifdef __SIZEOF_INT128__
/* 128-bit compares, products and shifts with the compiler's __int128 (the functions
   build them from 64-bit halves). A shift of 128 or more takes the function. */
#define lust_inl_w_(x) (((unsigned __int128)(x).hi << 64) | (x).lo)
#define lust_inl_u128_of_(v)                                                                           \
    __extension__({                                                                                    \
        unsigned __int128 lust_w_ = (v);                                                               \
        (lust_u128){(uint64_t)lust_w_, (uint64_t)(lust_w_ >> 64)};                                     \
    })
#define lust_u128_cmp(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_u128 a, b; } lust_x_ = {__VA_ARGS__};                                            \
        unsigned __int128 lust_l_ = lust_inl_w_(lust_x_.a), lust_r_ = lust_inl_w_(lust_x_.b);          \
        (int32_t)((lust_l_ > lust_r_) - (lust_l_ < lust_r_));                                          \
    })
#define lust_i128_cmp(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_i128 a, b; } lust_x_ = {__VA_ARGS__};                                            \
        __int128 lust_l_ = (__int128)lust_inl_w_(lust_x_.a), lust_r_ = (__int128)lust_inl_w_(lust_x_.b); \
        (int32_t)((lust_l_ > lust_r_) - (lust_l_ < lust_r_));                                          \
    })
#define lust_u128_mul(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_u128 a, b; } lust_x_ = {__VA_ARGS__};                                            \
        lust_inl_u128_of_(lust_inl_w_(lust_x_.a) * lust_inl_w_(lust_x_.b));                            \
    })
#define lust_i128_mul(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_i128 a, b; } lust_x_ = {__VA_ARGS__};                                            \
        lust_u128 lust_p_ = lust_inl_u128_of_(lust_inl_w_(lust_x_.a) * lust_inl_w_(lust_x_.b));        \
        (lust_i128){lust_p_.lo, lust_p_.hi};                                                           \
    })
#define lust_u128_shl(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_u128 a; uint32_t n; } lust_x_ = {__VA_ARGS__};                                   \
        __builtin_expect(lust_x_.n < 128, 1) ? lust_inl_u128_of_(lust_inl_w_(lust_x_.a) << lust_x_.n)  \
                                             : lust_u128_shl(lust_x_.a, lust_x_.n);                    \
    })
#define lust_u128_shr(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_u128 a; uint32_t n; } lust_x_ = {__VA_ARGS__};                                   \
        __builtin_expect(lust_x_.n < 128, 1) ? lust_inl_u128_of_(lust_inl_w_(lust_x_.a) >> lust_x_.n)  \
                                             : lust_u128_shr(lust_x_.a, lust_x_.n);                    \
    })
/* Wrapping 128-bit add and sub, and the bitwise ops. */
#define lust_inl_u128_op_(T, op, ...)                                                                  \
    __extension__({                                                                                    \
        struct { T a, b; } lust_x_ = {__VA_ARGS__};                                                    \
        lust_u128 lust_r_ = lust_inl_u128_of_(lust_inl_w_(lust_x_.a) op lust_inl_w_(lust_x_.b));       \
        (T){lust_r_.lo, lust_r_.hi};                                                                   \
    })
#define lust_u128_add(...) lust_inl_u128_op_(lust_u128, +, __VA_ARGS__)
#define lust_u128_sub(...) lust_inl_u128_op_(lust_u128, -, __VA_ARGS__)
#define lust_i128_add(...) lust_inl_u128_op_(lust_i128, +, __VA_ARGS__)
#define lust_i128_sub(...) lust_inl_u128_op_(lust_i128, -, __VA_ARGS__)
#define lust_u128_and(...) lust_inl_u128_op_(lust_u128, &, __VA_ARGS__)
#define lust_u128_or(...) lust_inl_u128_op_(lust_u128, |, __VA_ARGS__)
#define lust_u128_xor(...) lust_inl_u128_op_(lust_u128, ^, __VA_ARGS__)
#endif

/* Small helpers that every unit called out of line: on tsgo's pgo-train they ran 200 M
   calls of 2 to 40 instructions each. Each keeps its function's arguments and result;
   a panic or a slow case calls the function. */

/* A hash table's item count and capacity (hash.c). */
#define lust_hash_len(t) __extension__({ const lust_hash_table *lust_t_ = (t); lust_t_->items; })
#define lust_hash_capacity(t) __extension__({ const lust_hash_table *lust_t_ = (t); lust_t_->items + lust_t_->growth_left; })
#define lust_hash_is_empty(t) __extension__({ const lust_hash_table *lust_t_ = (t); (int)(lust_t_->items == 0); })
/* The empty table with no allocation, as the function makes it. */
#define lust_hash_init(t, size, align)                                                                 \
    __extension__({                                                                                    \
        lust_hash_table *lust_t_ = (t);                                                                \
        uint64_t lust_al_ = (align);                                                                   \
        lust_t_->elem_size = (size);                                                                   \
        lust_t_->elem_align = lust_al_ ? lust_al_ : 1;                                                 \
        lust_t_->ctrl = (uint8_t *)lust_hash_static_empty;                                             \
        lust_t_->data = 0;                                                                             \
        lust_t_->alloc_base = 0;                                                                       \
        lust_t_->bucket_mask = 0;                                                                      \
        lust_t_->items = 0;                                                                            \
        lust_t_->growth_left = 0;                                                                      \
        (void)0;                                                                                       \
    })
/* A table with no allocation is the empty one: nothing to drop or free. */
#define lust_hash_drop_table(t, drop, ctx)                                                             \
    __extension__({                                                                                    \
        lust_hash_table *lust_t_ = (t);                                                                \
        if (!(lust_t_->alloc_base == 0 && lust_t_->items == 0)) lust_hash_drop_table(lust_t_, (drop), (ctx)); \
        (void)0;                                                                                       \
    })

/* An index in bounds is the result; the function panics with Rust's message otherwise. */
#define lust_bounds(i, len, loc)                                                                       \
    __extension__({                                                                                    \
        uint64_t lust_i_ = (i), lust_n_ = (len);                                                       \
        __builtin_expect(lust_i_ < lust_n_, 1) ? lust_i_ : lust_bounds(lust_i_, lust_n_, (loc));       \
    })
#define lust_vec_check_remove(v, i, loc)                                                               \
    __extension__({                                                                                    \
        lust_Vec *lust_v_ = (v);                                                                       \
        uint64_t lust_i_ = (i);                                                                        \
        if (__builtin_expect(lust_i_ >= lust_v_->len, 0)) lust_vec_check_remove(lust_v_, lust_i_, (loc)); \
        (void)0;                                                                                       \
    })

/* The char at *i of valid UTF-8, and *i moved past it: an ASCII byte here, a wider char
   in the function. */
#define lust_utf8_next(p, i)                                                                           \
    __extension__({                                                                                    \
        const uint8_t *lust_p_ = (p);                                                                  \
        uint64_t *lust_i_ = (i);                                                                       \
        uint8_t lust_b_ = lust_p_[*lust_i_];                                                           \
        __builtin_expect(lust_b_ < 0x80, 1) ? (*lust_i_ += 1, (uint32_t)lust_b_) : lust_utf8_next(lust_p_, lust_i_); \
    })
#define lust_chars(...) __extension__({ struct { lust_str s; } lust_x_ = {__VA_ARGS__}; (lust_Chars){lust_x_.s, 0}; })
#define lust_str_starts_with(...)                                                                      \
    __extension__({                                                                                    \
        struct { lust_str s, p; } lust_x_ = {__VA_ARGS__};                                             \
        (uint8_t)(lust_x_.p.len <= lust_x_.s.len                                                       \
                  && (lust_x_.p.len == 0 || __builtin_memcmp(lust_x_.s.ptr, lust_x_.p.ptr, lust_x_.p.len) == 0)); \
    })
#define lust_str_ends_with(...)                                                                        \
    __extension__({                                                                                    \
        struct { lust_str s, p; } lust_x_ = {__VA_ARGS__};                                             \
        (uint8_t)(lust_x_.p.len <= lust_x_.s.len                                                       \
                  && (lust_x_.p.len == 0                                                               \
                      || __builtin_memcmp(lust_x_.s.ptr + lust_x_.s.len - lust_x_.p.len, lust_x_.p.ptr, lust_x_.p.len) == 0)); \
    })

/* A range's start and end in a slice of `len` (`get(range)`), as core.c's function: the
   tags give each end's kind (end: 0 included, 1 excluded, 2 none; start: 0 included,
   1 excluded, 2 none); 0 when the range does not fit. */
static inline int lust_inl_range_bounds_get_(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val,
                                             uint64_t *out_s, uint64_t *out_e) {
    uint64_t end, start;
    if (e_tag == 0) {
        if (e_val >= len) return 0;
        end = e_val + 1;
    } else if (e_tag == 1) {
        if (e_val > len) return 0;
        end = e_val;
    } else {
        end = len;
    }
    if (s_tag == 2) {
        start = 0;
    } else if (s_tag == 1) {
        if (s_val >= end) return 0;
        start = s_val + 1;
    } else {
        if (s_val > end) return 0;
        start = s_val;
    }
    *out_s = start;
    *out_e = end;
    return 1;
}
#define lust_range_bounds_get(...) lust_inl_range_bounds_get_(__VA_ARGS__)

/* Allocation: malloc for a nonzero size at an alignment malloc gives; zero sizes, larger
   alignments and a failed malloc (the function retries, then reports it) take the
   function. (__builtin_malloc calls malloc; units declare no malloc of their own, and a
   program's own extern malloc may declare it with other types.) free for a nonzero size,
   but Windows' over-aligned blocks. */
#define lust_alloc(size, align)                                                                        \
    __extension__({                                                                                    \
        uint64_t lust_sz_ = (size), lust_al_ = (align);                                                \
        void *lust_r_ = __builtin_expect(lust_sz_ != 0 && lust_al_ <= 16, 1) ? __builtin_malloc(lust_sz_) : 0; \
        __builtin_expect(lust_r_ != 0, 1) ? lust_r_ : lust_alloc(lust_sz_, lust_al_);                  \
    })
#ifdef _WIN32
#define lust_inl_aligned_free_(align) ((align) > 16)
#else
#define lust_inl_aligned_free_(align) 0
#endif
#define lust_dealloc(ptr, size, align)                                                                 \
    __extension__({                                                                                    \
        void *lust_p_ = (ptr);                                                                         \
        uint64_t lust_sz_ = (size), lust_al_ = (align);                                                \
        if (lust_sz_) {                                                                                \
            if (lust_inl_aligned_free_(lust_al_)) lust_dealloc(lust_p_, lust_sz_, lust_al_);           \
            else free(lust_p_);                                                                        \
        }                                                                                              \
        (void)0;                                                                                       \
    })

/* Strings: the empty one, drop, and a push that fits the capacity (growth takes the
   function). */
#define lust_string_new() ((lust_String){(uint8_t *)(uintptr_t)1, 0, 0})
#define lust_string_drop(s) __extension__({ lust_String *lust_s_ = (s); lust_dealloc(lust_s_->ptr, lust_s_->cap, 1); })
#define lust_string_push_str(s, ...)                                                                   \
    __extension__({                                                                                    \
        lust_String *lust_s_ = (s);                                                                    \
        struct { lust_str x; } lust_x_ = {__VA_ARGS__};                                                \
        if (__builtin_expect(lust_s_->cap - lust_s_->len >= lust_x_.x.len, 1)) {                       \
            if (lust_x_.x.len) __builtin_memcpy(lust_s_->ptr + lust_s_->len, lust_x_.x.ptr, lust_x_.x.len); \
            lust_s_->len += lust_x_.x.len;                                                             \
        } else                                                                                         \
            lust_string_push_str(lust_s_, lust_x_.x);                                                  \
        (void)0;                                                                                       \
    })
#define lust_string_push_char(s, c)                                                                    \
    __extension__({                                                                                    \
        lust_String *lust_s_ = (s);                                                                    \
        uint32_t lust_c_ = (c);                                                                        \
        if (__builtin_expect(lust_c_ < 0x80 && lust_s_->len < lust_s_->cap, 1))                        \
            lust_s_->ptr[lust_s_->len++] = (uint8_t)lust_c_;                                           \
        else                                                                                           \
            lust_string_push_char(lust_s_, lust_c_);                                                   \
        (void)0;                                                                                       \
    })

/* f64 and f32 min and max as float.c: a NaN loses to a number, and of two equal values
   (0.0 and -0.0) the second wins. The integer to float casts round to nearest, ties to
   even, as Rust's `as` (the runtime builds them from integer steps for tcc). */
static inline double lust_inl_f64_min_(double a, double b) { return a < b ? a : b < a ? b : a == b ? b : a == a ? a : b; }
static inline double lust_inl_f64_max_(double a, double b) { return a > b ? a : b > a ? b : a == b ? b : a == a ? a : b; }
static inline float lust_inl_f32_min_(float a, float b) { return a < b ? a : b < a ? b : a == b ? b : a == a ? a : b; }
static inline float lust_inl_f32_max_(float a, float b) { return a > b ? a : b > a ? b : a == b ? b : a == a ? a : b; }
#define lust_f64_min(a, b) lust_inl_f64_min_((a), (b))
#define lust_f64_max(a, b) lust_inl_f64_max_((a), (b))
#define lust_f32_min(a, b) lust_inl_f32_min_((a), (b))
#define lust_f32_max(a, b) lust_inl_f32_max_((a), (b))
#define lust_u64_to_f64(v) ((double)(uint64_t)(v))
#define lust_i64_to_f64(v) ((double)(int64_t)(v))
#endif

/* `p` is a reference made just before (Rust's validity invariant: never null). cgen states
   it only on the path that makes the reference, never on a pointer that may be null: a slice
   element `&ptr[i]` inside its bounds check, the payload of a `Some(r)` the program builds.
   A later niche check of the `Option<&T>` (`p != 0`) then folds. tcc ignores it. */
#if !defined(__TINYC__)
#define lust_ref_nn(p)                       \
    do {                                     \
        if (!(p)) __builtin_unreachable();   \
    } while (0)
#else
#define lust_ref_nn(p) ((void)0)
#endif

/* A release fn's constant data named by its content (cgen/kconst.rs `kdata_def`): each unit
   that uses it defines it, and the link keeps one definition, so equal constants share one
   address program-wide with no run-time interning. clang's selectany is a comdat (weak_odr):
   its value folds into the code that reads it, as a constant's does (a compare with a
   promoted enum constant is a compare with an immediate). A plain weak definition (gcc)
   keeps the identity but not the folding. */
#if defined(_WIN32)
#define LUST_KDATA __declspec(selectany)
#elif defined(__clang__)
#define LUST_KDATA __attribute__((selectany, visibility("hidden")))
#else
#define LUST_KDATA __attribute__((weak, visibility("hidden")))
#endif

extern const uint64_t lust_so_0089922f873e38d8;
extern const uint64_t lust_so_00b418e2a8d3f4dd;
extern const uint64_t lust_so_021870c95b651de6;
extern const uint64_t lust_so_03be07e6f84a9a13;
extern const uint64_t lust_so_04e9e8efe4aca037;
extern const uint64_t lust_so_06edc7502cf7934b;
extern const uint64_t lust_so_07a3bf7807baa7ae;
extern const uint64_t lust_so_09e3e50757e03460;
extern const uint64_t lust_so_09eb54041f570968;
extern const uint64_t lust_so_0a8b4f0ce09f0f96;
extern const uint64_t lust_so_0b073575bb69bcd4;
extern const uint64_t lust_so_0bbf87d9ee5e1780;
extern const uint64_t lust_so_0c27d1821e7e4708;
extern const uint64_t lust_so_0c57b10e9de4dd8c;
extern const uint64_t lust_so_0c702a05f888b9b5;
extern const uint64_t lust_so_0c7edc7c286c654b;
extern const uint64_t lust_so_0d0197cb01c4fe35;
extern const uint64_t lust_so_0d06ace48c74648b;
extern const uint64_t lust_so_12702f75bc3606fc;
extern const uint64_t lust_so_12ac54cbfedf3848;
extern const uint64_t lust_so_133fab019df5590f;
extern const uint64_t lust_so_13e778d589c9a46d;
extern const uint64_t lust_so_13ed921ecad8edea;
extern const uint64_t lust_so_1463cb8c99acbf3d;
extern const uint64_t lust_so_1868532e2a981b6f;
extern const uint64_t lust_so_1872984064d4f18e;
extern const uint64_t lust_so_18da39ea0dcd4fe7;
extern const uint64_t lust_so_1c09d099eb34e949;
extern const uint64_t lust_so_1c9278ae0079e571;
extern const uint64_t lust_so_1fe405fd40cfd6c6;
extern const uint64_t lust_so_2078ff17ac329a01;
extern const uint64_t lust_so_240f7fa254e78590;
extern const uint64_t lust_so_24b8bd7af0f45da5;
extern const uint64_t lust_so_253a7c9afe971794;
extern const uint64_t lust_so_29c6b9c153875659;
extern const uint64_t lust_so_29cce92e2bece48a;
extern const uint64_t lust_so_2a25936bc256da60;
extern const uint64_t lust_so_2b593d17738a060e;
extern const uint64_t lust_so_2c6f8781d6a6b594;
extern const uint64_t lust_so_2cd42e81d294ab1f;
extern const uint64_t lust_so_2d1c1333514d7c13;
extern const uint64_t lust_so_2d3296892bfdaa34;
extern const uint64_t lust_so_2e5694287e99ac3e;
extern const uint64_t lust_so_2ef263ab7f066864;
extern const uint64_t lust_so_2f2e9ac6ca7c78c1;
extern const uint64_t lust_so_2fe4355853ebd629;
extern const uint64_t lust_so_2fe5f5234fa44b6a;
extern const uint64_t lust_so_30d693ef8a8db365;
extern const uint64_t lust_so_31c07aa50b393194;
extern const uint64_t lust_so_329644254774d78c;
extern const uint64_t lust_so_338c781c688b5d6d;
extern const uint64_t lust_so_35a32cffcbb8f7b3;
extern const uint64_t lust_so_3632e762da5fb136;
extern const uint64_t lust_so_3754d36cda7d7a79;
extern const uint64_t lust_so_37eb6940323b7aab;
extern const uint64_t lust_so_37f5a0002796d4b4;
extern const uint64_t lust_so_38a0d0624b76abbb;
extern const uint64_t lust_so_3ba466fb37ed500b;
extern const uint64_t lust_so_3f4ec28af0af87ed;
extern const uint64_t lust_so_41cbbd13fba6099f;
extern const uint64_t lust_so_420570dd4f5fee14;
extern const uint64_t lust_so_47299ff23f5ec4ae;
extern const uint64_t lust_so_489e92cc79eda2fd;
extern const uint64_t lust_so_49e54edf4370e849;
extern const uint64_t lust_so_4a2c23f4f2a4c7bf;
extern const uint64_t lust_so_4a95db6a3015731d;
extern const uint64_t lust_so_4c12e097fbcce7de;
extern const uint64_t lust_so_4c2f085d58548f35;
extern const uint64_t lust_so_4e1722ac4a504ac5;
extern const uint64_t lust_so_509605bb3d21c548;
extern const uint64_t lust_so_52b7748b7e03b126;
extern const uint64_t lust_so_5352b14911e9db26;
extern const uint64_t lust_so_58ea2a62b0dd5957;
extern const uint64_t lust_so_5ac1125d8167d346;
extern const uint64_t lust_so_5ad1fa64abc416bb;
extern const uint64_t lust_so_5c13314d65f7070e;
extern const uint64_t lust_so_5c7925721244787b;
extern const uint64_t lust_so_5c9dc143e9da7d53;
extern const uint64_t lust_so_5d2dbb14d0ce22e9;
extern const uint64_t lust_so_620db28fc978a369;
extern const uint64_t lust_so_620f1bd5908429b9;
extern const uint64_t lust_so_63d14ca54dee12cd;
extern const uint64_t lust_so_6495393e0ec64505;
extern const uint64_t lust_so_655ce0fd6e9f8f21;
extern const uint64_t lust_so_658c60881d177a73;
extern const uint64_t lust_so_6661133ec689e76c;
extern const uint64_t lust_so_66bc2c4972581d52;
extern const uint64_t lust_so_695bb3edb1c10eb8;
extern const uint64_t lust_so_69a89510a8e19608;
extern const uint64_t lust_so_69c4f02c4698d6f5;
extern const uint64_t lust_so_6a83568fec5e815a;
extern const uint64_t lust_so_6acbb85cbb2e7d8e;
extern const uint64_t lust_so_6afdaa287dc7b46d;
extern const uint64_t lust_so_6bbf40f32abb7d72;
extern const uint64_t lust_so_6e04c532a433cced;
extern const uint64_t lust_so_6e187b64e783cbf8;
extern const uint64_t lust_so_6e1944b2fe6a358b;
extern const uint64_t lust_so_6e4405b3ba9ae8cd;
extern const uint64_t lust_so_6e45a74d048deb19;
extern const uint64_t lust_so_6e8e244a2fa8357b;
extern const uint64_t lust_so_6f463f8753b25553;
extern const uint64_t lust_so_70290558c3854fb9;
extern const uint64_t lust_so_70af7dfa8b9d5d33;
extern const uint64_t lust_so_70c48a1a8c6adfa7;
extern const uint64_t lust_so_726003d7a130b8a9;
extern const uint64_t lust_so_7646620f1a99865a;
extern const uint64_t lust_so_7885811ac870d212;
extern const uint64_t lust_so_7947f7854c604f66;
extern const uint64_t lust_so_7a2851b1a45f0f15;
extern const uint64_t lust_so_7a53a66349ac8302;
extern const uint64_t lust_so_7a81356a3e150afd;
extern const uint64_t lust_so_7bee5a0bfe87fd27;
extern const uint64_t lust_so_7c78f9001fb6fea4;
extern const uint64_t lust_so_7d99980989f90053;
extern const uint64_t lust_so_80222bab3a20ea13;
extern const uint64_t lust_so_81d4ea5193d167c0;
extern const uint64_t lust_so_84163f41f2e2fddd;
extern const uint64_t lust_so_84dc7988b9ff66c9;
extern const uint64_t lust_so_856b31d595c4b589;
extern const uint64_t lust_so_8616e1dd2ab461d5;
extern const uint64_t lust_so_87cff378ae434a46;
extern const uint64_t lust_so_891a81977881c6eb;
extern const uint64_t lust_so_89ac733e4914b098;
extern const uint64_t lust_so_89d4af82d3c42b68;
extern const uint64_t lust_so_8a71922da969ce56;
extern const uint64_t lust_so_8be47e3af2fd50aa;
extern const uint64_t lust_so_8e6c4336ffc258d8;
extern const uint64_t lust_so_8f70de8d9f99e53f;
extern const uint64_t lust_so_8fd9c15c0116fcfc;
extern const uint64_t lust_so_901569cf17c71ba8;
extern const uint64_t lust_so_911d6013f2c690ec;
extern const uint64_t lust_so_914347e29880b66e;
extern const uint64_t lust_so_9214820078ceddbb;
extern const uint64_t lust_so_9238399843afbaf0;
extern const uint64_t lust_so_92b5c190df1d8477;
extern const uint64_t lust_so_92ce47b1381db64b;
extern const uint64_t lust_so_936007394ada7049;
extern const uint64_t lust_so_943e8f8cf84336e8;
extern const uint64_t lust_so_95183369e473648f;
extern const uint64_t lust_so_95c7c5ed2791d8c7;
extern const uint64_t lust_so_96afa4b9bc140468;
extern const uint64_t lust_so_970944ee43a3b66f;
extern const uint64_t lust_so_99a5f75c4fcb0ec9;
extern const uint64_t lust_so_99dcd08403d20fe8;
extern const uint64_t lust_so_9c10ba922f7242ed;
extern const uint64_t lust_so_9cff13ec9a2dbb55;
extern const uint64_t lust_so_9d55f24516cc9be7;
extern const uint64_t lust_so_9d5e9281db73228e;
extern const uint64_t lust_so_9e761eba787a11a6;
extern const uint64_t lust_so_9ed5d1843e39fe4b;
extern const uint64_t lust_so_9f7c61b72e4fcc01;
extern const uint64_t lust_so_a0f8e459a09ace25;
extern const uint64_t lust_so_a14f74bd3e2d3b52;
extern const uint64_t lust_so_a17acf4a6dbfa03f;
extern const uint64_t lust_so_a1ae08b46d2329d8;
extern const uint64_t lust_so_a38bd19629179e77;
extern const uint64_t lust_so_a3f1b5fbf06821a7;
extern const uint64_t lust_so_a5063c8e6d67a08a;
extern const uint64_t lust_so_a50a8d99bac54be0;
extern const uint64_t lust_so_a75f823c083e9b55;
extern const uint64_t lust_so_aa87e869bcb3deb3;
extern const uint64_t lust_so_aaa278d3820d7c10;
extern const uint64_t lust_so_aaca894fd5dd8d5d;
extern const uint64_t lust_so_ab22ab135cfc7f03;
extern const uint64_t lust_so_ad04d27fc2cdfb3c;
extern const uint64_t lust_so_ad0eed563d6710a5;
extern const uint64_t lust_so_ad70c3c9ba5354fa;
extern const uint64_t lust_so_ada4b2b6dbfab747;
extern const uint64_t lust_so_adbf27a4aa538938;
extern const uint64_t lust_so_adbf9fc271314305;
extern const uint64_t lust_so_aeaa10c2868c2544;
extern const uint64_t lust_so_aede0641cd502851;
extern const uint64_t lust_so_aef4380f706b52b0;
extern const uint64_t lust_so_b0c323eee9cbbf8c;
extern const uint64_t lust_so_b0e5aa31ad01ca4e;
extern const uint64_t lust_so_b5497583b14d9758;
extern const uint64_t lust_so_b595fd324556fbba;
extern const uint64_t lust_so_b63f7579466b8d16;
extern const uint64_t lust_so_b74a6175129a725e;
extern const uint64_t lust_so_b8b23e37bef54b0c;
extern const uint64_t lust_so_bc6beedc491b2844;
extern const uint64_t lust_so_bdc4f598f746dc19;
extern const uint64_t lust_so_bde25bf2ae01c8a1;
extern const uint64_t lust_so_c2a46654f9cef801;
extern const uint64_t lust_so_c3ae8b0d935a77e5;
extern const uint64_t lust_so_c543dcb396a8aa3e;
extern const uint64_t lust_so_c6423313f96f0b06;
extern const uint64_t lust_so_c64403f64f6c81b1;
extern const uint64_t lust_so_c6638f0d95ea3dd3;
extern const uint64_t lust_so_c6c0593148877aa7;
extern const uint64_t lust_so_c6cea8fc00414c66;
extern const uint64_t lust_so_c79f5289847e038f;
extern const uint64_t lust_so_c7beb8261d6b69cd;
extern const uint64_t lust_so_c8ea4b882354f475;
extern const uint64_t lust_so_c9d35363888b9352;
extern const uint64_t lust_so_c9de8b76366ef0ad;
extern const uint64_t lust_so_cc223626cdf9f506;
extern const uint64_t lust_so_cd810979d9d91403;
extern const uint64_t lust_so_ce5002bd14c1ad21;
extern const uint64_t lust_so_cf3d129250fb9f97;
extern const uint64_t lust_so_cf77d6ac624225eb;
extern const uint64_t lust_so_cf8c94538d1bc2d3;
extern const uint64_t lust_so_cfb1cbd45320491a;
extern const uint64_t lust_so_d18a6c484a3658d5;
extern const uint64_t lust_so_d20f7f58fb2bfc8e;
extern const uint64_t lust_so_d3722509e8844953;
extern const uint64_t lust_so_d378c8c7e1032688;
extern const uint64_t lust_so_d3e6eb48954cf171;
extern const uint64_t lust_so_d4e70a7d5e27f6a1;
extern const uint64_t lust_so_d53ab81cf9d110cb;
extern const uint64_t lust_so_d55eeee98958238e;
extern const uint64_t lust_so_d5b3150a80e91f1a;
extern const uint64_t lust_so_d6b19d45cc583106;
extern const uint64_t lust_so_d7015c3f7e2c0086;
extern const uint64_t lust_so_d707b29152413470;
extern const uint64_t lust_so_d799bae7b1d71e42;
extern const uint64_t lust_so_d7d3446327da7cef;
extern const uint64_t lust_so_d93e6755e311ad3b;
extern const uint64_t lust_so_dba6d5be34aaeffb;
extern const uint64_t lust_so_dbe75b723c3e652a;
extern const uint64_t lust_so_dce795fb70dcd531;
extern const uint64_t lust_so_ddc7041e1c4192c8;
extern const uint64_t lust_so_ddff6c6a396f760c;
extern const uint64_t lust_so_e01d5f31b4d85cfb;
extern const uint64_t lust_so_e1ba5cf93f404e7c;
extern const uint64_t lust_so_e2dd255ed5ba577c;
extern const uint64_t lust_so_e4e5029593d65e5a;
extern const uint64_t lust_so_e4e717d2eef775c1;
extern const uint64_t lust_so_e4e91ccae01e4b9c;
extern const uint64_t lust_so_e54911916a943a85;
extern const uint64_t lust_so_e61724f7935ea8eb;
extern const uint64_t lust_so_e769b61a53b62242;
extern const uint64_t lust_so_e909122e4e7579ae;
extern const uint64_t lust_so_e9774056f07cacb8;
extern const uint64_t lust_so_e98d639fd11282c0;
extern const uint64_t lust_so_e9c4cb0543595e45;
extern const uint64_t lust_so_ea2b174b945b6a7d;
extern const uint64_t lust_so_ea4b82b4b5da741c;
extern const uint64_t lust_so_eb0e2947640f5dd0;
extern const uint64_t lust_so_ebf8b38da9e287d2;
extern const uint64_t lust_so_ef0f666527735563;
extern const uint64_t lust_so_f0497e5c9577df97;
extern const uint64_t lust_so_f0b2a02668219252;
extern const uint64_t lust_so_f222bcb220511850;
extern const uint64_t lust_so_f272ab7eeb43addd;
extern const uint64_t lust_so_f50cc8000839d113;
extern const uint64_t lust_so_f54fbe4a6a7a074f;
extern const uint64_t lust_so_f653010808001fef;
extern const uint64_t lust_so_f6f6b74f6101424e;
extern const uint64_t lust_so_f7b85ea6c34fd168;
extern const uint64_t lust_so_f7de1765bb06efd7;
extern const uint64_t lust_so_f8481ab24b3f511b;
extern const uint64_t lust_so_f86391d34a050e5e;
extern const uint64_t lust_so_f8dcb7425084658c;
extern const uint64_t lust_so_f9a7093afd8ecc61;
extern const uint64_t lust_so_fa713bfc79ead375;
extern const uint64_t lust_so_fa94b520e37fcf69;
extern const uint64_t lust_so_feb5c39f9b67e61a;
int64_t f_0089922f873e38d8(int64_t p1);
int64_t f_00b418e2a8d3f4dd(int64_t p1);
int64_t f_021870c95b651de6(int64_t p1);
int64_t f_03be07e6f84a9a13(int64_t p1);
int64_t f_04e9e8efe4aca037(int64_t p1);
int64_t f_06edc7502cf7934b(int64_t p1);
int64_t f_07a3bf7807baa7ae(int64_t p1);
int64_t f_09e3e50757e03460(int64_t p1);
int64_t f_09eb54041f570968(int64_t p1);
int64_t f_0a8b4f0ce09f0f96(int64_t p1);
int64_t f_0b073575bb69bcd4(int64_t p1);
int64_t f_0bbf87d9ee5e1780(int64_t p1);
int64_t f_0c27d1821e7e4708(int64_t p1);
int64_t f_0c57b10e9de4dd8c(int64_t p1);
int64_t f_0c702a05f888b9b5(int64_t p1);
int64_t f_0c7edc7c286c654b(int64_t p1);
int64_t f_0d0197cb01c4fe35(int64_t p1);
int64_t f_0d06ace48c74648b(int64_t p1);
int64_t f_12702f75bc3606fc(int64_t p1);
int64_t f_12ac54cbfedf3848(int64_t p1);
int64_t f_133fab019df5590f(int64_t p1);
int64_t f_13e778d589c9a46d(int64_t p1);
int64_t f_13ed921ecad8edea(int64_t p1);
int64_t f_1463cb8c99acbf3d(int64_t p1);
int64_t f_1868532e2a981b6f(int64_t p1);
int64_t f_1872984064d4f18e(int64_t p1);
int64_t f_18da39ea0dcd4fe7(int64_t p1);
int64_t f_1c09d099eb34e949(int64_t p1);
int64_t f_1c9278ae0079e571(int64_t p1);
int64_t f_1fe405fd40cfd6c6(int64_t p1);
int64_t f_2078ff17ac329a01(int64_t p1);
int64_t f_240f7fa254e78590(int64_t p1);
int64_t f_24b8bd7af0f45da5(int64_t p1);
int64_t f_253a7c9afe971794(int64_t p1);
int64_t f_29c6b9c153875659(int64_t p1);
int64_t f_29cce92e2bece48a(int64_t p1);
int64_t f_2a25936bc256da60(int64_t p1);
int64_t f_2b593d17738a060e(int64_t p1);
int64_t f_2c6f8781d6a6b594(int64_t p1);
int64_t f_2cd42e81d294ab1f(int64_t p1);
int64_t f_2d1c1333514d7c13(int64_t p1);
int64_t f_2d3296892bfdaa34(int64_t p1);
int64_t f_2e5694287e99ac3e(int64_t p1);
int64_t f_2ef263ab7f066864(int64_t p1);
int64_t f_2f2e9ac6ca7c78c1(int64_t p1);
int64_t f_2fe4355853ebd629(int64_t p1);
int64_t f_2fe5f5234fa44b6a(int64_t p1);
int64_t f_30d693ef8a8db365(int64_t p1);
int64_t f_31c07aa50b393194(int64_t p1);
int64_t f_329644254774d78c(int64_t p1);
int64_t f_338c781c688b5d6d(int64_t p1);
int64_t f_35a32cffcbb8f7b3(int64_t p1);
int64_t f_3632e762da5fb136(int64_t p1);
int64_t f_3754d36cda7d7a79(int64_t p1);
int64_t f_37eb6940323b7aab(int64_t p1);
int64_t f_37f5a0002796d4b4(int64_t p1);
int64_t f_38a0d0624b76abbb(int64_t p1);
int64_t f_3ba466fb37ed500b(int64_t p1);
int64_t f_3f4ec28af0af87ed(int64_t p1);
int64_t f_41cbbd13fba6099f(int64_t p1);
int64_t f_420570dd4f5fee14(int64_t p1);
int64_t f_47299ff23f5ec4ae(int64_t p1);
int64_t f_489e92cc79eda2fd(int64_t p1);
int64_t f_49e54edf4370e849(int64_t p1);
int64_t f_4a2c23f4f2a4c7bf(int64_t p1);
int64_t f_4a95db6a3015731d(int64_t p1);
int64_t f_4c12e097fbcce7de(int64_t p1);
int64_t f_4c2f085d58548f35(int64_t p1);
int64_t f_4e1722ac4a504ac5(int64_t p1);
int64_t f_509605bb3d21c548(int64_t p1);
int64_t f_52b7748b7e03b126(int64_t p1);
int64_t f_5352b14911e9db26(int64_t p1);
int64_t f_58ea2a62b0dd5957(int64_t p1);
int64_t f_5ac1125d8167d346(int64_t p1);
int64_t f_5ad1fa64abc416bb(int64_t p1);
int64_t f_5c13314d65f7070e(int64_t p1);
int64_t f_5c7925721244787b(int64_t p1);
int64_t f_5c9dc143e9da7d53(int64_t p1);
int64_t f_5d2dbb14d0ce22e9(int64_t p1);
int64_t f_620db28fc978a369(int64_t p1);
int64_t f_620f1bd5908429b9(int64_t p1);
int64_t f_63d14ca54dee12cd(int64_t p1);
int64_t f_6495393e0ec64505(int64_t p1);
int64_t f_655ce0fd6e9f8f21(int64_t p1);
int64_t f_658c60881d177a73(int64_t p1);
int64_t f_6661133ec689e76c(int64_t p1);
int64_t f_66bc2c4972581d52(int64_t p1);
int64_t f_695bb3edb1c10eb8(int64_t p1);
int64_t f_69a89510a8e19608(int64_t p1);
int64_t f_69c4f02c4698d6f5(int64_t p1);
int64_t f_6a83568fec5e815a(int64_t p1);
int64_t f_6acbb85cbb2e7d8e(int64_t p1);
int64_t f_6afdaa287dc7b46d(int64_t p1);
int64_t f_6bbf40f32abb7d72(int64_t p1);
int64_t f_6e04c532a433cced(int64_t p1);
int64_t f_6e187b64e783cbf8(int64_t p1);
int64_t f_6e1944b2fe6a358b(int64_t p1);
int64_t f_6e4405b3ba9ae8cd(int64_t p1);
int64_t f_6e45a74d048deb19(int64_t p1);
int64_t f_6e8e244a2fa8357b(int64_t p1);
int64_t f_6f463f8753b25553(int64_t p1);
int64_t f_70290558c3854fb9(int64_t p1);
int64_t f_70af7dfa8b9d5d33(int64_t p1);
int64_t f_70c48a1a8c6adfa7(int64_t p1);
int64_t f_726003d7a130b8a9(int64_t p1);
int64_t f_7646620f1a99865a(int64_t p1);
int64_t f_7885811ac870d212(int64_t p1);
int64_t f_7947f7854c604f66(int64_t p1);
int64_t f_7a2851b1a45f0f15(int64_t p1);
int64_t f_7a53a66349ac8302(int64_t p1);
int64_t f_7a81356a3e150afd(int64_t p1);
int64_t f_7bee5a0bfe87fd27(int64_t p1);
int64_t f_7c78f9001fb6fea4(int64_t p1);
int64_t f_7d99980989f90053(int64_t p1);
int64_t f_80222bab3a20ea13(int64_t p1);
int64_t f_81d4ea5193d167c0(int64_t p1);
int64_t f_84163f41f2e2fddd(int64_t p1);
int64_t f_84dc7988b9ff66c9(int64_t p1);
int64_t f_856b31d595c4b589(int64_t p1);
int64_t f_8616e1dd2ab461d5(int64_t p1);
int64_t f_87cff378ae434a46(int64_t p1);
int64_t f_891a81977881c6eb(int64_t p1);
int64_t f_89ac733e4914b098(int64_t p1);
int64_t f_89d4af82d3c42b68(int64_t p1);
int64_t f_8a71922da969ce56(int64_t p1);
int64_t f_8be47e3af2fd50aa(int64_t p1);
int64_t f_8e6c4336ffc258d8(int64_t p1);
int64_t f_8f70de8d9f99e53f(int64_t p1);
int64_t f_8fd9c15c0116fcfc(int64_t p1);
int64_t f_901569cf17c71ba8(int64_t p1);
int64_t f_911d6013f2c690ec(int64_t p1);
int64_t f_914347e29880b66e(int64_t p1);
int64_t f_9214820078ceddbb(int64_t p1);
int64_t f_9238399843afbaf0(int64_t p1);
int64_t f_92b5c190df1d8477(int64_t p1);
int64_t f_92ce47b1381db64b(int64_t p1);
int64_t f_936007394ada7049(int64_t p1);
int64_t f_943e8f8cf84336e8(int64_t p1);
int64_t f_95183369e473648f(int64_t p1);
int64_t f_95c7c5ed2791d8c7(int64_t p1);
int64_t f_96afa4b9bc140468(int64_t p1);
int64_t f_970944ee43a3b66f(int64_t p1);
int64_t f_99a5f75c4fcb0ec9(int64_t p1);
int64_t f_99dcd08403d20fe8(int64_t p1);
int64_t f_9c10ba922f7242ed(int64_t p1);
int64_t f_9cff13ec9a2dbb55(int64_t p1);
int64_t f_9d55f24516cc9be7(int64_t p1);
int64_t f_9d5e9281db73228e(int64_t p1);
int64_t f_9e761eba787a11a6(int64_t p1);
int64_t f_9ed5d1843e39fe4b(int64_t p1);
int64_t f_9f7c61b72e4fcc01(int64_t p1);
int64_t f_a0f8e459a09ace25(int64_t p1);
int64_t f_a14f74bd3e2d3b52(int64_t p1);
int64_t f_a17acf4a6dbfa03f(int64_t p1);
int64_t f_a1ae08b46d2329d8(int64_t p1);
int64_t f_a38bd19629179e77(int64_t p1);
int64_t f_a3f1b5fbf06821a7(int64_t p1);
int64_t f_a5063c8e6d67a08a(int64_t p1);
int64_t f_a50a8d99bac54be0(int64_t p1);
int64_t f_a75f823c083e9b55(int64_t p1);
int64_t f_aa87e869bcb3deb3(int64_t p1);
int64_t f_aaa278d3820d7c10(int64_t p1);
int64_t f_aaca894fd5dd8d5d(int64_t p1);
int64_t f_ab22ab135cfc7f03(int64_t p1);
int64_t f_ad04d27fc2cdfb3c(int64_t p1);
int64_t f_ad0eed563d6710a5(int64_t p1);
int64_t f_ad70c3c9ba5354fa(int64_t p1);
int64_t f_ada4b2b6dbfab747(int64_t p1);
int64_t f_adbf27a4aa538938(int64_t p1);
int64_t f_adbf9fc271314305(int64_t p1);
int64_t f_aeaa10c2868c2544(int64_t p1);
int64_t f_aede0641cd502851(int64_t p1);
int64_t f_aef4380f706b52b0(int64_t p1);
int64_t f_b0c323eee9cbbf8c(int64_t p1);
int64_t f_b0e5aa31ad01ca4e(int64_t p1);
int64_t f_b5497583b14d9758(int64_t p1);
int64_t f_b595fd324556fbba(int64_t p1);
int64_t f_b63f7579466b8d16(int64_t p1);
int64_t f_b74a6175129a725e(int64_t p1);
int64_t f_b8b23e37bef54b0c(int64_t p1);
int64_t f_bc6beedc491b2844(int64_t p1);
int64_t f_bdc4f598f746dc19(int64_t p1);
int64_t f_bde25bf2ae01c8a1(int64_t p1);
int64_t f_c2a46654f9cef801(int64_t p1);
int64_t f_c3ae8b0d935a77e5(int64_t p1);
int64_t f_c543dcb396a8aa3e(int64_t p1);
int64_t f_c6423313f96f0b06(int64_t p1);
int64_t f_c64403f64f6c81b1(int64_t p1);
int64_t f_c6638f0d95ea3dd3(int64_t p1);
int64_t f_c6c0593148877aa7(int64_t p1);
int64_t f_c6cea8fc00414c66(int64_t p1);
int64_t f_c79f5289847e038f(int64_t p1);
int64_t f_c7beb8261d6b69cd(int64_t p1);
int64_t f_c8ea4b882354f475(int64_t p1);
int64_t f_c9d35363888b9352(int64_t p1);
int64_t f_c9de8b76366ef0ad(int64_t p1);
int64_t f_cc223626cdf9f506(int64_t p1);
int64_t f_cd810979d9d91403(int64_t p1);
int64_t f_ce5002bd14c1ad21(int64_t p1);
int64_t f_cf3d129250fb9f97(int64_t p1);
int64_t f_cf77d6ac624225eb(int64_t p1);
int64_t f_cf8c94538d1bc2d3(int64_t p1);
int64_t f_cfb1cbd45320491a(int64_t p1);
int64_t f_d18a6c484a3658d5(int64_t p1);
int64_t f_d20f7f58fb2bfc8e(int64_t p1);
int64_t f_d3722509e8844953(int64_t p1);
int64_t f_d378c8c7e1032688(int64_t p1);
int64_t f_d3e6eb48954cf171(int64_t p1);
int64_t f_d4e70a7d5e27f6a1(int64_t p1);
int64_t f_d53ab81cf9d110cb(int64_t p1);
int64_t f_d55eeee98958238e(int64_t p1);
int64_t f_d5b3150a80e91f1a(int64_t p1);
int64_t f_d6b19d45cc583106(int64_t p1);
int64_t f_d7015c3f7e2c0086(int64_t p1);
int64_t f_d707b29152413470(int64_t p1);
int64_t f_d799bae7b1d71e42(int64_t p1);
int64_t f_d7d3446327da7cef(int64_t p1);
int64_t f_d93e6755e311ad3b(int64_t p1);
int64_t f_dba6d5be34aaeffb(int64_t p1);
int64_t f_dbe75b723c3e652a(int64_t p1);
int64_t f_ddc7041e1c4192c8(int64_t p1);
int64_t f_ddff6c6a396f760c(int64_t p1);
int64_t f_e01d5f31b4d85cfb(int64_t p1);
int64_t f_e1ba5cf93f404e7c(int64_t p1);
int64_t f_e2dd255ed5ba577c(int64_t p1);
int64_t f_e4e5029593d65e5a(int64_t p1);
int64_t f_e4e717d2eef775c1(int64_t p1);
int64_t f_e4e91ccae01e4b9c(int64_t p1);
int64_t f_e54911916a943a85(int64_t p1);
int64_t f_e61724f7935ea8eb(int64_t p1);
int64_t f_e769b61a53b62242(int64_t p1);
int64_t f_e909122e4e7579ae(int64_t p1);
int64_t f_e9774056f07cacb8(int64_t p1);
int64_t f_e98d639fd11282c0(int64_t p1);
int64_t f_e9c4cb0543595e45(int64_t p1);
int64_t f_ea2b174b945b6a7d(int64_t p1);
int64_t f_ea4b82b4b5da741c(int64_t p1);
int64_t f_eb0e2947640f5dd0(int64_t p1);
int64_t f_ebf8b38da9e287d2(int64_t p1);
int64_t f_ef0f666527735563(int64_t p1);
int64_t f_f0497e5c9577df97(int64_t p1);
int64_t f_f0b2a02668219252(int64_t p1);
int64_t f_f222bcb220511850(int64_t p1);
int64_t f_f272ab7eeb43addd(int64_t p1);
int64_t f_f50cc8000839d113(int64_t p1);
int64_t f_f54fbe4a6a7a074f(int64_t p1);
int64_t f_f653010808001fef(int64_t p1);
int64_t f_f6f6b74f6101424e(int64_t p1);
int64_t f_f7b85ea6c34fd168(int64_t p1);
int64_t f_f7de1765bb06efd7(int64_t p1);
int64_t f_f8481ab24b3f511b(int64_t p1);
int64_t f_f86391d34a050e5e(int64_t p1);
int64_t f_f8dcb7425084658c(int64_t p1);
int64_t f_f9a7093afd8ecc61(int64_t p1);
int64_t f_fa713bfc79ead375(int64_t p1);
int64_t f_fa94b520e37fcf69(int64_t p1);
int64_t f_feb5c39f9b67e61a(int64_t p1);
/* id */
int64_t f_7646620f1a99865a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = l1;
  return l0;
}

int64_t tramp_7646620f1a99865a(int64_t p1) { return ((int64_t (*)(int64_t))f_7646620f1a99865a)(p1); }
/* f0 */
int64_t f_adbf27a4aa538938(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 0, (LUST_SO(lust_so_adbf27a4aa538938) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_adbf27a4aa538938(int64_t p1) { return ((int64_t (*)(int64_t))f_adbf27a4aa538938)(p1); }
/* f1 */
int64_t f_c79f5289847e038f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 1, (LUST_SO(lust_so_c79f5289847e038f) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c79f5289847e038f(int64_t p1) { return ((int64_t (*)(int64_t))f_c79f5289847e038f)(p1); }
/* f2 */
int64_t f_6afdaa287dc7b46d(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 2, (LUST_SO(lust_so_6afdaa287dc7b46d) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6afdaa287dc7b46d(int64_t p1) { return ((int64_t (*)(int64_t))f_6afdaa287dc7b46d)(p1); }
/* f3 */
int64_t f_6f463f8753b25553(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 3, (LUST_SO(lust_so_6f463f8753b25553) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6f463f8753b25553(int64_t p1) { return ((int64_t (*)(int64_t))f_6f463f8753b25553)(p1); }
/* f4 */
int64_t f_3f4ec28af0af87ed(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 4, (LUST_SO(lust_so_3f4ec28af0af87ed) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_3f4ec28af0af87ed(int64_t p1) { return ((int64_t (*)(int64_t))f_3f4ec28af0af87ed)(p1); }
/* f5 */
int64_t f_ad04d27fc2cdfb3c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 5, (LUST_SO(lust_so_ad04d27fc2cdfb3c) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ad04d27fc2cdfb3c(int64_t p1) { return ((int64_t (*)(int64_t))f_ad04d27fc2cdfb3c)(p1); }
/* f6 */
int64_t f_6e1944b2fe6a358b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 6, (LUST_SO(lust_so_6e1944b2fe6a358b) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6e1944b2fe6a358b(int64_t p1) { return ((int64_t (*)(int64_t))f_6e1944b2fe6a358b)(p1); }
/* f7 */
int64_t f_655ce0fd6e9f8f21(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 7, (LUST_SO(lust_so_655ce0fd6e9f8f21) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_655ce0fd6e9f8f21(int64_t p1) { return ((int64_t (*)(int64_t))f_655ce0fd6e9f8f21)(p1); }
/* f8 */
int64_t f_6acbb85cbb2e7d8e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 8, (LUST_SO(lust_so_6acbb85cbb2e7d8e) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6acbb85cbb2e7d8e(int64_t p1) { return ((int64_t (*)(int64_t))f_6acbb85cbb2e7d8e)(p1); }
/* f9 */
int64_t f_6bbf40f32abb7d72(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 9, (LUST_SO(lust_so_6bbf40f32abb7d72) | 24ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6bbf40f32abb7d72(int64_t p1) { return ((int64_t (*)(int64_t))f_6bbf40f32abb7d72)(p1); }
/* f10 */
int64_t f_70290558c3854fb9(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 10, (LUST_SO(lust_so_70290558c3854fb9) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_70290558c3854fb9(int64_t p1) { return ((int64_t (*)(int64_t))f_70290558c3854fb9)(p1); }
/* f11 */
int64_t f_ddff6c6a396f760c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 11, (LUST_SO(lust_so_ddff6c6a396f760c) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ddff6c6a396f760c(int64_t p1) { return ((int64_t (*)(int64_t))f_ddff6c6a396f760c)(p1); }
/* f12 */
int64_t f_7947f7854c604f66(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 12, (LUST_SO(lust_so_7947f7854c604f66) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_7947f7854c604f66(int64_t p1) { return ((int64_t (*)(int64_t))f_7947f7854c604f66)(p1); }
/* f13 */
int64_t f_f653010808001fef(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 13, (LUST_SO(lust_so_f653010808001fef) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f653010808001fef(int64_t p1) { return ((int64_t (*)(int64_t))f_f653010808001fef)(p1); }
/* f14 */
int64_t f_2b593d17738a060e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 14, (LUST_SO(lust_so_2b593d17738a060e) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2b593d17738a060e(int64_t p1) { return ((int64_t (*)(int64_t))f_2b593d17738a060e)(p1); }
/* f15 */
int64_t f_5c9dc143e9da7d53(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 15, (LUST_SO(lust_so_5c9dc143e9da7d53) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_5c9dc143e9da7d53(int64_t p1) { return ((int64_t (*)(int64_t))f_5c9dc143e9da7d53)(p1); }
/* f16 */
int64_t f_2078ff17ac329a01(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 16, (LUST_SO(lust_so_2078ff17ac329a01) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2078ff17ac329a01(int64_t p1) { return ((int64_t (*)(int64_t))f_2078ff17ac329a01)(p1); }
/* f17 */
int64_t f_943e8f8cf84336e8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 17, (LUST_SO(lust_so_943e8f8cf84336e8) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_943e8f8cf84336e8(int64_t p1) { return ((int64_t (*)(int64_t))f_943e8f8cf84336e8)(p1); }
/* f18 */
int64_t f_bdc4f598f746dc19(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 18, (LUST_SO(lust_so_bdc4f598f746dc19) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_bdc4f598f746dc19(int64_t p1) { return ((int64_t (*)(int64_t))f_bdc4f598f746dc19)(p1); }
/* f19 */
int64_t f_5ad1fa64abc416bb(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 19, (LUST_SO(lust_so_5ad1fa64abc416bb) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_5ad1fa64abc416bb(int64_t p1) { return ((int64_t (*)(int64_t))f_5ad1fa64abc416bb)(p1); }
/* f20 */
int64_t f_5c7925721244787b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 20, (LUST_SO(lust_so_5c7925721244787b) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_5c7925721244787b(int64_t p1) { return ((int64_t (*)(int64_t))f_5c7925721244787b)(p1); }
/* f21 */
int64_t f_0089922f873e38d8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 21, (LUST_SO(lust_so_0089922f873e38d8) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0089922f873e38d8(int64_t p1) { return ((int64_t (*)(int64_t))f_0089922f873e38d8)(p1); }
/* f22 */
int64_t f_f9a7093afd8ecc61(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 22, (LUST_SO(lust_so_f9a7093afd8ecc61) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f9a7093afd8ecc61(int64_t p1) { return ((int64_t (*)(int64_t))f_f9a7093afd8ecc61)(p1); }
/* f23 */
int64_t f_87cff378ae434a46(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 23, (LUST_SO(lust_so_87cff378ae434a46) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_87cff378ae434a46(int64_t p1) { return ((int64_t (*)(int64_t))f_87cff378ae434a46)(p1); }
/* f24 */
int64_t f_12702f75bc3606fc(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 24, (LUST_SO(lust_so_12702f75bc3606fc) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_12702f75bc3606fc(int64_t p1) { return ((int64_t (*)(int64_t))f_12702f75bc3606fc)(p1); }
/* f25 */
int64_t f_92ce47b1381db64b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 25, (LUST_SO(lust_so_92ce47b1381db64b) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_92ce47b1381db64b(int64_t p1) { return ((int64_t (*)(int64_t))f_92ce47b1381db64b)(p1); }
/* f26 */
int64_t f_6e8e244a2fa8357b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 26, (LUST_SO(lust_so_6e8e244a2fa8357b) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6e8e244a2fa8357b(int64_t p1) { return ((int64_t (*)(int64_t))f_6e8e244a2fa8357b)(p1); }
/* f27 */
int64_t f_f7de1765bb06efd7(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 27, (LUST_SO(lust_so_f7de1765bb06efd7) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f7de1765bb06efd7(int64_t p1) { return ((int64_t (*)(int64_t))f_f7de1765bb06efd7)(p1); }
/* f28 */
int64_t f_2e5694287e99ac3e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 28, (LUST_SO(lust_so_2e5694287e99ac3e) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2e5694287e99ac3e(int64_t p1) { return ((int64_t (*)(int64_t))f_2e5694287e99ac3e)(p1); }
/* f29 */
int64_t f_cf8c94538d1bc2d3(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 29, (LUST_SO(lust_so_cf8c94538d1bc2d3) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_cf8c94538d1bc2d3(int64_t p1) { return ((int64_t (*)(int64_t))f_cf8c94538d1bc2d3)(p1); }
/* f30 */
int64_t f_09e3e50757e03460(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 30, (LUST_SO(lust_so_09e3e50757e03460) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_09e3e50757e03460(int64_t p1) { return ((int64_t (*)(int64_t))f_09e3e50757e03460)(p1); }
/* f31 */
int64_t f_e769b61a53b62242(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 31, (LUST_SO(lust_so_e769b61a53b62242) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e769b61a53b62242(int64_t p1) { return ((int64_t (*)(int64_t))f_e769b61a53b62242)(p1); }
/* f32 */
int64_t f_5d2dbb14d0ce22e9(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 32, (LUST_SO(lust_so_5d2dbb14d0ce22e9) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_5d2dbb14d0ce22e9(int64_t p1) { return ((int64_t (*)(int64_t))f_5d2dbb14d0ce22e9)(p1); }
/* f33 */
int64_t f_e98d639fd11282c0(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 33, (LUST_SO(lust_so_e98d639fd11282c0) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e98d639fd11282c0(int64_t p1) { return ((int64_t (*)(int64_t))f_e98d639fd11282c0)(p1); }
/* f34 */
int64_t f_2a25936bc256da60(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 34, (LUST_SO(lust_so_2a25936bc256da60) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2a25936bc256da60(int64_t p1) { return ((int64_t (*)(int64_t))f_2a25936bc256da60)(p1); }
/* f35 */
int64_t f_c6638f0d95ea3dd3(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 35, (LUST_SO(lust_so_c6638f0d95ea3dd3) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c6638f0d95ea3dd3(int64_t p1) { return ((int64_t (*)(int64_t))f_c6638f0d95ea3dd3)(p1); }
/* f36 */
int64_t f_ef0f666527735563(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 36, (LUST_SO(lust_so_ef0f666527735563) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ef0f666527735563(int64_t p1) { return ((int64_t (*)(int64_t))f_ef0f666527735563)(p1); }
/* f37 */
int64_t f_4a95db6a3015731d(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 37, (LUST_SO(lust_so_4a95db6a3015731d) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_4a95db6a3015731d(int64_t p1) { return ((int64_t (*)(int64_t))f_4a95db6a3015731d)(p1); }
/* f38 */
int64_t f_f6f6b74f6101424e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 38, (LUST_SO(lust_so_f6f6b74f6101424e) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f6f6b74f6101424e(int64_t p1) { return ((int64_t (*)(int64_t))f_f6f6b74f6101424e)(p1); }
/* f39 */
int64_t f_8a71922da969ce56(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 39, (LUST_SO(lust_so_8a71922da969ce56) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_8a71922da969ce56(int64_t p1) { return ((int64_t (*)(int64_t))f_8a71922da969ce56)(p1); }
/* f40 */
int64_t f_240f7fa254e78590(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 40, (LUST_SO(lust_so_240f7fa254e78590) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_240f7fa254e78590(int64_t p1) { return ((int64_t (*)(int64_t))f_240f7fa254e78590)(p1); }
/* f41 */
int64_t f_2cd42e81d294ab1f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 41, (LUST_SO(lust_so_2cd42e81d294ab1f) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2cd42e81d294ab1f(int64_t p1) { return ((int64_t (*)(int64_t))f_2cd42e81d294ab1f)(p1); }
/* f42 */
int64_t f_d378c8c7e1032688(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 42, (LUST_SO(lust_so_d378c8c7e1032688) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d378c8c7e1032688(int64_t p1) { return ((int64_t (*)(int64_t))f_d378c8c7e1032688)(p1); }
/* f43 */
int64_t f_a0f8e459a09ace25(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 43, (LUST_SO(lust_so_a0f8e459a09ace25) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_a0f8e459a09ace25(int64_t p1) { return ((int64_t (*)(int64_t))f_a0f8e459a09ace25)(p1); }
/* f44 */
int64_t f_6e187b64e783cbf8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 44, (LUST_SO(lust_so_6e187b64e783cbf8) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6e187b64e783cbf8(int64_t p1) { return ((int64_t (*)(int64_t))f_6e187b64e783cbf8)(p1); }
/* f45 */
int64_t f_ab22ab135cfc7f03(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 45, (LUST_SO(lust_so_ab22ab135cfc7f03) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ab22ab135cfc7f03(int64_t p1) { return ((int64_t (*)(int64_t))f_ab22ab135cfc7f03)(p1); }
/* f46 */
int64_t f_253a7c9afe971794(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 46, (LUST_SO(lust_so_253a7c9afe971794) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_253a7c9afe971794(int64_t p1) { return ((int64_t (*)(int64_t))f_253a7c9afe971794)(p1); }
/* f47 */
int64_t f_aa87e869bcb3deb3(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 47, (LUST_SO(lust_so_aa87e869bcb3deb3) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_aa87e869bcb3deb3(int64_t p1) { return ((int64_t (*)(int64_t))f_aa87e869bcb3deb3)(p1); }
/* f48 */
int64_t f_e9774056f07cacb8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 48, (LUST_SO(lust_so_e9774056f07cacb8) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e9774056f07cacb8(int64_t p1) { return ((int64_t (*)(int64_t))f_e9774056f07cacb8)(p1); }
/* f49 */
int64_t f_0c57b10e9de4dd8c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 49, (LUST_SO(lust_so_0c57b10e9de4dd8c) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0c57b10e9de4dd8c(int64_t p1) { return ((int64_t (*)(int64_t))f_0c57b10e9de4dd8c)(p1); }
/* f50 */
int64_t f_936007394ada7049(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 50, (LUST_SO(lust_so_936007394ada7049) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_936007394ada7049(int64_t p1) { return ((int64_t (*)(int64_t))f_936007394ada7049)(p1); }
/* f51 */
int64_t f_2c6f8781d6a6b594(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 51, (LUST_SO(lust_so_2c6f8781d6a6b594) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2c6f8781d6a6b594(int64_t p1) { return ((int64_t (*)(int64_t))f_2c6f8781d6a6b594)(p1); }
/* f52 */
int64_t f_9214820078ceddbb(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 52, (LUST_SO(lust_so_9214820078ceddbb) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_9214820078ceddbb(int64_t p1) { return ((int64_t (*)(int64_t))f_9214820078ceddbb)(p1); }
/* f53 */
int64_t f_329644254774d78c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 53, (LUST_SO(lust_so_329644254774d78c) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_329644254774d78c(int64_t p1) { return ((int64_t (*)(int64_t))f_329644254774d78c)(p1); }
/* f54 */
int64_t f_89d4af82d3c42b68(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 54, (LUST_SO(lust_so_89d4af82d3c42b68) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_89d4af82d3c42b68(int64_t p1) { return ((int64_t (*)(int64_t))f_89d4af82d3c42b68)(p1); }
/* f55 */
int64_t f_d7d3446327da7cef(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 55, (LUST_SO(lust_so_d7d3446327da7cef) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d7d3446327da7cef(int64_t p1) { return ((int64_t (*)(int64_t))f_d7d3446327da7cef)(p1); }
/* f56 */
int64_t f_9d55f24516cc9be7(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 56, (LUST_SO(lust_so_9d55f24516cc9be7) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_9d55f24516cc9be7(int64_t p1) { return ((int64_t (*)(int64_t))f_9d55f24516cc9be7)(p1); }
/* f57 */
int64_t f_18da39ea0dcd4fe7(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 57, (LUST_SO(lust_so_18da39ea0dcd4fe7) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_18da39ea0dcd4fe7(int64_t p1) { return ((int64_t (*)(int64_t))f_18da39ea0dcd4fe7)(p1); }
/* f58 */
int64_t f_8be47e3af2fd50aa(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 58, (LUST_SO(lust_so_8be47e3af2fd50aa) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_8be47e3af2fd50aa(int64_t p1) { return ((int64_t (*)(int64_t))f_8be47e3af2fd50aa)(p1); }
/* f59 */
int64_t f_d4e70a7d5e27f6a1(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 59, (LUST_SO(lust_so_d4e70a7d5e27f6a1) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d4e70a7d5e27f6a1(int64_t p1) { return ((int64_t (*)(int64_t))f_d4e70a7d5e27f6a1)(p1); }
/* f60 */
int64_t f_00b418e2a8d3f4dd(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 60, (LUST_SO(lust_so_00b418e2a8d3f4dd) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_00b418e2a8d3f4dd(int64_t p1) { return ((int64_t (*)(int64_t))f_00b418e2a8d3f4dd)(p1); }
/* f61 */
int64_t f_9ed5d1843e39fe4b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 61, (LUST_SO(lust_so_9ed5d1843e39fe4b) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_9ed5d1843e39fe4b(int64_t p1) { return ((int64_t (*)(int64_t))f_9ed5d1843e39fe4b)(p1); }
/* f62 */
int64_t f_47299ff23f5ec4ae(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 62, (LUST_SO(lust_so_47299ff23f5ec4ae) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_47299ff23f5ec4ae(int64_t p1) { return ((int64_t (*)(int64_t))f_47299ff23f5ec4ae)(p1); }
/* f63 */
int64_t f_0d06ace48c74648b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 63, (LUST_SO(lust_so_0d06ace48c74648b) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0d06ace48c74648b(int64_t p1) { return ((int64_t (*)(int64_t))f_0d06ace48c74648b)(p1); }
/* f64 */
int64_t f_bde25bf2ae01c8a1(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 64, (LUST_SO(lust_so_bde25bf2ae01c8a1) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_bde25bf2ae01c8a1(int64_t p1) { return ((int64_t (*)(int64_t))f_bde25bf2ae01c8a1)(p1); }
/* f65 */
int64_t f_3632e762da5fb136(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 65, (LUST_SO(lust_so_3632e762da5fb136) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_3632e762da5fb136(int64_t p1) { return ((int64_t (*)(int64_t))f_3632e762da5fb136)(p1); }
/* f66 */
int64_t f_b0c323eee9cbbf8c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 66, (LUST_SO(lust_so_b0c323eee9cbbf8c) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_b0c323eee9cbbf8c(int64_t p1) { return ((int64_t (*)(int64_t))f_b0c323eee9cbbf8c)(p1); }
/* f67 */
int64_t f_338c781c688b5d6d(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 67, (LUST_SO(lust_so_338c781c688b5d6d) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_338c781c688b5d6d(int64_t p1) { return ((int64_t (*)(int64_t))f_338c781c688b5d6d)(p1); }
/* f68 */
int64_t f_3754d36cda7d7a79(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 68, (LUST_SO(lust_so_3754d36cda7d7a79) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_3754d36cda7d7a79(int64_t p1) { return ((int64_t (*)(int64_t))f_3754d36cda7d7a79)(p1); }
/* f69 */
int64_t f_f7b85ea6c34fd168(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 69, (LUST_SO(lust_so_f7b85ea6c34fd168) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f7b85ea6c34fd168(int64_t p1) { return ((int64_t (*)(int64_t))f_f7b85ea6c34fd168)(p1); }
/* f70 */
int64_t f_0b073575bb69bcd4(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 70, (LUST_SO(lust_so_0b073575bb69bcd4) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0b073575bb69bcd4(int64_t p1) { return ((int64_t (*)(int64_t))f_0b073575bb69bcd4)(p1); }
/* f71 */
int64_t f_41cbbd13fba6099f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 71, (LUST_SO(lust_so_41cbbd13fba6099f) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_41cbbd13fba6099f(int64_t p1) { return ((int64_t (*)(int64_t))f_41cbbd13fba6099f)(p1); }
/* f72 */
int64_t f_a5063c8e6d67a08a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 72, (LUST_SO(lust_so_a5063c8e6d67a08a) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_a5063c8e6d67a08a(int64_t p1) { return ((int64_t (*)(int64_t))f_a5063c8e6d67a08a)(p1); }
/* f73 */
int64_t f_fa94b520e37fcf69(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 73, (LUST_SO(lust_so_fa94b520e37fcf69) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_fa94b520e37fcf69(int64_t p1) { return ((int64_t (*)(int64_t))f_fa94b520e37fcf69)(p1); }
/* f74 */
int64_t f_970944ee43a3b66f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 74, (LUST_SO(lust_so_970944ee43a3b66f) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_970944ee43a3b66f(int64_t p1) { return ((int64_t (*)(int64_t))f_970944ee43a3b66f)(p1); }
/* f75 */
int64_t f_f8dcb7425084658c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 75, (LUST_SO(lust_so_f8dcb7425084658c) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f8dcb7425084658c(int64_t p1) { return ((int64_t (*)(int64_t))f_f8dcb7425084658c)(p1); }
/* f76 */
int64_t f_cfb1cbd45320491a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 76, (LUST_SO(lust_so_cfb1cbd45320491a) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_cfb1cbd45320491a(int64_t p1) { return ((int64_t (*)(int64_t))f_cfb1cbd45320491a)(p1); }
/* f77 */
int64_t f_7d99980989f90053(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 77, (LUST_SO(lust_so_7d99980989f90053) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_7d99980989f90053(int64_t p1) { return ((int64_t (*)(int64_t))f_7d99980989f90053)(p1); }
/* f78 */
int64_t f_a3f1b5fbf06821a7(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 78, (LUST_SO(lust_so_a3f1b5fbf06821a7) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_a3f1b5fbf06821a7(int64_t p1) { return ((int64_t (*)(int64_t))f_a3f1b5fbf06821a7)(p1); }
/* f79 */
int64_t f_70af7dfa8b9d5d33(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 79, (LUST_SO(lust_so_70af7dfa8b9d5d33) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_70af7dfa8b9d5d33(int64_t p1) { return ((int64_t (*)(int64_t))f_70af7dfa8b9d5d33)(p1); }
/* f80 */
int64_t f_b63f7579466b8d16(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 80, (LUST_SO(lust_so_b63f7579466b8d16) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_b63f7579466b8d16(int64_t p1) { return ((int64_t (*)(int64_t))f_b63f7579466b8d16)(p1); }
/* f81 */
int64_t f_658c60881d177a73(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 81, (LUST_SO(lust_so_658c60881d177a73) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_658c60881d177a73(int64_t p1) { return ((int64_t (*)(int64_t))f_658c60881d177a73)(p1); }
/* f82 */
int64_t f_aaca894fd5dd8d5d(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 82, (LUST_SO(lust_so_aaca894fd5dd8d5d) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_aaca894fd5dd8d5d(int64_t p1) { return ((int64_t (*)(int64_t))f_aaca894fd5dd8d5d)(p1); }
/* f83 */
int64_t f_cd810979d9d91403(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 83, (LUST_SO(lust_so_cd810979d9d91403) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_cd810979d9d91403(int64_t p1) { return ((int64_t (*)(int64_t))f_cd810979d9d91403)(p1); }
/* f84 */
int64_t f_cf3d129250fb9f97(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 84, (LUST_SO(lust_so_cf3d129250fb9f97) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_cf3d129250fb9f97(int64_t p1) { return ((int64_t (*)(int64_t))f_cf3d129250fb9f97)(p1); }
/* f85 */
int64_t f_ce5002bd14c1ad21(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 85, (LUST_SO(lust_so_ce5002bd14c1ad21) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ce5002bd14c1ad21(int64_t p1) { return ((int64_t (*)(int64_t))f_ce5002bd14c1ad21)(p1); }
/* f86 */
int64_t f_891a81977881c6eb(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 86, (LUST_SO(lust_so_891a81977881c6eb) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_891a81977881c6eb(int64_t p1) { return ((int64_t (*)(int64_t))f_891a81977881c6eb)(p1); }
/* f87 */
int64_t f_07a3bf7807baa7ae(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 87, (LUST_SO(lust_so_07a3bf7807baa7ae) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_07a3bf7807baa7ae(int64_t p1) { return ((int64_t (*)(int64_t))f_07a3bf7807baa7ae)(p1); }
/* f88 */
int64_t f_e1ba5cf93f404e7c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 88, (LUST_SO(lust_so_e1ba5cf93f404e7c) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e1ba5cf93f404e7c(int64_t p1) { return ((int64_t (*)(int64_t))f_e1ba5cf93f404e7c)(p1); }
/* f89 */
int64_t f_c6c0593148877aa7(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 89, (LUST_SO(lust_so_c6c0593148877aa7) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c6c0593148877aa7(int64_t p1) { return ((int64_t (*)(int64_t))f_c6c0593148877aa7)(p1); }
/* f90 */
int64_t f_7885811ac870d212(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 90, (LUST_SO(lust_so_7885811ac870d212) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_7885811ac870d212(int64_t p1) { return ((int64_t (*)(int64_t))f_7885811ac870d212)(p1); }
/* f91 */
int64_t f_8e6c4336ffc258d8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 91, (LUST_SO(lust_so_8e6c4336ffc258d8) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_8e6c4336ffc258d8(int64_t p1) { return ((int64_t (*)(int64_t))f_8e6c4336ffc258d8)(p1); }
/* f92 */
int64_t f_13e778d589c9a46d(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 92, (LUST_SO(lust_so_13e778d589c9a46d) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_13e778d589c9a46d(int64_t p1) { return ((int64_t (*)(int64_t))f_13e778d589c9a46d)(p1); }
/* f93 */
int64_t f_e4e5029593d65e5a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 93, (LUST_SO(lust_so_e4e5029593d65e5a) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e4e5029593d65e5a(int64_t p1) { return ((int64_t (*)(int64_t))f_e4e5029593d65e5a)(p1); }
/* f94 */
int64_t f_70c48a1a8c6adfa7(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 94, (LUST_SO(lust_so_70c48a1a8c6adfa7) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_70c48a1a8c6adfa7(int64_t p1) { return ((int64_t (*)(int64_t))f_70c48a1a8c6adfa7)(p1); }
/* f95 */
int64_t f_2d1c1333514d7c13(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 95, (LUST_SO(lust_so_2d1c1333514d7c13) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2d1c1333514d7c13(int64_t p1) { return ((int64_t (*)(int64_t))f_2d1c1333514d7c13)(p1); }
/* f96 */
int64_t f_9f7c61b72e4fcc01(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 96, (LUST_SO(lust_so_9f7c61b72e4fcc01) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_9f7c61b72e4fcc01(int64_t p1) { return ((int64_t (*)(int64_t))f_9f7c61b72e4fcc01)(p1); }
/* f97 */
int64_t f_ad70c3c9ba5354fa(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 97, (LUST_SO(lust_so_ad70c3c9ba5354fa) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ad70c3c9ba5354fa(int64_t p1) { return ((int64_t (*)(int64_t))f_ad70c3c9ba5354fa)(p1); }
/* f98 */
int64_t f_9e761eba787a11a6(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 98, (LUST_SO(lust_so_9e761eba787a11a6) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_9e761eba787a11a6(int64_t p1) { return ((int64_t (*)(int64_t))f_9e761eba787a11a6)(p1); }
/* f99 */
int64_t f_9d5e9281db73228e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 99, (LUST_SO(lust_so_9d5e9281db73228e) | 25ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_9d5e9281db73228e(int64_t p1) { return ((int64_t (*)(int64_t))f_9d5e9281db73228e)(p1); }
/* f100 */
int64_t f_c2a46654f9cef801(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 100, (LUST_SO(lust_so_c2a46654f9cef801) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c2a46654f9cef801(int64_t p1) { return ((int64_t (*)(int64_t))f_c2a46654f9cef801)(p1); }
/* f101 */
int64_t f_2fe5f5234fa44b6a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 101, (LUST_SO(lust_so_2fe5f5234fa44b6a) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2fe5f5234fa44b6a(int64_t p1) { return ((int64_t (*)(int64_t))f_2fe5f5234fa44b6a)(p1); }
/* f102 */
int64_t f_f54fbe4a6a7a074f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 102, (LUST_SO(lust_so_f54fbe4a6a7a074f) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f54fbe4a6a7a074f(int64_t p1) { return ((int64_t (*)(int64_t))f_f54fbe4a6a7a074f)(p1); }
/* f103 */
int64_t f_c8ea4b882354f475(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 103, (LUST_SO(lust_so_c8ea4b882354f475) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c8ea4b882354f475(int64_t p1) { return ((int64_t (*)(int64_t))f_c8ea4b882354f475)(p1); }
/* f104 */
int64_t f_a1ae08b46d2329d8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 104, (LUST_SO(lust_so_a1ae08b46d2329d8) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_a1ae08b46d2329d8(int64_t p1) { return ((int64_t (*)(int64_t))f_a1ae08b46d2329d8)(p1); }
/* f105 */
int64_t f_04e9e8efe4aca037(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 105, (LUST_SO(lust_so_04e9e8efe4aca037) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_04e9e8efe4aca037(int64_t p1) { return ((int64_t (*)(int64_t))f_04e9e8efe4aca037)(p1); }
/* f106 */
int64_t f_4e1722ac4a504ac5(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 106, (LUST_SO(lust_so_4e1722ac4a504ac5) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_4e1722ac4a504ac5(int64_t p1) { return ((int64_t (*)(int64_t))f_4e1722ac4a504ac5)(p1); }
/* f107 */
int64_t f_37f5a0002796d4b4(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 107, (LUST_SO(lust_so_37f5a0002796d4b4) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_37f5a0002796d4b4(int64_t p1) { return ((int64_t (*)(int64_t))f_37f5a0002796d4b4)(p1); }
/* f108 */
int64_t f_29c6b9c153875659(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 108, (LUST_SO(lust_so_29c6b9c153875659) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_29c6b9c153875659(int64_t p1) { return ((int64_t (*)(int64_t))f_29c6b9c153875659)(p1); }
/* f109 */
int64_t f_49e54edf4370e849(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 109, (LUST_SO(lust_so_49e54edf4370e849) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_49e54edf4370e849(int64_t p1) { return ((int64_t (*)(int64_t))f_49e54edf4370e849)(p1); }
/* f110 */
int64_t f_7a2851b1a45f0f15(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 110, (LUST_SO(lust_so_7a2851b1a45f0f15) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_7a2851b1a45f0f15(int64_t p1) { return ((int64_t (*)(int64_t))f_7a2851b1a45f0f15)(p1); }
/* f111 */
int64_t f_d707b29152413470(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 111, (LUST_SO(lust_so_d707b29152413470) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d707b29152413470(int64_t p1) { return ((int64_t (*)(int64_t))f_d707b29152413470)(p1); }
/* f112 */
int64_t f_c6cea8fc00414c66(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 112, (LUST_SO(lust_so_c6cea8fc00414c66) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c6cea8fc00414c66(int64_t p1) { return ((int64_t (*)(int64_t))f_c6cea8fc00414c66)(p1); }
/* f113 */
int64_t f_b74a6175129a725e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 113, (LUST_SO(lust_so_b74a6175129a725e) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_b74a6175129a725e(int64_t p1) { return ((int64_t (*)(int64_t))f_b74a6175129a725e)(p1); }
/* f114 */
int64_t f_63d14ca54dee12cd(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 114, (LUST_SO(lust_so_63d14ca54dee12cd) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_63d14ca54dee12cd(int64_t p1) { return ((int64_t (*)(int64_t))f_63d14ca54dee12cd)(p1); }
/* f115 */
int64_t f_a38bd19629179e77(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 115, (LUST_SO(lust_so_a38bd19629179e77) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_a38bd19629179e77(int64_t p1) { return ((int64_t (*)(int64_t))f_a38bd19629179e77)(p1); }
/* f116 */
int64_t f_6495393e0ec64505(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 116, (LUST_SO(lust_so_6495393e0ec64505) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6495393e0ec64505(int64_t p1) { return ((int64_t (*)(int64_t))f_6495393e0ec64505)(p1); }
/* f117 */
int64_t f_80222bab3a20ea13(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 117, (LUST_SO(lust_so_80222bab3a20ea13) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_80222bab3a20ea13(int64_t p1) { return ((int64_t (*)(int64_t))f_80222bab3a20ea13)(p1); }
/* f118 */
int64_t f_e4e717d2eef775c1(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 118, (LUST_SO(lust_so_e4e717d2eef775c1) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e4e717d2eef775c1(int64_t p1) { return ((int64_t (*)(int64_t))f_e4e717d2eef775c1)(p1); }
/* f119 */
int64_t f_0d0197cb01c4fe35(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 119, (LUST_SO(lust_so_0d0197cb01c4fe35) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0d0197cb01c4fe35(int64_t p1) { return ((int64_t (*)(int64_t))f_0d0197cb01c4fe35)(p1); }
/* f120 */
int64_t f_5ac1125d8167d346(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 120, (LUST_SO(lust_so_5ac1125d8167d346) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_5ac1125d8167d346(int64_t p1) { return ((int64_t (*)(int64_t))f_5ac1125d8167d346)(p1); }
/* f121 */
int64_t f_1872984064d4f18e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 121, (LUST_SO(lust_so_1872984064d4f18e) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_1872984064d4f18e(int64_t p1) { return ((int64_t (*)(int64_t))f_1872984064d4f18e)(p1); }
/* f122 */
int64_t f_89ac733e4914b098(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 122, (LUST_SO(lust_so_89ac733e4914b098) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_89ac733e4914b098(int64_t p1) { return ((int64_t (*)(int64_t))f_89ac733e4914b098)(p1); }
/* f123 */
int64_t f_12ac54cbfedf3848(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 123, (LUST_SO(lust_so_12ac54cbfedf3848) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_12ac54cbfedf3848(int64_t p1) { return ((int64_t (*)(int64_t))f_12ac54cbfedf3848)(p1); }
/* f124 */
int64_t f_4c2f085d58548f35(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 124, (LUST_SO(lust_so_4c2f085d58548f35) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_4c2f085d58548f35(int64_t p1) { return ((int64_t (*)(int64_t))f_4c2f085d58548f35)(p1); }
/* f125 */
int64_t f_914347e29880b66e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 125, (LUST_SO(lust_so_914347e29880b66e) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_914347e29880b66e(int64_t p1) { return ((int64_t (*)(int64_t))f_914347e29880b66e)(p1); }
/* f126 */
int64_t f_66bc2c4972581d52(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 126, (LUST_SO(lust_so_66bc2c4972581d52) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_66bc2c4972581d52(int64_t p1) { return ((int64_t (*)(int64_t))f_66bc2c4972581d52)(p1); }
/* f127 */
int64_t f_c3ae8b0d935a77e5(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 127, (LUST_SO(lust_so_c3ae8b0d935a77e5) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c3ae8b0d935a77e5(int64_t p1) { return ((int64_t (*)(int64_t))f_c3ae8b0d935a77e5)(p1); }
/* f128 */
int64_t f_b8b23e37bef54b0c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 128, (LUST_SO(lust_so_b8b23e37bef54b0c) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_b8b23e37bef54b0c(int64_t p1) { return ((int64_t (*)(int64_t))f_b8b23e37bef54b0c)(p1); }
/* f129 */
int64_t f_1c09d099eb34e949(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 129, (LUST_SO(lust_so_1c09d099eb34e949) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_1c09d099eb34e949(int64_t p1) { return ((int64_t (*)(int64_t))f_1c09d099eb34e949)(p1); }
/* f130 */
int64_t f_1463cb8c99acbf3d(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 130, (LUST_SO(lust_so_1463cb8c99acbf3d) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_1463cb8c99acbf3d(int64_t p1) { return ((int64_t (*)(int64_t))f_1463cb8c99acbf3d)(p1); }
/* f131 */
int64_t f_a17acf4a6dbfa03f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 131, (LUST_SO(lust_so_a17acf4a6dbfa03f) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_a17acf4a6dbfa03f(int64_t p1) { return ((int64_t (*)(int64_t))f_a17acf4a6dbfa03f)(p1); }
/* f132 */
int64_t f_6e45a74d048deb19(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 132, (LUST_SO(lust_so_6e45a74d048deb19) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6e45a74d048deb19(int64_t p1) { return ((int64_t (*)(int64_t))f_6e45a74d048deb19)(p1); }
/* f133 */
int64_t f_99dcd08403d20fe8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 133, (LUST_SO(lust_so_99dcd08403d20fe8) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_99dcd08403d20fe8(int64_t p1) { return ((int64_t (*)(int64_t))f_99dcd08403d20fe8)(p1); }
/* f134 */
int64_t f_d20f7f58fb2bfc8e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 134, (LUST_SO(lust_so_d20f7f58fb2bfc8e) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d20f7f58fb2bfc8e(int64_t p1) { return ((int64_t (*)(int64_t))f_d20f7f58fb2bfc8e)(p1); }
/* f135 */
int64_t f_37eb6940323b7aab(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 135, (LUST_SO(lust_so_37eb6940323b7aab) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_37eb6940323b7aab(int64_t p1) { return ((int64_t (*)(int64_t))f_37eb6940323b7aab)(p1); }
/* f136 */
int64_t f_06edc7502cf7934b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 136, (LUST_SO(lust_so_06edc7502cf7934b) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_06edc7502cf7934b(int64_t p1) { return ((int64_t (*)(int64_t))f_06edc7502cf7934b)(p1); }
/* f137 */
int64_t f_c6423313f96f0b06(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 137, (LUST_SO(lust_so_c6423313f96f0b06) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c6423313f96f0b06(int64_t p1) { return ((int64_t (*)(int64_t))f_c6423313f96f0b06)(p1); }
/* f138 */
int64_t f_8fd9c15c0116fcfc(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 138, (LUST_SO(lust_so_8fd9c15c0116fcfc) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_8fd9c15c0116fcfc(int64_t p1) { return ((int64_t (*)(int64_t))f_8fd9c15c0116fcfc)(p1); }
/* f139 */
int64_t f_d5b3150a80e91f1a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 139, (LUST_SO(lust_so_d5b3150a80e91f1a) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d5b3150a80e91f1a(int64_t p1) { return ((int64_t (*)(int64_t))f_d5b3150a80e91f1a)(p1); }
/* f140 */
int64_t f_69c4f02c4698d6f5(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 140, (LUST_SO(lust_so_69c4f02c4698d6f5) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_69c4f02c4698d6f5(int64_t p1) { return ((int64_t (*)(int64_t))f_69c4f02c4698d6f5)(p1); }
/* f141 */
int64_t f_ada4b2b6dbfab747(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 141, (LUST_SO(lust_so_ada4b2b6dbfab747) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ada4b2b6dbfab747(int64_t p1) { return ((int64_t (*)(int64_t))f_ada4b2b6dbfab747)(p1); }
/* f142 */
int64_t f_5352b14911e9db26(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 142, (LUST_SO(lust_so_5352b14911e9db26) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_5352b14911e9db26(int64_t p1) { return ((int64_t (*)(int64_t))f_5352b14911e9db26)(p1); }
/* f143 */
int64_t f_5c13314d65f7070e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 143, (LUST_SO(lust_so_5c13314d65f7070e) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_5c13314d65f7070e(int64_t p1) { return ((int64_t (*)(int64_t))f_5c13314d65f7070e)(p1); }
/* f144 */
int64_t f_f0497e5c9577df97(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 144, (LUST_SO(lust_so_f0497e5c9577df97) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f0497e5c9577df97(int64_t p1) { return ((int64_t (*)(int64_t))f_f0497e5c9577df97)(p1); }
/* f145 */
int64_t f_aaa278d3820d7c10(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 145, (LUST_SO(lust_so_aaa278d3820d7c10) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_aaa278d3820d7c10(int64_t p1) { return ((int64_t (*)(int64_t))f_aaa278d3820d7c10)(p1); }
/* f146 */
int64_t f_09eb54041f570968(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 146, (LUST_SO(lust_so_09eb54041f570968) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_09eb54041f570968(int64_t p1) { return ((int64_t (*)(int64_t))f_09eb54041f570968)(p1); }
/* f147 */
int64_t f_6e04c532a433cced(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 147, (LUST_SO(lust_so_6e04c532a433cced) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6e04c532a433cced(int64_t p1) { return ((int64_t (*)(int64_t))f_6e04c532a433cced)(p1); }
/* f148 */
int64_t f_13ed921ecad8edea(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 148, (LUST_SO(lust_so_13ed921ecad8edea) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_13ed921ecad8edea(int64_t p1) { return ((int64_t (*)(int64_t))f_13ed921ecad8edea)(p1); }
/* f149 */
int64_t f_509605bb3d21c548(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 149, (LUST_SO(lust_so_509605bb3d21c548) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_509605bb3d21c548(int64_t p1) { return ((int64_t (*)(int64_t))f_509605bb3d21c548)(p1); }
/* f150 */
int64_t f_0c702a05f888b9b5(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 150, (LUST_SO(lust_so_0c702a05f888b9b5) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0c702a05f888b9b5(int64_t p1) { return ((int64_t (*)(int64_t))f_0c702a05f888b9b5)(p1); }
/* f151 */
int64_t f_69a89510a8e19608(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 151, (LUST_SO(lust_so_69a89510a8e19608) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_69a89510a8e19608(int64_t p1) { return ((int64_t (*)(int64_t))f_69a89510a8e19608)(p1); }
/* f152 */
int64_t f_feb5c39f9b67e61a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 152, (LUST_SO(lust_so_feb5c39f9b67e61a) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_feb5c39f9b67e61a(int64_t p1) { return ((int64_t (*)(int64_t))f_feb5c39f9b67e61a)(p1); }
/* f153 */
int64_t f_cc223626cdf9f506(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 153, (LUST_SO(lust_so_cc223626cdf9f506) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_cc223626cdf9f506(int64_t p1) { return ((int64_t (*)(int64_t))f_cc223626cdf9f506)(p1); }
/* f154 */
int64_t f_31c07aa50b393194(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 154, (LUST_SO(lust_so_31c07aa50b393194) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_31c07aa50b393194(int64_t p1) { return ((int64_t (*)(int64_t))f_31c07aa50b393194)(p1); }
/* f155 */
int64_t f_95c7c5ed2791d8c7(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 155, (LUST_SO(lust_so_95c7c5ed2791d8c7) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_95c7c5ed2791d8c7(int64_t p1) { return ((int64_t (*)(int64_t))f_95c7c5ed2791d8c7)(p1); }
/* f156 */
int64_t f_420570dd4f5fee14(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 156, (LUST_SO(lust_so_420570dd4f5fee14) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_420570dd4f5fee14(int64_t p1) { return ((int64_t (*)(int64_t))f_420570dd4f5fee14)(p1); }
/* f157 */
int64_t f_35a32cffcbb8f7b3(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 157, (LUST_SO(lust_so_35a32cffcbb8f7b3) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_35a32cffcbb8f7b3(int64_t p1) { return ((int64_t (*)(int64_t))f_35a32cffcbb8f7b3)(p1); }
/* f158 */
int64_t f_1868532e2a981b6f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 158, (LUST_SO(lust_so_1868532e2a981b6f) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_1868532e2a981b6f(int64_t p1) { return ((int64_t (*)(int64_t))f_1868532e2a981b6f)(p1); }
/* f159 */
int64_t f_b0e5aa31ad01ca4e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 159, (LUST_SO(lust_so_b0e5aa31ad01ca4e) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_b0e5aa31ad01ca4e(int64_t p1) { return ((int64_t (*)(int64_t))f_b0e5aa31ad01ca4e)(p1); }
/* f160 */
int64_t f_6661133ec689e76c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 160, (LUST_SO(lust_so_6661133ec689e76c) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6661133ec689e76c(int64_t p1) { return ((int64_t (*)(int64_t))f_6661133ec689e76c)(p1); }
/* f161 */
int64_t f_e9c4cb0543595e45(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 161, (LUST_SO(lust_so_e9c4cb0543595e45) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e9c4cb0543595e45(int64_t p1) { return ((int64_t (*)(int64_t))f_e9c4cb0543595e45)(p1); }
/* f162 */
int64_t f_58ea2a62b0dd5957(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 162, (LUST_SO(lust_so_58ea2a62b0dd5957) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_58ea2a62b0dd5957(int64_t p1) { return ((int64_t (*)(int64_t))f_58ea2a62b0dd5957)(p1); }
/* f163 */
int64_t f_03be07e6f84a9a13(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 163, (LUST_SO(lust_so_03be07e6f84a9a13) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_03be07e6f84a9a13(int64_t p1) { return ((int64_t (*)(int64_t))f_03be07e6f84a9a13)(p1); }
/* f164 */
int64_t f_d93e6755e311ad3b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 164, (LUST_SO(lust_so_d93e6755e311ad3b) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d93e6755e311ad3b(int64_t p1) { return ((int64_t (*)(int64_t))f_d93e6755e311ad3b)(p1); }
/* f165 */
int64_t f_ea4b82b4b5da741c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 165, (LUST_SO(lust_so_ea4b82b4b5da741c) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ea4b82b4b5da741c(int64_t p1) { return ((int64_t (*)(int64_t))f_ea4b82b4b5da741c)(p1); }
/* f166 */
int64_t f_a50a8d99bac54be0(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 166, (LUST_SO(lust_so_a50a8d99bac54be0) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_a50a8d99bac54be0(int64_t p1) { return ((int64_t (*)(int64_t))f_a50a8d99bac54be0)(p1); }
/* f167 */
int64_t f_f0b2a02668219252(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 167, (LUST_SO(lust_so_f0b2a02668219252) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f0b2a02668219252(int64_t p1) { return ((int64_t (*)(int64_t))f_f0b2a02668219252)(p1); }
/* f168 */
int64_t f_f222bcb220511850(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 168, (LUST_SO(lust_so_f222bcb220511850) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f222bcb220511850(int64_t p1) { return ((int64_t (*)(int64_t))f_f222bcb220511850)(p1); }
/* f169 */
int64_t f_f86391d34a050e5e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 169, (LUST_SO(lust_so_f86391d34a050e5e) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f86391d34a050e5e(int64_t p1) { return ((int64_t (*)(int64_t))f_f86391d34a050e5e)(p1); }
/* f170 */
int64_t f_d799bae7b1d71e42(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 170, (LUST_SO(lust_so_d799bae7b1d71e42) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d799bae7b1d71e42(int64_t p1) { return ((int64_t (*)(int64_t))f_d799bae7b1d71e42)(p1); }
/* f171 */
int64_t f_7bee5a0bfe87fd27(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 171, (LUST_SO(lust_so_7bee5a0bfe87fd27) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_7bee5a0bfe87fd27(int64_t p1) { return ((int64_t (*)(int64_t))f_7bee5a0bfe87fd27)(p1); }
/* f172 */
int64_t f_489e92cc79eda2fd(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 172, (LUST_SO(lust_so_489e92cc79eda2fd) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_489e92cc79eda2fd(int64_t p1) { return ((int64_t (*)(int64_t))f_489e92cc79eda2fd)(p1); }
/* f173 */
int64_t f_ea2b174b945b6a7d(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 173, (LUST_SO(lust_so_ea2b174b945b6a7d) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ea2b174b945b6a7d(int64_t p1) { return ((int64_t (*)(int64_t))f_ea2b174b945b6a7d)(p1); }
/* f174 */
int64_t f_9238399843afbaf0(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 174, (LUST_SO(lust_so_9238399843afbaf0) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_9238399843afbaf0(int64_t p1) { return ((int64_t (*)(int64_t))f_9238399843afbaf0)(p1); }
/* f175 */
int64_t f_b5497583b14d9758(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 175, (LUST_SO(lust_so_b5497583b14d9758) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_b5497583b14d9758(int64_t p1) { return ((int64_t (*)(int64_t))f_b5497583b14d9758)(p1); }
/* f176 */
int64_t f_95183369e473648f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 176, (LUST_SO(lust_so_95183369e473648f) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_95183369e473648f(int64_t p1) { return ((int64_t (*)(int64_t))f_95183369e473648f)(p1); }
/* f177 */
int64_t f_e909122e4e7579ae(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 177, (LUST_SO(lust_so_e909122e4e7579ae) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e909122e4e7579ae(int64_t p1) { return ((int64_t (*)(int64_t))f_e909122e4e7579ae)(p1); }
/* f178 */
int64_t f_1fe405fd40cfd6c6(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 178, (LUST_SO(lust_so_1fe405fd40cfd6c6) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_1fe405fd40cfd6c6(int64_t p1) { return ((int64_t (*)(int64_t))f_1fe405fd40cfd6c6)(p1); }
/* f179 */
int64_t f_eb0e2947640f5dd0(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 179, (LUST_SO(lust_so_eb0e2947640f5dd0) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_eb0e2947640f5dd0(int64_t p1) { return ((int64_t (*)(int64_t))f_eb0e2947640f5dd0)(p1); }
/* f180 */
int64_t f_f272ab7eeb43addd(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 180, (LUST_SO(lust_so_f272ab7eeb43addd) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f272ab7eeb43addd(int64_t p1) { return ((int64_t (*)(int64_t))f_f272ab7eeb43addd)(p1); }
/* f181 */
int64_t f_96afa4b9bc140468(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 181, (LUST_SO(lust_so_96afa4b9bc140468) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_96afa4b9bc140468(int64_t p1) { return ((int64_t (*)(int64_t))f_96afa4b9bc140468)(p1); }
/* f182 */
int64_t f_84dc7988b9ff66c9(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 182, (LUST_SO(lust_so_84dc7988b9ff66c9) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_84dc7988b9ff66c9(int64_t p1) { return ((int64_t (*)(int64_t))f_84dc7988b9ff66c9)(p1); }
/* f183 */
int64_t f_c9de8b76366ef0ad(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 183, (LUST_SO(lust_so_c9de8b76366ef0ad) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c9de8b76366ef0ad(int64_t p1) { return ((int64_t (*)(int64_t))f_c9de8b76366ef0ad)(p1); }
/* f184 */
int64_t f_3ba466fb37ed500b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 184, (LUST_SO(lust_so_3ba466fb37ed500b) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_3ba466fb37ed500b(int64_t p1) { return ((int64_t (*)(int64_t))f_3ba466fb37ed500b)(p1); }
/* f185 */
int64_t f_9cff13ec9a2dbb55(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 185, (LUST_SO(lust_so_9cff13ec9a2dbb55) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_9cff13ec9a2dbb55(int64_t p1) { return ((int64_t (*)(int64_t))f_9cff13ec9a2dbb55)(p1); }
/* f186 */
int64_t f_29cce92e2bece48a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 186, (LUST_SO(lust_so_29cce92e2bece48a) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_29cce92e2bece48a(int64_t p1) { return ((int64_t (*)(int64_t))f_29cce92e2bece48a)(p1); }
/* f187 */
int64_t f_d3722509e8844953(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 187, (LUST_SO(lust_so_d3722509e8844953) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d3722509e8844953(int64_t p1) { return ((int64_t (*)(int64_t))f_d3722509e8844953)(p1); }
/* f188 */
int64_t f_4a2c23f4f2a4c7bf(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 188, (LUST_SO(lust_so_4a2c23f4f2a4c7bf) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_4a2c23f4f2a4c7bf(int64_t p1) { return ((int64_t (*)(int64_t))f_4a2c23f4f2a4c7bf)(p1); }
/* f189 */
int64_t f_7a81356a3e150afd(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 189, (LUST_SO(lust_so_7a81356a3e150afd) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_7a81356a3e150afd(int64_t p1) { return ((int64_t (*)(int64_t))f_7a81356a3e150afd)(p1); }
/* f190 */
int64_t f_ebf8b38da9e287d2(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 190, (LUST_SO(lust_so_ebf8b38da9e287d2) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ebf8b38da9e287d2(int64_t p1) { return ((int64_t (*)(int64_t))f_ebf8b38da9e287d2)(p1); }
/* f191 */
int64_t f_911d6013f2c690ec(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 191, (LUST_SO(lust_so_911d6013f2c690ec) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_911d6013f2c690ec(int64_t p1) { return ((int64_t (*)(int64_t))f_911d6013f2c690ec)(p1); }
/* f192 */
int64_t f_dbe75b723c3e652a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 192, (LUST_SO(lust_so_dbe75b723c3e652a) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_dbe75b723c3e652a(int64_t p1) { return ((int64_t (*)(int64_t))f_dbe75b723c3e652a)(p1); }
/* f193 */
int64_t f_cf77d6ac624225eb(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 193, (LUST_SO(lust_so_cf77d6ac624225eb) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_cf77d6ac624225eb(int64_t p1) { return ((int64_t (*)(int64_t))f_cf77d6ac624225eb)(p1); }
/* f194 */
int64_t f_2d3296892bfdaa34(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 194, (LUST_SO(lust_so_2d3296892bfdaa34) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2d3296892bfdaa34(int64_t p1) { return ((int64_t (*)(int64_t))f_2d3296892bfdaa34)(p1); }
/* f195 */
int64_t f_ad0eed563d6710a5(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 195, (LUST_SO(lust_so_ad0eed563d6710a5) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ad0eed563d6710a5(int64_t p1) { return ((int64_t (*)(int64_t))f_ad0eed563d6710a5)(p1); }
/* f196 */
int64_t f_0a8b4f0ce09f0f96(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 196, (LUST_SO(lust_so_0a8b4f0ce09f0f96) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0a8b4f0ce09f0f96(int64_t p1) { return ((int64_t (*)(int64_t))f_0a8b4f0ce09f0f96)(p1); }
/* f197 */
int64_t f_b595fd324556fbba(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 197, (LUST_SO(lust_so_b595fd324556fbba) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_b595fd324556fbba(int64_t p1) { return ((int64_t (*)(int64_t))f_b595fd324556fbba)(p1); }
/* f198 */
int64_t f_133fab019df5590f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 198, (LUST_SO(lust_so_133fab019df5590f) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_133fab019df5590f(int64_t p1) { return ((int64_t (*)(int64_t))f_133fab019df5590f)(p1); }
/* f199 */
int64_t f_8616e1dd2ab461d5(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 199, (LUST_SO(lust_so_8616e1dd2ab461d5) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_8616e1dd2ab461d5(int64_t p1) { return ((int64_t (*)(int64_t))f_8616e1dd2ab461d5)(p1); }
/* f200 */
int64_t f_bc6beedc491b2844(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 200, (LUST_SO(lust_so_bc6beedc491b2844) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_bc6beedc491b2844(int64_t p1) { return ((int64_t (*)(int64_t))f_bc6beedc491b2844)(p1); }
/* f201 */
int64_t f_856b31d595c4b589(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 201, (LUST_SO(lust_so_856b31d595c4b589) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_856b31d595c4b589(int64_t p1) { return ((int64_t (*)(int64_t))f_856b31d595c4b589)(p1); }
/* f202 */
int64_t f_7c78f9001fb6fea4(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 202, (LUST_SO(lust_so_7c78f9001fb6fea4) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_7c78f9001fb6fea4(int64_t p1) { return ((int64_t (*)(int64_t))f_7c78f9001fb6fea4)(p1); }
/* f203 */
int64_t f_e61724f7935ea8eb(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 203, (LUST_SO(lust_so_e61724f7935ea8eb) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e61724f7935ea8eb(int64_t p1) { return ((int64_t (*)(int64_t))f_e61724f7935ea8eb)(p1); }
/* f204 */
int64_t f_dba6d5be34aaeffb(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 204, (LUST_SO(lust_so_dba6d5be34aaeffb) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_dba6d5be34aaeffb(int64_t p1) { return ((int64_t (*)(int64_t))f_dba6d5be34aaeffb)(p1); }
/* f205 */
int64_t f_adbf9fc271314305(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 205, (LUST_SO(lust_so_adbf9fc271314305) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_adbf9fc271314305(int64_t p1) { return ((int64_t (*)(int64_t))f_adbf9fc271314305)(p1); }
/* f206 */
int64_t f_620f1bd5908429b9(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 206, (LUST_SO(lust_so_620f1bd5908429b9) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_620f1bd5908429b9(int64_t p1) { return ((int64_t (*)(int64_t))f_620f1bd5908429b9)(p1); }
/* f207 */
int64_t f_a75f823c083e9b55(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 207, (LUST_SO(lust_so_a75f823c083e9b55) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_a75f823c083e9b55(int64_t p1) { return ((int64_t (*)(int64_t))f_a75f823c083e9b55)(p1); }
/* f208 */
int64_t f_c64403f64f6c81b1(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 208, (LUST_SO(lust_so_c64403f64f6c81b1) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c64403f64f6c81b1(int64_t p1) { return ((int64_t (*)(int64_t))f_c64403f64f6c81b1)(p1); }
/* f209 */
int64_t f_aede0641cd502851(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 209, (LUST_SO(lust_so_aede0641cd502851) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_aede0641cd502851(int64_t p1) { return ((int64_t (*)(int64_t))f_aede0641cd502851)(p1); }
/* f210 */
int64_t f_81d4ea5193d167c0(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 210, (LUST_SO(lust_so_81d4ea5193d167c0) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_81d4ea5193d167c0(int64_t p1) { return ((int64_t (*)(int64_t))f_81d4ea5193d167c0)(p1); }
/* f211 */
int64_t f_aef4380f706b52b0(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 211, (LUST_SO(lust_so_aef4380f706b52b0) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_aef4380f706b52b0(int64_t p1) { return ((int64_t (*)(int64_t))f_aef4380f706b52b0)(p1); }
/* f212 */
int64_t f_901569cf17c71ba8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 212, (LUST_SO(lust_so_901569cf17c71ba8) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_901569cf17c71ba8(int64_t p1) { return ((int64_t (*)(int64_t))f_901569cf17c71ba8)(p1); }
/* f213 */
int64_t f_d7015c3f7e2c0086(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 213, (LUST_SO(lust_so_d7015c3f7e2c0086) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d7015c3f7e2c0086(int64_t p1) { return ((int64_t (*)(int64_t))f_d7015c3f7e2c0086)(p1); }
/* f214 */
int64_t f_ddc7041e1c4192c8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 214, (LUST_SO(lust_so_ddc7041e1c4192c8) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_ddc7041e1c4192c8(int64_t p1) { return ((int64_t (*)(int64_t))f_ddc7041e1c4192c8)(p1); }
/* f215 */
int64_t f_6a83568fec5e815a(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 215, (LUST_SO(lust_so_6a83568fec5e815a) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6a83568fec5e815a(int64_t p1) { return ((int64_t (*)(int64_t))f_6a83568fec5e815a)(p1); }
/* f216 */
int64_t f_52b7748b7e03b126(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 216, (LUST_SO(lust_so_52b7748b7e03b126) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_52b7748b7e03b126(int64_t p1) { return ((int64_t (*)(int64_t))f_52b7748b7e03b126)(p1); }
/* f217 */
int64_t f_92b5c190df1d8477(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 217, (LUST_SO(lust_so_92b5c190df1d8477) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_92b5c190df1d8477(int64_t p1) { return ((int64_t (*)(int64_t))f_92b5c190df1d8477)(p1); }
/* f218 */
int64_t f_9c10ba922f7242ed(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 218, (LUST_SO(lust_so_9c10ba922f7242ed) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_9c10ba922f7242ed(int64_t p1) { return ((int64_t (*)(int64_t))f_9c10ba922f7242ed)(p1); }
/* f219 */
int64_t f_c543dcb396a8aa3e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 219, (LUST_SO(lust_so_c543dcb396a8aa3e) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c543dcb396a8aa3e(int64_t p1) { return ((int64_t (*)(int64_t))f_c543dcb396a8aa3e)(p1); }
/* f220 */
int64_t f_d53ab81cf9d110cb(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 220, (LUST_SO(lust_so_d53ab81cf9d110cb) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d53ab81cf9d110cb(int64_t p1) { return ((int64_t (*)(int64_t))f_d53ab81cf9d110cb)(p1); }
/* f221 */
int64_t f_24b8bd7af0f45da5(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 221, (LUST_SO(lust_so_24b8bd7af0f45da5) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_24b8bd7af0f45da5(int64_t p1) { return ((int64_t (*)(int64_t))f_24b8bd7af0f45da5)(p1); }
/* f222 */
int64_t f_8f70de8d9f99e53f(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 222, (LUST_SO(lust_so_8f70de8d9f99e53f) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_8f70de8d9f99e53f(int64_t p1) { return ((int64_t (*)(int64_t))f_8f70de8d9f99e53f)(p1); }
/* f223 */
int64_t f_38a0d0624b76abbb(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 223, (LUST_SO(lust_so_38a0d0624b76abbb) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_38a0d0624b76abbb(int64_t p1) { return ((int64_t (*)(int64_t))f_38a0d0624b76abbb)(p1); }
/* f224 */
int64_t f_0bbf87d9ee5e1780(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 224, (LUST_SO(lust_so_0bbf87d9ee5e1780) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0bbf87d9ee5e1780(int64_t p1) { return ((int64_t (*)(int64_t))f_0bbf87d9ee5e1780)(p1); }
/* f225 */
int64_t f_726003d7a130b8a9(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 225, (LUST_SO(lust_so_726003d7a130b8a9) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_726003d7a130b8a9(int64_t p1) { return ((int64_t (*)(int64_t))f_726003d7a130b8a9)(p1); }
/* f226 */
int64_t f_c9d35363888b9352(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 226, (LUST_SO(lust_so_c9d35363888b9352) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c9d35363888b9352(int64_t p1) { return ((int64_t (*)(int64_t))f_c9d35363888b9352)(p1); }
/* f227 */
int64_t f_2ef263ab7f066864(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 227, (LUST_SO(lust_so_2ef263ab7f066864) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2ef263ab7f066864(int64_t p1) { return ((int64_t (*)(int64_t))f_2ef263ab7f066864)(p1); }
/* f228 */
int64_t f_a14f74bd3e2d3b52(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 228, (LUST_SO(lust_so_a14f74bd3e2d3b52) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_a14f74bd3e2d3b52(int64_t p1) { return ((int64_t (*)(int64_t))f_a14f74bd3e2d3b52)(p1); }
/* f229 */
int64_t f_84163f41f2e2fddd(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 229, (LUST_SO(lust_so_84163f41f2e2fddd) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_84163f41f2e2fddd(int64_t p1) { return ((int64_t (*)(int64_t))f_84163f41f2e2fddd)(p1); }
/* f230 */
int64_t f_e2dd255ed5ba577c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 230, (LUST_SO(lust_so_e2dd255ed5ba577c) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e2dd255ed5ba577c(int64_t p1) { return ((int64_t (*)(int64_t))f_e2dd255ed5ba577c)(p1); }
/* f231 */
int64_t f_2fe4355853ebd629(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 231, (LUST_SO(lust_so_2fe4355853ebd629) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2fe4355853ebd629(int64_t p1) { return ((int64_t (*)(int64_t))f_2fe4355853ebd629)(p1); }
/* f232 */
int64_t f_0c27d1821e7e4708(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 232, (LUST_SO(lust_so_0c27d1821e7e4708) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0c27d1821e7e4708(int64_t p1) { return ((int64_t (*)(int64_t))f_0c27d1821e7e4708)(p1); }
/* f233 */
int64_t f_c7beb8261d6b69cd(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 233, (LUST_SO(lust_so_c7beb8261d6b69cd) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_c7beb8261d6b69cd(int64_t p1) { return ((int64_t (*)(int64_t))f_c7beb8261d6b69cd)(p1); }
/* f234 */
int64_t f_f50cc8000839d113(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 234, (LUST_SO(lust_so_f50cc8000839d113) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f50cc8000839d113(int64_t p1) { return ((int64_t (*)(int64_t))f_f50cc8000839d113)(p1); }
/* f235 */
int64_t f_30d693ef8a8db365(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 235, (LUST_SO(lust_so_30d693ef8a8db365) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_30d693ef8a8db365(int64_t p1) { return ((int64_t (*)(int64_t))f_30d693ef8a8db365)(p1); }
/* f236 */
int64_t f_620db28fc978a369(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 236, (LUST_SO(lust_so_620db28fc978a369) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_620db28fc978a369(int64_t p1) { return ((int64_t (*)(int64_t))f_620db28fc978a369)(p1); }
/* f237 */
int64_t f_6e4405b3ba9ae8cd(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 237, (LUST_SO(lust_so_6e4405b3ba9ae8cd) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_6e4405b3ba9ae8cd(int64_t p1) { return ((int64_t (*)(int64_t))f_6e4405b3ba9ae8cd)(p1); }
/* f238 */
int64_t f_021870c95b651de6(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 238, (LUST_SO(lust_so_021870c95b651de6) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_021870c95b651de6(int64_t p1) { return ((int64_t (*)(int64_t))f_021870c95b651de6)(p1); }
/* f239 */
int64_t f_d6b19d45cc583106(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 239, (LUST_SO(lust_so_d6b19d45cc583106) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d6b19d45cc583106(int64_t p1) { return ((int64_t (*)(int64_t))f_d6b19d45cc583106)(p1); }
/* f240 */
int64_t f_e54911916a943a85(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 240, (LUST_SO(lust_so_e54911916a943a85) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e54911916a943a85(int64_t p1) { return ((int64_t (*)(int64_t))f_e54911916a943a85)(p1); }
/* f241 */
int64_t f_f8481ab24b3f511b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 241, (LUST_SO(lust_so_f8481ab24b3f511b) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_f8481ab24b3f511b(int64_t p1) { return ((int64_t (*)(int64_t))f_f8481ab24b3f511b)(p1); }
/* f242 */
int64_t f_4c12e097fbcce7de(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 242, (LUST_SO(lust_so_4c12e097fbcce7de) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_4c12e097fbcce7de(int64_t p1) { return ((int64_t (*)(int64_t))f_4c12e097fbcce7de)(p1); }
/* f243 */
int64_t f_e01d5f31b4d85cfb(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 243, (LUST_SO(lust_so_e01d5f31b4d85cfb) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e01d5f31b4d85cfb(int64_t p1) { return ((int64_t (*)(int64_t))f_e01d5f31b4d85cfb)(p1); }
/* f244 */
int64_t f_d55eeee98958238e(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 244, (LUST_SO(lust_so_d55eeee98958238e) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d55eeee98958238e(int64_t p1) { return ((int64_t (*)(int64_t))f_d55eeee98958238e)(p1); }
/* f245 */
int64_t f_d3e6eb48954cf171(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 245, (LUST_SO(lust_so_d3e6eb48954cf171) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d3e6eb48954cf171(int64_t p1) { return ((int64_t (*)(int64_t))f_d3e6eb48954cf171)(p1); }
/* f246 */
int64_t f_7a53a66349ac8302(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 246, (LUST_SO(lust_so_7a53a66349ac8302) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_7a53a66349ac8302(int64_t p1) { return ((int64_t (*)(int64_t))f_7a53a66349ac8302)(p1); }
/* f247 */
int64_t f_695bb3edb1c10eb8(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 247, (LUST_SO(lust_so_695bb3edb1c10eb8) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_695bb3edb1c10eb8(int64_t p1) { return ((int64_t (*)(int64_t))f_695bb3edb1c10eb8)(p1); }
/* f248 */
int64_t f_fa713bfc79ead375(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 248, (LUST_SO(lust_so_fa713bfc79ead375) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_fa713bfc79ead375(int64_t p1) { return ((int64_t (*)(int64_t))f_fa713bfc79ead375)(p1); }
/* f249 */
int64_t f_2f2e9ac6ca7c78c1(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 249, (LUST_SO(lust_so_2f2e9ac6ca7c78c1) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_2f2e9ac6ca7c78c1(int64_t p1) { return ((int64_t (*)(int64_t))f_2f2e9ac6ca7c78c1)(p1); }
/* f250 */
int64_t f_aeaa10c2868c2544(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 250, (LUST_SO(lust_so_aeaa10c2868c2544) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_aeaa10c2868c2544(int64_t p1) { return ((int64_t (*)(int64_t))f_aeaa10c2868c2544)(p1); }
/* f251 */
int64_t f_e4e91ccae01e4b9c(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 251, (LUST_SO(lust_so_e4e91ccae01e4b9c) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_e4e91ccae01e4b9c(int64_t p1) { return ((int64_t (*)(int64_t))f_e4e91ccae01e4b9c)(p1); }
/* f252 */
int64_t f_1c9278ae0079e571(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 252, (LUST_SO(lust_so_1c9278ae0079e571) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_1c9278ae0079e571(int64_t p1) { return ((int64_t (*)(int64_t))f_1c9278ae0079e571)(p1); }
/* f253 */
int64_t f_0c7edc7c286c654b(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 253, (LUST_SO(lust_so_0c7edc7c286c654b) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_0c7edc7c286c654b(int64_t p1) { return ((int64_t (*)(int64_t))f_0c7edc7c286c654b)(p1); }
/* f254 */
int64_t f_99a5f75c4fcb0ec9(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 254, (LUST_SO(lust_so_99a5f75c4fcb0ec9) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_99a5f75c4fcb0ec9(int64_t p1) { return ((int64_t (*)(int64_t))f_99a5f75c4fcb0ec9)(p1); }
/* f255 */
int64_t f_d18a6c484a3658d5(int64_t p1) {
  int64_t l0, l1 = p1;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((int64_t){0});
bb0:;
  l0 = lust_add_i64(l1, 255, (LUST_SO(lust_so_d18a6c484a3658d5) | 26ull));
  LUST_UNW(2);
  return l0;
bb1:;
  lust_unw_resume(&ex);
  return ((int64_t){0});
bb2:;
  goto bb1;
}

int64_t tramp_d18a6c484a3658d5(int64_t p1) { return ((int64_t (*)(int64_t))f_d18a6c484a3658d5)(p1); }
/* main */
lust_Unit f_dce795fb70dcd531(void) {
  lust_Unit l0;
  int64_t l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13, l14, l15, l16, l17, l18, l19, l20, l21, l22, l23, l24, l25, l26, l27, l28, l29, l30, l31, l32, l33, l34, l35, l36, l37, l38, l39, l40, l41, l42, l43, l44, l45, l46, l47, l48, l49, l50, l51, l52, l53, l54, l55, l56, l57, l58, l59, l60, l61, l62, l63, l64, l65, l66, l67, l68, l69, l70, l71, l72, l73, l74, l75, l76, l77, l78, l79, l80, l81, l82, l83, l84, l85, l86, l87, l88, l89, l90, l91, l92, l93, l94, l95, l96, l97, l98, l99, l100, l101, l102, l103, l104, l105, l106, l107, l108, l109, l110, l111, l112, l113, l114, l115, l116, l117, l118, l119, l120, l121, l122, l123, l124, l125, l126, l127, l128, l129, l130, l131, l132, l133, l134, l135, l136, l137, l138, l139, l140, l141, l142, l143, l144, l145, l146, l147, l148, l149, l150, l151, l152, l153, l154, l155, l156, l157, l158, l159, l160, l161, l162, l163, l164, l165, l166, l167, l168, l169, l170, l171, l172, l173, l174, l175, l176, l177, l178, l179, l180, l181, l182, l183, l184, l185, l186, l187, l188, l189, l190, l191, l192, l193, l194, l195, l196, l197, l198, l199, l200, l201, l202, l203, l204, l205, l206, l207, l208, l209, l210, l211, l212, l213, l214, l215, l216, l217, l218, l219, l220, l221, l222, l223, l224, l225, l226, l227, l228, l229, l230, l231, l232, l233, l234, l235, l236, l237, l238, l239, l240, l241, l242, l243, l244, l245, l246, l247, l248, l249, l250, l251, l252, l253, l254, l255, l256, l257, l258, l259, l260, l261, l262, l263, l264, l265, l266, l267, l268, l269, l270, l271, l272, l273, l274, l275, l276, l277, l278, l279, l280, l281, l282, l283, l284, l285, l286, l287, l288, l289, l290, l291, l292, l293, l294, l295, l296, l297, l298, l299, l300, l301, l302, l303, l304, l305, l306, l307, l308, l309, l310, l311, l312, l313, l314, l315, l316, l317, l318, l319, l320, l321, l322, l323, l324, l325, l326, l327, l328, l329, l330, l331, l332, l333, l334, l335, l336, l337, l338, l339, l340, l341, l342, l343, l344, l345, l346, l347, l348, l349, l350, l351, l352, l353, l354, l355, l356, l357, l358, l359, l360, l361, l362, l363, l364, l365, l366, l367, l368, l369, l370, l371, l372, l373, l374, l375, l376, l377, l378, l379, l380, l381, l382, l383, l384, l385, l386, l387, l388, l389, l390, l391, l392, l393, l394, l395, l396, l397, l398, l399, l400, l401, l402, l403, l404, l405, l406, l407, l408, l409, l410, l411, l412, l413, l414, l415, l416, l417, l418, l419, l420, l421, l422, l423, l424, l425, l426, l427, l428, l429, l430, l431, l432, l433, l434, l435, l436, l437, l438, l439, l440, l441, l442, l443, l444, l445, l446, l447, l448, l449, l450, l451, l452, l453, l454, l455, l456, l457, l458, l459, l460, l461, l462, l463, l464, l465, l466, l467, l468, l469, l470, l471, l472, l473, l474, l475, l476, l477, l478, l479, l480, l481, l482, l483, l484, l485, l486, l487, l488, l489, l490, l491, l492, l493, l494, l495, l496, l497, l498, l499, l500, l501, l502, l503, l504, l505, l506, l507, l508, l509, l510, l511, l512;
  int64_t *l513;
  lust_exc ex;
  if (lust_unw_pending && lust_unw_mine()) return ((lust_Unit){});
bb0:;
  {
    int64_t t1 = ((int64_t (*)(int64_t))f_adbf27a4aa538938)(1);
    LUST_UNW(3);
    l4 = t1;
  }
bb1:;
  {
    int64_t t2 = ((int64_t (*)(int64_t))f_c79f5289847e038f)(1);
    LUST_UNW(5);
    l5 = t2;
  }
  goto bb4;
bb2:;
  lust_unw_resume(&ex);
  return ((lust_Unit){});
bb3:;
  goto bb2;
bb4:;
  l3 = lust_add_i64(l4, l5, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(6);
  {
    int64_t t3 = ((int64_t (*)(int64_t))f_6afdaa287dc7b46d)(1);
    LUST_UNW(8);
    l7 = t3;
  }
  goto bb7;
bb5:;
  goto bb3;
bb6:;
  goto bb5;
bb7:;
  l6 = lust_add_i64(l3, l7, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(9);
  {
    int64_t t4 = ((int64_t (*)(int64_t))f_6f463f8753b25553)(1);
    LUST_UNW(11);
    l9 = t4;
  }
  goto bb10;
bb8:;
  goto bb6;
bb9:;
  goto bb8;
bb10:;
  l8 = lust_add_i64(l6, l9, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(12);
  {
    int64_t t5 = ((int64_t (*)(int64_t))f_3f4ec28af0af87ed)(1);
    LUST_UNW(14);
    l11 = t5;
  }
  goto bb13;
bb11:;
  goto bb9;
bb12:;
  goto bb11;
bb13:;
  l10 = lust_add_i64(l8, l11, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(15);
  {
    int64_t t6 = ((int64_t (*)(int64_t))f_ad04d27fc2cdfb3c)(1);
    LUST_UNW(17);
    l13 = t6;
  }
  goto bb16;
bb14:;
  goto bb12;
bb15:;
  goto bb14;
bb16:;
  l12 = lust_add_i64(l10, l13, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(18);
  {
    int64_t t7 = ((int64_t (*)(int64_t))f_6e1944b2fe6a358b)(1);
    LUST_UNW(20);
    l15 = t7;
  }
  goto bb19;
bb17:;
  goto bb15;
bb18:;
  goto bb17;
bb19:;
  l14 = lust_add_i64(l12, l15, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(21);
  {
    int64_t t8 = ((int64_t (*)(int64_t))f_655ce0fd6e9f8f21)(1);
    LUST_UNW(23);
    l17 = t8;
  }
  goto bb22;
bb20:;
  goto bb18;
bb21:;
  goto bb20;
bb22:;
  l16 = lust_add_i64(l14, l17, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(24);
  {
    int64_t t9 = ((int64_t (*)(int64_t))f_6acbb85cbb2e7d8e)(1);
    LUST_UNW(26);
    l19 = t9;
  }
  goto bb25;
bb23:;
  goto bb21;
bb24:;
  goto bb23;
bb25:;
  l18 = lust_add_i64(l16, l19, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(27);
  {
    int64_t t10 = ((int64_t (*)(int64_t))f_6bbf40f32abb7d72)(1);
    LUST_UNW(29);
    l21 = t10;
  }
  goto bb28;
bb26:;
  goto bb24;
bb27:;
  goto bb26;
bb28:;
  l20 = lust_add_i64(l18, l21, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(30);
  {
    int64_t t11 = ((int64_t (*)(int64_t))f_70290558c3854fb9)(1);
    LUST_UNW(32);
    l23 = t11;
  }
  goto bb31;
bb29:;
  goto bb27;
bb30:;
  goto bb29;
bb31:;
  l22 = lust_add_i64(l20, l23, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(33);
  {
    int64_t t12 = ((int64_t (*)(int64_t))f_ddff6c6a396f760c)(1);
    LUST_UNW(35);
    l25 = t12;
  }
  goto bb34;
bb32:;
  goto bb30;
bb33:;
  goto bb32;
bb34:;
  l24 = lust_add_i64(l22, l25, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(36);
  {
    int64_t t13 = ((int64_t (*)(int64_t))f_7947f7854c604f66)(1);
    LUST_UNW(38);
    l27 = t13;
  }
  goto bb37;
bb35:;
  goto bb33;
bb36:;
  goto bb35;
bb37:;
  l26 = lust_add_i64(l24, l27, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(39);
  {
    int64_t t14 = ((int64_t (*)(int64_t))f_f653010808001fef)(1);
    LUST_UNW(41);
    l29 = t14;
  }
  goto bb40;
bb38:;
  goto bb36;
bb39:;
  goto bb38;
bb40:;
  l28 = lust_add_i64(l26, l29, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(42);
  {
    int64_t t15 = ((int64_t (*)(int64_t))f_2b593d17738a060e)(1);
    LUST_UNW(44);
    l31 = t15;
  }
  goto bb43;
bb41:;
  goto bb39;
bb42:;
  goto bb41;
bb43:;
  l30 = lust_add_i64(l28, l31, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(45);
  {
    int64_t t16 = ((int64_t (*)(int64_t))f_5c9dc143e9da7d53)(1);
    LUST_UNW(47);
    l33 = t16;
  }
  goto bb46;
bb44:;
  goto bb42;
bb45:;
  goto bb44;
bb46:;
  l32 = lust_add_i64(l30, l33, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(48);
  {
    int64_t t17 = ((int64_t (*)(int64_t))f_2078ff17ac329a01)(1);
    LUST_UNW(50);
    l35 = t17;
  }
  goto bb49;
bb47:;
  goto bb45;
bb48:;
  goto bb47;
bb49:;
  l34 = lust_add_i64(l32, l35, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(51);
  {
    int64_t t18 = ((int64_t (*)(int64_t))f_943e8f8cf84336e8)(1);
    LUST_UNW(53);
    l37 = t18;
  }
  goto bb52;
bb50:;
  goto bb48;
bb51:;
  goto bb50;
bb52:;
  l36 = lust_add_i64(l34, l37, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(54);
  {
    int64_t t19 = ((int64_t (*)(int64_t))f_bdc4f598f746dc19)(1);
    LUST_UNW(56);
    l39 = t19;
  }
  goto bb55;
bb53:;
  goto bb51;
bb54:;
  goto bb53;
bb55:;
  l38 = lust_add_i64(l36, l39, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(57);
  {
    int64_t t20 = ((int64_t (*)(int64_t))f_5ad1fa64abc416bb)(1);
    LUST_UNW(59);
    l41 = t20;
  }
  goto bb58;
bb56:;
  goto bb54;
bb57:;
  goto bb56;
bb58:;
  l40 = lust_add_i64(l38, l41, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(60);
  {
    int64_t t21 = ((int64_t (*)(int64_t))f_5c7925721244787b)(1);
    LUST_UNW(62);
    l43 = t21;
  }
  goto bb61;
bb59:;
  goto bb57;
bb60:;
  goto bb59;
bb61:;
  l42 = lust_add_i64(l40, l43, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(63);
  {
    int64_t t22 = ((int64_t (*)(int64_t))f_0089922f873e38d8)(1);
    LUST_UNW(65);
    l45 = t22;
  }
  goto bb64;
bb62:;
  goto bb60;
bb63:;
  goto bb62;
bb64:;
  l44 = lust_add_i64(l42, l45, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(66);
  {
    int64_t t23 = ((int64_t (*)(int64_t))f_f9a7093afd8ecc61)(1);
    LUST_UNW(68);
    l47 = t23;
  }
  goto bb67;
bb65:;
  goto bb63;
bb66:;
  goto bb65;
bb67:;
  l46 = lust_add_i64(l44, l47, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(69);
  {
    int64_t t24 = ((int64_t (*)(int64_t))f_87cff378ae434a46)(1);
    LUST_UNW(71);
    l49 = t24;
  }
  goto bb70;
bb68:;
  goto bb66;
bb69:;
  goto bb68;
bb70:;
  l48 = lust_add_i64(l46, l49, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(72);
  {
    int64_t t25 = ((int64_t (*)(int64_t))f_12702f75bc3606fc)(1);
    LUST_UNW(74);
    l51 = t25;
  }
  goto bb73;
bb71:;
  goto bb69;
bb72:;
  goto bb71;
bb73:;
  l50 = lust_add_i64(l48, l51, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(75);
  {
    int64_t t26 = ((int64_t (*)(int64_t))f_92ce47b1381db64b)(1);
    LUST_UNW(77);
    l53 = t26;
  }
  goto bb76;
bb74:;
  goto bb72;
bb75:;
  goto bb74;
bb76:;
  l52 = lust_add_i64(l50, l53, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(78);
  {
    int64_t t27 = ((int64_t (*)(int64_t))f_6e8e244a2fa8357b)(1);
    LUST_UNW(80);
    l55 = t27;
  }
  goto bb79;
bb77:;
  goto bb75;
bb78:;
  goto bb77;
bb79:;
  l54 = lust_add_i64(l52, l55, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(81);
  {
    int64_t t28 = ((int64_t (*)(int64_t))f_f7de1765bb06efd7)(1);
    LUST_UNW(83);
    l57 = t28;
  }
  goto bb82;
bb80:;
  goto bb78;
bb81:;
  goto bb80;
bb82:;
  l56 = lust_add_i64(l54, l57, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(84);
  {
    int64_t t29 = ((int64_t (*)(int64_t))f_2e5694287e99ac3e)(1);
    LUST_UNW(86);
    l59 = t29;
  }
  goto bb85;
bb83:;
  goto bb81;
bb84:;
  goto bb83;
bb85:;
  l58 = lust_add_i64(l56, l59, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(87);
  {
    int64_t t30 = ((int64_t (*)(int64_t))f_cf8c94538d1bc2d3)(1);
    LUST_UNW(89);
    l61 = t30;
  }
  goto bb88;
bb86:;
  goto bb84;
bb87:;
  goto bb86;
bb88:;
  l60 = lust_add_i64(l58, l61, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(90);
  {
    int64_t t31 = ((int64_t (*)(int64_t))f_09e3e50757e03460)(1);
    LUST_UNW(92);
    l63 = t31;
  }
  goto bb91;
bb89:;
  goto bb87;
bb90:;
  goto bb89;
bb91:;
  l62 = lust_add_i64(l60, l63, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(93);
  {
    int64_t t32 = ((int64_t (*)(int64_t))f_e769b61a53b62242)(1);
    LUST_UNW(95);
    l65 = t32;
  }
  goto bb94;
bb92:;
  goto bb90;
bb93:;
  goto bb92;
bb94:;
  l64 = lust_add_i64(l62, l65, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(96);
  {
    int64_t t33 = ((int64_t (*)(int64_t))f_5d2dbb14d0ce22e9)(1);
    LUST_UNW(98);
    l67 = t33;
  }
  goto bb97;
bb95:;
  goto bb93;
bb96:;
  goto bb95;
bb97:;
  l66 = lust_add_i64(l64, l67, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(99);
  {
    int64_t t34 = ((int64_t (*)(int64_t))f_e98d639fd11282c0)(1);
    LUST_UNW(101);
    l69 = t34;
  }
  goto bb100;
bb98:;
  goto bb96;
bb99:;
  goto bb98;
bb100:;
  l68 = lust_add_i64(l66, l69, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(102);
  {
    int64_t t35 = ((int64_t (*)(int64_t))f_2a25936bc256da60)(1);
    LUST_UNW(104);
    l71 = t35;
  }
  goto bb103;
bb101:;
  goto bb99;
bb102:;
  goto bb101;
bb103:;
  l70 = lust_add_i64(l68, l71, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(105);
  {
    int64_t t36 = ((int64_t (*)(int64_t))f_c6638f0d95ea3dd3)(1);
    LUST_UNW(107);
    l73 = t36;
  }
  goto bb106;
bb104:;
  goto bb102;
bb105:;
  goto bb104;
bb106:;
  l72 = lust_add_i64(l70, l73, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(108);
  {
    int64_t t37 = ((int64_t (*)(int64_t))f_ef0f666527735563)(1);
    LUST_UNW(110);
    l75 = t37;
  }
  goto bb109;
bb107:;
  goto bb105;
bb108:;
  goto bb107;
bb109:;
  l74 = lust_add_i64(l72, l75, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(111);
  {
    int64_t t38 = ((int64_t (*)(int64_t))f_4a95db6a3015731d)(1);
    LUST_UNW(113);
    l77 = t38;
  }
  goto bb112;
bb110:;
  goto bb108;
bb111:;
  goto bb110;
bb112:;
  l76 = lust_add_i64(l74, l77, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(114);
  {
    int64_t t39 = ((int64_t (*)(int64_t))f_f6f6b74f6101424e)(1);
    LUST_UNW(116);
    l79 = t39;
  }
  goto bb115;
bb113:;
  goto bb111;
bb114:;
  goto bb113;
bb115:;
  l78 = lust_add_i64(l76, l79, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(117);
  {
    int64_t t40 = ((int64_t (*)(int64_t))f_8a71922da969ce56)(1);
    LUST_UNW(119);
    l81 = t40;
  }
  goto bb118;
bb116:;
  goto bb114;
bb117:;
  goto bb116;
bb118:;
  l80 = lust_add_i64(l78, l81, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(120);
  {
    int64_t t41 = ((int64_t (*)(int64_t))f_240f7fa254e78590)(1);
    LUST_UNW(122);
    l83 = t41;
  }
  goto bb121;
bb119:;
  goto bb117;
bb120:;
  goto bb119;
bb121:;
  l82 = lust_add_i64(l80, l83, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(123);
  {
    int64_t t42 = ((int64_t (*)(int64_t))f_2cd42e81d294ab1f)(1);
    LUST_UNW(125);
    l85 = t42;
  }
  goto bb124;
bb122:;
  goto bb120;
bb123:;
  goto bb122;
bb124:;
  l84 = lust_add_i64(l82, l85, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(126);
  {
    int64_t t43 = ((int64_t (*)(int64_t))f_d378c8c7e1032688)(1);
    LUST_UNW(128);
    l87 = t43;
  }
  goto bb127;
bb125:;
  goto bb123;
bb126:;
  goto bb125;
bb127:;
  l86 = lust_add_i64(l84, l87, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(129);
  {
    int64_t t44 = ((int64_t (*)(int64_t))f_a0f8e459a09ace25)(1);
    LUST_UNW(131);
    l89 = t44;
  }
  goto bb130;
bb128:;
  goto bb126;
bb129:;
  goto bb128;
bb130:;
  l88 = lust_add_i64(l86, l89, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(132);
  {
    int64_t t45 = ((int64_t (*)(int64_t))f_6e187b64e783cbf8)(1);
    LUST_UNW(134);
    l91 = t45;
  }
  goto bb133;
bb131:;
  goto bb129;
bb132:;
  goto bb131;
bb133:;
  l90 = lust_add_i64(l88, l91, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(135);
  {
    int64_t t46 = ((int64_t (*)(int64_t))f_ab22ab135cfc7f03)(1);
    LUST_UNW(137);
    l93 = t46;
  }
  goto bb136;
bb134:;
  goto bb132;
bb135:;
  goto bb134;
bb136:;
  l92 = lust_add_i64(l90, l93, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(138);
  {
    int64_t t47 = ((int64_t (*)(int64_t))f_253a7c9afe971794)(1);
    LUST_UNW(140);
    l95 = t47;
  }
  goto bb139;
bb137:;
  goto bb135;
bb138:;
  goto bb137;
bb139:;
  l94 = lust_add_i64(l92, l95, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(141);
  {
    int64_t t48 = ((int64_t (*)(int64_t))f_aa87e869bcb3deb3)(1);
    LUST_UNW(143);
    l97 = t48;
  }
  goto bb142;
bb140:;
  goto bb138;
bb141:;
  goto bb140;
bb142:;
  l96 = lust_add_i64(l94, l97, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(144);
  {
    int64_t t49 = ((int64_t (*)(int64_t))f_e9774056f07cacb8)(1);
    LUST_UNW(146);
    l99 = t49;
  }
  goto bb145;
bb143:;
  goto bb141;
bb144:;
  goto bb143;
bb145:;
  l98 = lust_add_i64(l96, l99, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(147);
  {
    int64_t t50 = ((int64_t (*)(int64_t))f_0c57b10e9de4dd8c)(1);
    LUST_UNW(149);
    l101 = t50;
  }
  goto bb148;
bb146:;
  goto bb144;
bb147:;
  goto bb146;
bb148:;
  l100 = lust_add_i64(l98, l101, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(150);
  {
    int64_t t51 = ((int64_t (*)(int64_t))f_936007394ada7049)(1);
    LUST_UNW(152);
    l103 = t51;
  }
  goto bb151;
bb149:;
  goto bb147;
bb150:;
  goto bb149;
bb151:;
  l102 = lust_add_i64(l100, l103, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(153);
  {
    int64_t t52 = ((int64_t (*)(int64_t))f_2c6f8781d6a6b594)(1);
    LUST_UNW(155);
    l105 = t52;
  }
  goto bb154;
bb152:;
  goto bb150;
bb153:;
  goto bb152;
bb154:;
  l104 = lust_add_i64(l102, l105, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(156);
  {
    int64_t t53 = ((int64_t (*)(int64_t))f_9214820078ceddbb)(1);
    LUST_UNW(158);
    l107 = t53;
  }
  goto bb157;
bb155:;
  goto bb153;
bb156:;
  goto bb155;
bb157:;
  l106 = lust_add_i64(l104, l107, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(159);
  {
    int64_t t54 = ((int64_t (*)(int64_t))f_329644254774d78c)(1);
    LUST_UNW(161);
    l109 = t54;
  }
  goto bb160;
bb158:;
  goto bb156;
bb159:;
  goto bb158;
bb160:;
  l108 = lust_add_i64(l106, l109, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(162);
  {
    int64_t t55 = ((int64_t (*)(int64_t))f_89d4af82d3c42b68)(1);
    LUST_UNW(164);
    l111 = t55;
  }
  goto bb163;
bb161:;
  goto bb159;
bb162:;
  goto bb161;
bb163:;
  l110 = lust_add_i64(l108, l111, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(165);
  {
    int64_t t56 = ((int64_t (*)(int64_t))f_d7d3446327da7cef)(1);
    LUST_UNW(167);
    l113 = t56;
  }
  goto bb166;
bb164:;
  goto bb162;
bb165:;
  goto bb164;
bb166:;
  l112 = lust_add_i64(l110, l113, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(168);
  {
    int64_t t57 = ((int64_t (*)(int64_t))f_9d55f24516cc9be7)(1);
    LUST_UNW(170);
    l115 = t57;
  }
  goto bb169;
bb167:;
  goto bb165;
bb168:;
  goto bb167;
bb169:;
  l114 = lust_add_i64(l112, l115, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(171);
  {
    int64_t t58 = ((int64_t (*)(int64_t))f_18da39ea0dcd4fe7)(1);
    LUST_UNW(173);
    l117 = t58;
  }
  goto bb172;
bb170:;
  goto bb168;
bb171:;
  goto bb170;
bb172:;
  l116 = lust_add_i64(l114, l117, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(174);
  {
    int64_t t59 = ((int64_t (*)(int64_t))f_8be47e3af2fd50aa)(1);
    LUST_UNW(176);
    l119 = t59;
  }
  goto bb175;
bb173:;
  goto bb171;
bb174:;
  goto bb173;
bb175:;
  l118 = lust_add_i64(l116, l119, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(177);
  {
    int64_t t60 = ((int64_t (*)(int64_t))f_d4e70a7d5e27f6a1)(1);
    LUST_UNW(179);
    l121 = t60;
  }
  goto bb178;
bb176:;
  goto bb174;
bb177:;
  goto bb176;
bb178:;
  l120 = lust_add_i64(l118, l121, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(180);
  {
    int64_t t61 = ((int64_t (*)(int64_t))f_00b418e2a8d3f4dd)(1);
    LUST_UNW(182);
    l123 = t61;
  }
  goto bb181;
bb179:;
  goto bb177;
bb180:;
  goto bb179;
bb181:;
  l122 = lust_add_i64(l120, l123, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(183);
  {
    int64_t t62 = ((int64_t (*)(int64_t))f_9ed5d1843e39fe4b)(1);
    LUST_UNW(185);
    l125 = t62;
  }
  goto bb184;
bb182:;
  goto bb180;
bb183:;
  goto bb182;
bb184:;
  l124 = lust_add_i64(l122, l125, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(186);
  {
    int64_t t63 = ((int64_t (*)(int64_t))f_47299ff23f5ec4ae)(1);
    LUST_UNW(188);
    l127 = t63;
  }
  goto bb187;
bb185:;
  goto bb183;
bb186:;
  goto bb185;
bb187:;
  l126 = lust_add_i64(l124, l127, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(189);
  {
    int64_t t64 = ((int64_t (*)(int64_t))f_0d06ace48c74648b)(1);
    LUST_UNW(191);
    l129 = t64;
  }
  goto bb190;
bb188:;
  goto bb186;
bb189:;
  goto bb188;
bb190:;
  l128 = lust_add_i64(l126, l129, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(192);
  {
    int64_t t65 = ((int64_t (*)(int64_t))f_bde25bf2ae01c8a1)(1);
    LUST_UNW(194);
    l131 = t65;
  }
  goto bb193;
bb191:;
  goto bb189;
bb192:;
  goto bb191;
bb193:;
  l130 = lust_add_i64(l128, l131, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(195);
  {
    int64_t t66 = ((int64_t (*)(int64_t))f_3632e762da5fb136)(1);
    LUST_UNW(197);
    l133 = t66;
  }
  goto bb196;
bb194:;
  goto bb192;
bb195:;
  goto bb194;
bb196:;
  l132 = lust_add_i64(l130, l133, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(198);
  {
    int64_t t67 = ((int64_t (*)(int64_t))f_b0c323eee9cbbf8c)(1);
    LUST_UNW(200);
    l135 = t67;
  }
  goto bb199;
bb197:;
  goto bb195;
bb198:;
  goto bb197;
bb199:;
  l134 = lust_add_i64(l132, l135, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(201);
  {
    int64_t t68 = ((int64_t (*)(int64_t))f_338c781c688b5d6d)(1);
    LUST_UNW(203);
    l137 = t68;
  }
  goto bb202;
bb200:;
  goto bb198;
bb201:;
  goto bb200;
bb202:;
  l136 = lust_add_i64(l134, l137, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(204);
  {
    int64_t t69 = ((int64_t (*)(int64_t))f_3754d36cda7d7a79)(1);
    LUST_UNW(206);
    l139 = t69;
  }
  goto bb205;
bb203:;
  goto bb201;
bb204:;
  goto bb203;
bb205:;
  l138 = lust_add_i64(l136, l139, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(207);
  {
    int64_t t70 = ((int64_t (*)(int64_t))f_f7b85ea6c34fd168)(1);
    LUST_UNW(209);
    l141 = t70;
  }
  goto bb208;
bb206:;
  goto bb204;
bb207:;
  goto bb206;
bb208:;
  l140 = lust_add_i64(l138, l141, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(210);
  {
    int64_t t71 = ((int64_t (*)(int64_t))f_0b073575bb69bcd4)(1);
    LUST_UNW(212);
    l143 = t71;
  }
  goto bb211;
bb209:;
  goto bb207;
bb210:;
  goto bb209;
bb211:;
  l142 = lust_add_i64(l140, l143, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(213);
  {
    int64_t t72 = ((int64_t (*)(int64_t))f_41cbbd13fba6099f)(1);
    LUST_UNW(215);
    l145 = t72;
  }
  goto bb214;
bb212:;
  goto bb210;
bb213:;
  goto bb212;
bb214:;
  l144 = lust_add_i64(l142, l145, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(216);
  {
    int64_t t73 = ((int64_t (*)(int64_t))f_a5063c8e6d67a08a)(1);
    LUST_UNW(218);
    l147 = t73;
  }
  goto bb217;
bb215:;
  goto bb213;
bb216:;
  goto bb215;
bb217:;
  l146 = lust_add_i64(l144, l147, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(219);
  {
    int64_t t74 = ((int64_t (*)(int64_t))f_fa94b520e37fcf69)(1);
    LUST_UNW(221);
    l149 = t74;
  }
  goto bb220;
bb218:;
  goto bb216;
bb219:;
  goto bb218;
bb220:;
  l148 = lust_add_i64(l146, l149, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(222);
  {
    int64_t t75 = ((int64_t (*)(int64_t))f_970944ee43a3b66f)(1);
    LUST_UNW(224);
    l151 = t75;
  }
  goto bb223;
bb221:;
  goto bb219;
bb222:;
  goto bb221;
bb223:;
  l150 = lust_add_i64(l148, l151, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(225);
  {
    int64_t t76 = ((int64_t (*)(int64_t))f_f8dcb7425084658c)(1);
    LUST_UNW(227);
    l153 = t76;
  }
  goto bb226;
bb224:;
  goto bb222;
bb225:;
  goto bb224;
bb226:;
  l152 = lust_add_i64(l150, l153, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(228);
  {
    int64_t t77 = ((int64_t (*)(int64_t))f_cfb1cbd45320491a)(1);
    LUST_UNW(230);
    l155 = t77;
  }
  goto bb229;
bb227:;
  goto bb225;
bb228:;
  goto bb227;
bb229:;
  l154 = lust_add_i64(l152, l155, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(231);
  {
    int64_t t78 = ((int64_t (*)(int64_t))f_7d99980989f90053)(1);
    LUST_UNW(233);
    l157 = t78;
  }
  goto bb232;
bb230:;
  goto bb228;
bb231:;
  goto bb230;
bb232:;
  l156 = lust_add_i64(l154, l157, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(234);
  {
    int64_t t79 = ((int64_t (*)(int64_t))f_a3f1b5fbf06821a7)(1);
    LUST_UNW(236);
    l159 = t79;
  }
  goto bb235;
bb233:;
  goto bb231;
bb234:;
  goto bb233;
bb235:;
  l158 = lust_add_i64(l156, l159, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(237);
  {
    int64_t t80 = ((int64_t (*)(int64_t))f_70af7dfa8b9d5d33)(1);
    LUST_UNW(239);
    l161 = t80;
  }
  goto bb238;
bb236:;
  goto bb234;
bb237:;
  goto bb236;
bb238:;
  l160 = lust_add_i64(l158, l161, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(240);
  {
    int64_t t81 = ((int64_t (*)(int64_t))f_b63f7579466b8d16)(1);
    LUST_UNW(242);
    l163 = t81;
  }
  goto bb241;
bb239:;
  goto bb237;
bb240:;
  goto bb239;
bb241:;
  l162 = lust_add_i64(l160, l163, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(243);
  {
    int64_t t82 = ((int64_t (*)(int64_t))f_658c60881d177a73)(1);
    LUST_UNW(245);
    l165 = t82;
  }
  goto bb244;
bb242:;
  goto bb240;
bb243:;
  goto bb242;
bb244:;
  l164 = lust_add_i64(l162, l165, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(246);
  {
    int64_t t83 = ((int64_t (*)(int64_t))f_aaca894fd5dd8d5d)(1);
    LUST_UNW(248);
    l167 = t83;
  }
  goto bb247;
bb245:;
  goto bb243;
bb246:;
  goto bb245;
bb247:;
  l166 = lust_add_i64(l164, l167, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(249);
  {
    int64_t t84 = ((int64_t (*)(int64_t))f_cd810979d9d91403)(1);
    LUST_UNW(251);
    l169 = t84;
  }
  goto bb250;
bb248:;
  goto bb246;
bb249:;
  goto bb248;
bb250:;
  l168 = lust_add_i64(l166, l169, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(252);
  {
    int64_t t85 = ((int64_t (*)(int64_t))f_cf3d129250fb9f97)(1);
    LUST_UNW(254);
    l171 = t85;
  }
  goto bb253;
bb251:;
  goto bb249;
bb252:;
  goto bb251;
bb253:;
  l170 = lust_add_i64(l168, l171, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(255);
  {
    int64_t t86 = ((int64_t (*)(int64_t))f_ce5002bd14c1ad21)(1);
    LUST_UNW(257);
    l173 = t86;
  }
  goto bb256;
bb254:;
  goto bb252;
bb255:;
  goto bb254;
bb256:;
  l172 = lust_add_i64(l170, l173, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(258);
  {
    int64_t t87 = ((int64_t (*)(int64_t))f_891a81977881c6eb)(1);
    LUST_UNW(260);
    l175 = t87;
  }
  goto bb259;
bb257:;
  goto bb255;
bb258:;
  goto bb257;
bb259:;
  l174 = lust_add_i64(l172, l175, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(261);
  {
    int64_t t88 = ((int64_t (*)(int64_t))f_07a3bf7807baa7ae)(1);
    LUST_UNW(263);
    l177 = t88;
  }
  goto bb262;
bb260:;
  goto bb258;
bb261:;
  goto bb260;
bb262:;
  l176 = lust_add_i64(l174, l177, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(264);
  {
    int64_t t89 = ((int64_t (*)(int64_t))f_e1ba5cf93f404e7c)(1);
    LUST_UNW(266);
    l179 = t89;
  }
  goto bb265;
bb263:;
  goto bb261;
bb264:;
  goto bb263;
bb265:;
  l178 = lust_add_i64(l176, l179, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(267);
  {
    int64_t t90 = ((int64_t (*)(int64_t))f_c6c0593148877aa7)(1);
    LUST_UNW(269);
    l181 = t90;
  }
  goto bb268;
bb266:;
  goto bb264;
bb267:;
  goto bb266;
bb268:;
  l180 = lust_add_i64(l178, l181, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(270);
  {
    int64_t t91 = ((int64_t (*)(int64_t))f_7885811ac870d212)(1);
    LUST_UNW(272);
    l183 = t91;
  }
  goto bb271;
bb269:;
  goto bb267;
bb270:;
  goto bb269;
bb271:;
  l182 = lust_add_i64(l180, l183, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(273);
  {
    int64_t t92 = ((int64_t (*)(int64_t))f_8e6c4336ffc258d8)(1);
    LUST_UNW(275);
    l185 = t92;
  }
  goto bb274;
bb272:;
  goto bb270;
bb273:;
  goto bb272;
bb274:;
  l184 = lust_add_i64(l182, l185, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(276);
  {
    int64_t t93 = ((int64_t (*)(int64_t))f_13e778d589c9a46d)(1);
    LUST_UNW(278);
    l187 = t93;
  }
  goto bb277;
bb275:;
  goto bb273;
bb276:;
  goto bb275;
bb277:;
  l186 = lust_add_i64(l184, l187, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(279);
  {
    int64_t t94 = ((int64_t (*)(int64_t))f_e4e5029593d65e5a)(1);
    LUST_UNW(281);
    l189 = t94;
  }
  goto bb280;
bb278:;
  goto bb276;
bb279:;
  goto bb278;
bb280:;
  l188 = lust_add_i64(l186, l189, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(282);
  {
    int64_t t95 = ((int64_t (*)(int64_t))f_70c48a1a8c6adfa7)(1);
    LUST_UNW(284);
    l191 = t95;
  }
  goto bb283;
bb281:;
  goto bb279;
bb282:;
  goto bb281;
bb283:;
  l190 = lust_add_i64(l188, l191, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(285);
  {
    int64_t t96 = ((int64_t (*)(int64_t))f_2d1c1333514d7c13)(1);
    LUST_UNW(287);
    l193 = t96;
  }
  goto bb286;
bb284:;
  goto bb282;
bb285:;
  goto bb284;
bb286:;
  l192 = lust_add_i64(l190, l193, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(288);
  {
    int64_t t97 = ((int64_t (*)(int64_t))f_9f7c61b72e4fcc01)(1);
    LUST_UNW(290);
    l195 = t97;
  }
  goto bb289;
bb287:;
  goto bb285;
bb288:;
  goto bb287;
bb289:;
  l194 = lust_add_i64(l192, l195, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(291);
  {
    int64_t t98 = ((int64_t (*)(int64_t))f_ad70c3c9ba5354fa)(1);
    LUST_UNW(293);
    l197 = t98;
  }
  goto bb292;
bb290:;
  goto bb288;
bb291:;
  goto bb290;
bb292:;
  l196 = lust_add_i64(l194, l197, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(294);
  {
    int64_t t99 = ((int64_t (*)(int64_t))f_9e761eba787a11a6)(1);
    LUST_UNW(296);
    l199 = t99;
  }
  goto bb295;
bb293:;
  goto bb291;
bb294:;
  goto bb293;
bb295:;
  l198 = lust_add_i64(l196, l199, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(297);
  {
    int64_t t100 = ((int64_t (*)(int64_t))f_9d5e9281db73228e)(1);
    LUST_UNW(299);
    l201 = t100;
  }
  goto bb298;
bb296:;
  goto bb294;
bb297:;
  goto bb296;
bb298:;
  l200 = lust_add_i64(l198, l201, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(300);
  {
    int64_t t101 = ((int64_t (*)(int64_t))f_c2a46654f9cef801)(1);
    LUST_UNW(302);
    l203 = t101;
  }
  goto bb301;
bb299:;
  goto bb297;
bb300:;
  goto bb299;
bb301:;
  l202 = lust_add_i64(l200, l203, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(303);
  {
    int64_t t102 = ((int64_t (*)(int64_t))f_2fe5f5234fa44b6a)(1);
    LUST_UNW(305);
    l205 = t102;
  }
  goto bb304;
bb302:;
  goto bb300;
bb303:;
  goto bb302;
bb304:;
  l204 = lust_add_i64(l202, l205, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(306);
  {
    int64_t t103 = ((int64_t (*)(int64_t))f_f54fbe4a6a7a074f)(1);
    LUST_UNW(308);
    l207 = t103;
  }
  goto bb307;
bb305:;
  goto bb303;
bb306:;
  goto bb305;
bb307:;
  l206 = lust_add_i64(l204, l207, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(309);
  {
    int64_t t104 = ((int64_t (*)(int64_t))f_c8ea4b882354f475)(1);
    LUST_UNW(311);
    l209 = t104;
  }
  goto bb310;
bb308:;
  goto bb306;
bb309:;
  goto bb308;
bb310:;
  l208 = lust_add_i64(l206, l209, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(312);
  {
    int64_t t105 = ((int64_t (*)(int64_t))f_a1ae08b46d2329d8)(1);
    LUST_UNW(314);
    l211 = t105;
  }
  goto bb313;
bb311:;
  goto bb309;
bb312:;
  goto bb311;
bb313:;
  l210 = lust_add_i64(l208, l211, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(315);
  {
    int64_t t106 = ((int64_t (*)(int64_t))f_04e9e8efe4aca037)(1);
    LUST_UNW(317);
    l213 = t106;
  }
  goto bb316;
bb314:;
  goto bb312;
bb315:;
  goto bb314;
bb316:;
  l212 = lust_add_i64(l210, l213, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(318);
  {
    int64_t t107 = ((int64_t (*)(int64_t))f_4e1722ac4a504ac5)(1);
    LUST_UNW(320);
    l215 = t107;
  }
  goto bb319;
bb317:;
  goto bb315;
bb318:;
  goto bb317;
bb319:;
  l214 = lust_add_i64(l212, l215, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(321);
  {
    int64_t t108 = ((int64_t (*)(int64_t))f_37f5a0002796d4b4)(1);
    LUST_UNW(323);
    l217 = t108;
  }
  goto bb322;
bb320:;
  goto bb318;
bb321:;
  goto bb320;
bb322:;
  l216 = lust_add_i64(l214, l217, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(324);
  {
    int64_t t109 = ((int64_t (*)(int64_t))f_29c6b9c153875659)(1);
    LUST_UNW(326);
    l219 = t109;
  }
  goto bb325;
bb323:;
  goto bb321;
bb324:;
  goto bb323;
bb325:;
  l218 = lust_add_i64(l216, l219, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(327);
  {
    int64_t t110 = ((int64_t (*)(int64_t))f_49e54edf4370e849)(1);
    LUST_UNW(329);
    l221 = t110;
  }
  goto bb328;
bb326:;
  goto bb324;
bb327:;
  goto bb326;
bb328:;
  l220 = lust_add_i64(l218, l221, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(330);
  {
    int64_t t111 = ((int64_t (*)(int64_t))f_7a2851b1a45f0f15)(1);
    LUST_UNW(332);
    l223 = t111;
  }
  goto bb331;
bb329:;
  goto bb327;
bb330:;
  goto bb329;
bb331:;
  l222 = lust_add_i64(l220, l223, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(333);
  {
    int64_t t112 = ((int64_t (*)(int64_t))f_d707b29152413470)(1);
    LUST_UNW(335);
    l225 = t112;
  }
  goto bb334;
bb332:;
  goto bb330;
bb333:;
  goto bb332;
bb334:;
  l224 = lust_add_i64(l222, l225, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(336);
  {
    int64_t t113 = ((int64_t (*)(int64_t))f_c6cea8fc00414c66)(1);
    LUST_UNW(338);
    l227 = t113;
  }
  goto bb337;
bb335:;
  goto bb333;
bb336:;
  goto bb335;
bb337:;
  l226 = lust_add_i64(l224, l227, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(339);
  {
    int64_t t114 = ((int64_t (*)(int64_t))f_b74a6175129a725e)(1);
    LUST_UNW(341);
    l229 = t114;
  }
  goto bb340;
bb338:;
  goto bb336;
bb339:;
  goto bb338;
bb340:;
  l228 = lust_add_i64(l226, l229, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(342);
  {
    int64_t t115 = ((int64_t (*)(int64_t))f_63d14ca54dee12cd)(1);
    LUST_UNW(344);
    l231 = t115;
  }
  goto bb343;
bb341:;
  goto bb339;
bb342:;
  goto bb341;
bb343:;
  l230 = lust_add_i64(l228, l231, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(345);
  {
    int64_t t116 = ((int64_t (*)(int64_t))f_a38bd19629179e77)(1);
    LUST_UNW(347);
    l233 = t116;
  }
  goto bb346;
bb344:;
  goto bb342;
bb345:;
  goto bb344;
bb346:;
  l232 = lust_add_i64(l230, l233, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(348);
  {
    int64_t t117 = ((int64_t (*)(int64_t))f_6495393e0ec64505)(1);
    LUST_UNW(350);
    l235 = t117;
  }
  goto bb349;
bb347:;
  goto bb345;
bb348:;
  goto bb347;
bb349:;
  l234 = lust_add_i64(l232, l235, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(351);
  {
    int64_t t118 = ((int64_t (*)(int64_t))f_80222bab3a20ea13)(1);
    LUST_UNW(353);
    l237 = t118;
  }
  goto bb352;
bb350:;
  goto bb348;
bb351:;
  goto bb350;
bb352:;
  l236 = lust_add_i64(l234, l237, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(354);
  {
    int64_t t119 = ((int64_t (*)(int64_t))f_e4e717d2eef775c1)(1);
    LUST_UNW(356);
    l239 = t119;
  }
  goto bb355;
bb353:;
  goto bb351;
bb354:;
  goto bb353;
bb355:;
  l238 = lust_add_i64(l236, l239, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(357);
  {
    int64_t t120 = ((int64_t (*)(int64_t))f_0d0197cb01c4fe35)(1);
    LUST_UNW(359);
    l241 = t120;
  }
  goto bb358;
bb356:;
  goto bb354;
bb357:;
  goto bb356;
bb358:;
  l240 = lust_add_i64(l238, l241, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(360);
  {
    int64_t t121 = ((int64_t (*)(int64_t))f_5ac1125d8167d346)(1);
    LUST_UNW(362);
    l243 = t121;
  }
  goto bb361;
bb359:;
  goto bb357;
bb360:;
  goto bb359;
bb361:;
  l242 = lust_add_i64(l240, l243, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(363);
  {
    int64_t t122 = ((int64_t (*)(int64_t))f_1872984064d4f18e)(1);
    LUST_UNW(365);
    l245 = t122;
  }
  goto bb364;
bb362:;
  goto bb360;
bb363:;
  goto bb362;
bb364:;
  l244 = lust_add_i64(l242, l245, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(366);
  {
    int64_t t123 = ((int64_t (*)(int64_t))f_89ac733e4914b098)(1);
    LUST_UNW(368);
    l247 = t123;
  }
  goto bb367;
bb365:;
  goto bb363;
bb366:;
  goto bb365;
bb367:;
  l246 = lust_add_i64(l244, l247, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(369);
  {
    int64_t t124 = ((int64_t (*)(int64_t))f_12ac54cbfedf3848)(1);
    LUST_UNW(371);
    l249 = t124;
  }
  goto bb370;
bb368:;
  goto bb366;
bb369:;
  goto bb368;
bb370:;
  l248 = lust_add_i64(l246, l249, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(372);
  {
    int64_t t125 = ((int64_t (*)(int64_t))f_4c2f085d58548f35)(1);
    LUST_UNW(374);
    l251 = t125;
  }
  goto bb373;
bb371:;
  goto bb369;
bb372:;
  goto bb371;
bb373:;
  l250 = lust_add_i64(l248, l251, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(375);
  {
    int64_t t126 = ((int64_t (*)(int64_t))f_914347e29880b66e)(1);
    LUST_UNW(377);
    l253 = t126;
  }
  goto bb376;
bb374:;
  goto bb372;
bb375:;
  goto bb374;
bb376:;
  l252 = lust_add_i64(l250, l253, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(378);
  {
    int64_t t127 = ((int64_t (*)(int64_t))f_66bc2c4972581d52)(1);
    LUST_UNW(380);
    l255 = t127;
  }
  goto bb379;
bb377:;
  goto bb375;
bb378:;
  goto bb377;
bb379:;
  l254 = lust_add_i64(l252, l255, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(381);
  {
    int64_t t128 = ((int64_t (*)(int64_t))f_c3ae8b0d935a77e5)(1);
    LUST_UNW(383);
    l257 = t128;
  }
  goto bb382;
bb380:;
  goto bb378;
bb381:;
  goto bb380;
bb382:;
  l256 = lust_add_i64(l254, l257, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(384);
  {
    int64_t t129 = ((int64_t (*)(int64_t))f_b8b23e37bef54b0c)(1);
    LUST_UNW(386);
    l259 = t129;
  }
  goto bb385;
bb383:;
  goto bb381;
bb384:;
  goto bb383;
bb385:;
  l258 = lust_add_i64(l256, l259, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(387);
  {
    int64_t t130 = ((int64_t (*)(int64_t))f_1c09d099eb34e949)(1);
    LUST_UNW(389);
    l261 = t130;
  }
  goto bb388;
bb386:;
  goto bb384;
bb387:;
  goto bb386;
bb388:;
  l260 = lust_add_i64(l258, l261, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(390);
  {
    int64_t t131 = ((int64_t (*)(int64_t))f_1463cb8c99acbf3d)(1);
    LUST_UNW(392);
    l263 = t131;
  }
  goto bb391;
bb389:;
  goto bb387;
bb390:;
  goto bb389;
bb391:;
  l262 = lust_add_i64(l260, l263, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(393);
  {
    int64_t t132 = ((int64_t (*)(int64_t))f_a17acf4a6dbfa03f)(1);
    LUST_UNW(395);
    l265 = t132;
  }
  goto bb394;
bb392:;
  goto bb390;
bb393:;
  goto bb392;
bb394:;
  l264 = lust_add_i64(l262, l265, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(396);
  {
    int64_t t133 = ((int64_t (*)(int64_t))f_6e45a74d048deb19)(1);
    LUST_UNW(398);
    l267 = t133;
  }
  goto bb397;
bb395:;
  goto bb393;
bb396:;
  goto bb395;
bb397:;
  l266 = lust_add_i64(l264, l267, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(399);
  {
    int64_t t134 = ((int64_t (*)(int64_t))f_99dcd08403d20fe8)(1);
    LUST_UNW(401);
    l269 = t134;
  }
  goto bb400;
bb398:;
  goto bb396;
bb399:;
  goto bb398;
bb400:;
  l268 = lust_add_i64(l266, l269, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(402);
  {
    int64_t t135 = ((int64_t (*)(int64_t))f_d20f7f58fb2bfc8e)(1);
    LUST_UNW(404);
    l271 = t135;
  }
  goto bb403;
bb401:;
  goto bb399;
bb402:;
  goto bb401;
bb403:;
  l270 = lust_add_i64(l268, l271, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(405);
  {
    int64_t t136 = ((int64_t (*)(int64_t))f_37eb6940323b7aab)(1);
    LUST_UNW(407);
    l273 = t136;
  }
  goto bb406;
bb404:;
  goto bb402;
bb405:;
  goto bb404;
bb406:;
  l272 = lust_add_i64(l270, l273, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(408);
  {
    int64_t t137 = ((int64_t (*)(int64_t))f_06edc7502cf7934b)(1);
    LUST_UNW(410);
    l275 = t137;
  }
  goto bb409;
bb407:;
  goto bb405;
bb408:;
  goto bb407;
bb409:;
  l274 = lust_add_i64(l272, l275, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(411);
  {
    int64_t t138 = ((int64_t (*)(int64_t))f_c6423313f96f0b06)(1);
    LUST_UNW(413);
    l277 = t138;
  }
  goto bb412;
bb410:;
  goto bb408;
bb411:;
  goto bb410;
bb412:;
  l276 = lust_add_i64(l274, l277, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(414);
  {
    int64_t t139 = ((int64_t (*)(int64_t))f_8fd9c15c0116fcfc)(1);
    LUST_UNW(416);
    l279 = t139;
  }
  goto bb415;
bb413:;
  goto bb411;
bb414:;
  goto bb413;
bb415:;
  l278 = lust_add_i64(l276, l279, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(417);
  {
    int64_t t140 = ((int64_t (*)(int64_t))f_d5b3150a80e91f1a)(1);
    LUST_UNW(419);
    l281 = t140;
  }
  goto bb418;
bb416:;
  goto bb414;
bb417:;
  goto bb416;
bb418:;
  l280 = lust_add_i64(l278, l281, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(420);
  {
    int64_t t141 = ((int64_t (*)(int64_t))f_69c4f02c4698d6f5)(1);
    LUST_UNW(422);
    l283 = t141;
  }
  goto bb421;
bb419:;
  goto bb417;
bb420:;
  goto bb419;
bb421:;
  l282 = lust_add_i64(l280, l283, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(423);
  {
    int64_t t142 = ((int64_t (*)(int64_t))f_ada4b2b6dbfab747)(1);
    LUST_UNW(425);
    l285 = t142;
  }
  goto bb424;
bb422:;
  goto bb420;
bb423:;
  goto bb422;
bb424:;
  l284 = lust_add_i64(l282, l285, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(426);
  {
    int64_t t143 = ((int64_t (*)(int64_t))f_5352b14911e9db26)(1);
    LUST_UNW(428);
    l287 = t143;
  }
  goto bb427;
bb425:;
  goto bb423;
bb426:;
  goto bb425;
bb427:;
  l286 = lust_add_i64(l284, l287, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(429);
  {
    int64_t t144 = ((int64_t (*)(int64_t))f_5c13314d65f7070e)(1);
    LUST_UNW(431);
    l289 = t144;
  }
  goto bb430;
bb428:;
  goto bb426;
bb429:;
  goto bb428;
bb430:;
  l288 = lust_add_i64(l286, l289, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(432);
  {
    int64_t t145 = ((int64_t (*)(int64_t))f_f0497e5c9577df97)(1);
    LUST_UNW(434);
    l291 = t145;
  }
  goto bb433;
bb431:;
  goto bb429;
bb432:;
  goto bb431;
bb433:;
  l290 = lust_add_i64(l288, l291, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(435);
  {
    int64_t t146 = ((int64_t (*)(int64_t))f_aaa278d3820d7c10)(1);
    LUST_UNW(437);
    l293 = t146;
  }
  goto bb436;
bb434:;
  goto bb432;
bb435:;
  goto bb434;
bb436:;
  l292 = lust_add_i64(l290, l293, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(438);
  {
    int64_t t147 = ((int64_t (*)(int64_t))f_09eb54041f570968)(1);
    LUST_UNW(440);
    l295 = t147;
  }
  goto bb439;
bb437:;
  goto bb435;
bb438:;
  goto bb437;
bb439:;
  l294 = lust_add_i64(l292, l295, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(441);
  {
    int64_t t148 = ((int64_t (*)(int64_t))f_6e04c532a433cced)(1);
    LUST_UNW(443);
    l297 = t148;
  }
  goto bb442;
bb440:;
  goto bb438;
bb441:;
  goto bb440;
bb442:;
  l296 = lust_add_i64(l294, l297, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(444);
  {
    int64_t t149 = ((int64_t (*)(int64_t))f_13ed921ecad8edea)(1);
    LUST_UNW(446);
    l299 = t149;
  }
  goto bb445;
bb443:;
  goto bb441;
bb444:;
  goto bb443;
bb445:;
  l298 = lust_add_i64(l296, l299, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(447);
  {
    int64_t t150 = ((int64_t (*)(int64_t))f_509605bb3d21c548)(1);
    LUST_UNW(449);
    l301 = t150;
  }
  goto bb448;
bb446:;
  goto bb444;
bb447:;
  goto bb446;
bb448:;
  l300 = lust_add_i64(l298, l301, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(450);
  {
    int64_t t151 = ((int64_t (*)(int64_t))f_0c702a05f888b9b5)(1);
    LUST_UNW(452);
    l303 = t151;
  }
  goto bb451;
bb449:;
  goto bb447;
bb450:;
  goto bb449;
bb451:;
  l302 = lust_add_i64(l300, l303, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(453);
  {
    int64_t t152 = ((int64_t (*)(int64_t))f_69a89510a8e19608)(1);
    LUST_UNW(455);
    l305 = t152;
  }
  goto bb454;
bb452:;
  goto bb450;
bb453:;
  goto bb452;
bb454:;
  l304 = lust_add_i64(l302, l305, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(456);
  {
    int64_t t153 = ((int64_t (*)(int64_t))f_feb5c39f9b67e61a)(1);
    LUST_UNW(458);
    l307 = t153;
  }
  goto bb457;
bb455:;
  goto bb453;
bb456:;
  goto bb455;
bb457:;
  l306 = lust_add_i64(l304, l307, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(459);
  {
    int64_t t154 = ((int64_t (*)(int64_t))f_cc223626cdf9f506)(1);
    LUST_UNW(461);
    l309 = t154;
  }
  goto bb460;
bb458:;
  goto bb456;
bb459:;
  goto bb458;
bb460:;
  l308 = lust_add_i64(l306, l309, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(462);
  {
    int64_t t155 = ((int64_t (*)(int64_t))f_31c07aa50b393194)(1);
    LUST_UNW(464);
    l311 = t155;
  }
  goto bb463;
bb461:;
  goto bb459;
bb462:;
  goto bb461;
bb463:;
  l310 = lust_add_i64(l308, l311, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(465);
  {
    int64_t t156 = ((int64_t (*)(int64_t))f_95c7c5ed2791d8c7)(1);
    LUST_UNW(467);
    l313 = t156;
  }
  goto bb466;
bb464:;
  goto bb462;
bb465:;
  goto bb464;
bb466:;
  l312 = lust_add_i64(l310, l313, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(468);
  {
    int64_t t157 = ((int64_t (*)(int64_t))f_420570dd4f5fee14)(1);
    LUST_UNW(470);
    l315 = t157;
  }
  goto bb469;
bb467:;
  goto bb465;
bb468:;
  goto bb467;
bb469:;
  l314 = lust_add_i64(l312, l315, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(471);
  {
    int64_t t158 = ((int64_t (*)(int64_t))f_35a32cffcbb8f7b3)(1);
    LUST_UNW(473);
    l317 = t158;
  }
  goto bb472;
bb470:;
  goto bb468;
bb471:;
  goto bb470;
bb472:;
  l316 = lust_add_i64(l314, l317, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(474);
  {
    int64_t t159 = ((int64_t (*)(int64_t))f_1868532e2a981b6f)(1);
    LUST_UNW(476);
    l319 = t159;
  }
  goto bb475;
bb473:;
  goto bb471;
bb474:;
  goto bb473;
bb475:;
  l318 = lust_add_i64(l316, l319, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(477);
  {
    int64_t t160 = ((int64_t (*)(int64_t))f_b0e5aa31ad01ca4e)(1);
    LUST_UNW(479);
    l321 = t160;
  }
  goto bb478;
bb476:;
  goto bb474;
bb477:;
  goto bb476;
bb478:;
  l320 = lust_add_i64(l318, l321, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(480);
  {
    int64_t t161 = ((int64_t (*)(int64_t))f_6661133ec689e76c)(1);
    LUST_UNW(482);
    l323 = t161;
  }
  goto bb481;
bb479:;
  goto bb477;
bb480:;
  goto bb479;
bb481:;
  l322 = lust_add_i64(l320, l323, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(483);
  {
    int64_t t162 = ((int64_t (*)(int64_t))f_e9c4cb0543595e45)(1);
    LUST_UNW(485);
    l325 = t162;
  }
  goto bb484;
bb482:;
  goto bb480;
bb483:;
  goto bb482;
bb484:;
  l324 = lust_add_i64(l322, l325, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(486);
  {
    int64_t t163 = ((int64_t (*)(int64_t))f_58ea2a62b0dd5957)(1);
    LUST_UNW(488);
    l327 = t163;
  }
  goto bb487;
bb485:;
  goto bb483;
bb486:;
  goto bb485;
bb487:;
  l326 = lust_add_i64(l324, l327, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(489);
  {
    int64_t t164 = ((int64_t (*)(int64_t))f_03be07e6f84a9a13)(1);
    LUST_UNW(491);
    l329 = t164;
  }
  goto bb490;
bb488:;
  goto bb486;
bb489:;
  goto bb488;
bb490:;
  l328 = lust_add_i64(l326, l329, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(492);
  {
    int64_t t165 = ((int64_t (*)(int64_t))f_d93e6755e311ad3b)(1);
    LUST_UNW(494);
    l331 = t165;
  }
  goto bb493;
bb491:;
  goto bb489;
bb492:;
  goto bb491;
bb493:;
  l330 = lust_add_i64(l328, l331, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(495);
  {
    int64_t t166 = ((int64_t (*)(int64_t))f_ea4b82b4b5da741c)(1);
    LUST_UNW(497);
    l333 = t166;
  }
  goto bb496;
bb494:;
  goto bb492;
bb495:;
  goto bb494;
bb496:;
  l332 = lust_add_i64(l330, l333, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(498);
  {
    int64_t t167 = ((int64_t (*)(int64_t))f_a50a8d99bac54be0)(1);
    LUST_UNW(500);
    l335 = t167;
  }
  goto bb499;
bb497:;
  goto bb495;
bb498:;
  goto bb497;
bb499:;
  l334 = lust_add_i64(l332, l335, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(501);
  {
    int64_t t168 = ((int64_t (*)(int64_t))f_f0b2a02668219252)(1);
    LUST_UNW(503);
    l337 = t168;
  }
  goto bb502;
bb500:;
  goto bb498;
bb501:;
  goto bb500;
bb502:;
  l336 = lust_add_i64(l334, l337, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(504);
  {
    int64_t t169 = ((int64_t (*)(int64_t))f_f222bcb220511850)(1);
    LUST_UNW(506);
    l339 = t169;
  }
  goto bb505;
bb503:;
  goto bb501;
bb504:;
  goto bb503;
bb505:;
  l338 = lust_add_i64(l336, l339, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(507);
  {
    int64_t t170 = ((int64_t (*)(int64_t))f_f86391d34a050e5e)(1);
    LUST_UNW(509);
    l341 = t170;
  }
  goto bb508;
bb506:;
  goto bb504;
bb507:;
  goto bb506;
bb508:;
  l340 = lust_add_i64(l338, l341, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(510);
  {
    int64_t t171 = ((int64_t (*)(int64_t))f_d799bae7b1d71e42)(1);
    LUST_UNW(512);
    l343 = t171;
  }
  goto bb511;
bb509:;
  goto bb507;
bb510:;
  goto bb509;
bb511:;
  l342 = lust_add_i64(l340, l343, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(513);
  {
    int64_t t172 = ((int64_t (*)(int64_t))f_7bee5a0bfe87fd27)(1);
    LUST_UNW(515);
    l345 = t172;
  }
  goto bb514;
bb512:;
  goto bb510;
bb513:;
  goto bb512;
bb514:;
  l344 = lust_add_i64(l342, l345, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(516);
  {
    int64_t t173 = ((int64_t (*)(int64_t))f_489e92cc79eda2fd)(1);
    LUST_UNW(518);
    l347 = t173;
  }
  goto bb517;
bb515:;
  goto bb513;
bb516:;
  goto bb515;
bb517:;
  l346 = lust_add_i64(l344, l347, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(519);
  {
    int64_t t174 = ((int64_t (*)(int64_t))f_ea2b174b945b6a7d)(1);
    LUST_UNW(521);
    l349 = t174;
  }
  goto bb520;
bb518:;
  goto bb516;
bb519:;
  goto bb518;
bb520:;
  l348 = lust_add_i64(l346, l349, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(522);
  {
    int64_t t175 = ((int64_t (*)(int64_t))f_9238399843afbaf0)(1);
    LUST_UNW(524);
    l351 = t175;
  }
  goto bb523;
bb521:;
  goto bb519;
bb522:;
  goto bb521;
bb523:;
  l350 = lust_add_i64(l348, l351, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(525);
  {
    int64_t t176 = ((int64_t (*)(int64_t))f_b5497583b14d9758)(1);
    LUST_UNW(527);
    l353 = t176;
  }
  goto bb526;
bb524:;
  goto bb522;
bb525:;
  goto bb524;
bb526:;
  l352 = lust_add_i64(l350, l353, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(528);
  {
    int64_t t177 = ((int64_t (*)(int64_t))f_95183369e473648f)(1);
    LUST_UNW(530);
    l355 = t177;
  }
  goto bb529;
bb527:;
  goto bb525;
bb528:;
  goto bb527;
bb529:;
  l354 = lust_add_i64(l352, l355, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(531);
  {
    int64_t t178 = ((int64_t (*)(int64_t))f_e909122e4e7579ae)(1);
    LUST_UNW(533);
    l357 = t178;
  }
  goto bb532;
bb530:;
  goto bb528;
bb531:;
  goto bb530;
bb532:;
  l356 = lust_add_i64(l354, l357, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(534);
  {
    int64_t t179 = ((int64_t (*)(int64_t))f_1fe405fd40cfd6c6)(1);
    LUST_UNW(536);
    l359 = t179;
  }
  goto bb535;
bb533:;
  goto bb531;
bb534:;
  goto bb533;
bb535:;
  l358 = lust_add_i64(l356, l359, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(537);
  {
    int64_t t180 = ((int64_t (*)(int64_t))f_eb0e2947640f5dd0)(1);
    LUST_UNW(539);
    l361 = t180;
  }
  goto bb538;
bb536:;
  goto bb534;
bb537:;
  goto bb536;
bb538:;
  l360 = lust_add_i64(l358, l361, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(540);
  {
    int64_t t181 = ((int64_t (*)(int64_t))f_f272ab7eeb43addd)(1);
    LUST_UNW(542);
    l363 = t181;
  }
  goto bb541;
bb539:;
  goto bb537;
bb540:;
  goto bb539;
bb541:;
  l362 = lust_add_i64(l360, l363, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(543);
  {
    int64_t t182 = ((int64_t (*)(int64_t))f_96afa4b9bc140468)(1);
    LUST_UNW(545);
    l365 = t182;
  }
  goto bb544;
bb542:;
  goto bb540;
bb543:;
  goto bb542;
bb544:;
  l364 = lust_add_i64(l362, l365, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(546);
  {
    int64_t t183 = ((int64_t (*)(int64_t))f_84dc7988b9ff66c9)(1);
    LUST_UNW(548);
    l367 = t183;
  }
  goto bb547;
bb545:;
  goto bb543;
bb546:;
  goto bb545;
bb547:;
  l366 = lust_add_i64(l364, l367, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(549);
  {
    int64_t t184 = ((int64_t (*)(int64_t))f_c9de8b76366ef0ad)(1);
    LUST_UNW(551);
    l369 = t184;
  }
  goto bb550;
bb548:;
  goto bb546;
bb549:;
  goto bb548;
bb550:;
  l368 = lust_add_i64(l366, l369, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(552);
  {
    int64_t t185 = ((int64_t (*)(int64_t))f_3ba466fb37ed500b)(1);
    LUST_UNW(554);
    l371 = t185;
  }
  goto bb553;
bb551:;
  goto bb549;
bb552:;
  goto bb551;
bb553:;
  l370 = lust_add_i64(l368, l371, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(555);
  {
    int64_t t186 = ((int64_t (*)(int64_t))f_9cff13ec9a2dbb55)(1);
    LUST_UNW(557);
    l373 = t186;
  }
  goto bb556;
bb554:;
  goto bb552;
bb555:;
  goto bb554;
bb556:;
  l372 = lust_add_i64(l370, l373, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(558);
  {
    int64_t t187 = ((int64_t (*)(int64_t))f_29cce92e2bece48a)(1);
    LUST_UNW(560);
    l375 = t187;
  }
  goto bb559;
bb557:;
  goto bb555;
bb558:;
  goto bb557;
bb559:;
  l374 = lust_add_i64(l372, l375, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(561);
  {
    int64_t t188 = ((int64_t (*)(int64_t))f_d3722509e8844953)(1);
    LUST_UNW(563);
    l377 = t188;
  }
  goto bb562;
bb560:;
  goto bb558;
bb561:;
  goto bb560;
bb562:;
  l376 = lust_add_i64(l374, l377, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(564);
  {
    int64_t t189 = ((int64_t (*)(int64_t))f_4a2c23f4f2a4c7bf)(1);
    LUST_UNW(566);
    l379 = t189;
  }
  goto bb565;
bb563:;
  goto bb561;
bb564:;
  goto bb563;
bb565:;
  l378 = lust_add_i64(l376, l379, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(567);
  {
    int64_t t190 = ((int64_t (*)(int64_t))f_7a81356a3e150afd)(1);
    LUST_UNW(569);
    l381 = t190;
  }
  goto bb568;
bb566:;
  goto bb564;
bb567:;
  goto bb566;
bb568:;
  l380 = lust_add_i64(l378, l381, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(570);
  {
    int64_t t191 = ((int64_t (*)(int64_t))f_ebf8b38da9e287d2)(1);
    LUST_UNW(572);
    l383 = t191;
  }
  goto bb571;
bb569:;
  goto bb567;
bb570:;
  goto bb569;
bb571:;
  l382 = lust_add_i64(l380, l383, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(573);
  {
    int64_t t192 = ((int64_t (*)(int64_t))f_911d6013f2c690ec)(1);
    LUST_UNW(575);
    l385 = t192;
  }
  goto bb574;
bb572:;
  goto bb570;
bb573:;
  goto bb572;
bb574:;
  l384 = lust_add_i64(l382, l385, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(576);
  {
    int64_t t193 = ((int64_t (*)(int64_t))f_dbe75b723c3e652a)(1);
    LUST_UNW(578);
    l387 = t193;
  }
  goto bb577;
bb575:;
  goto bb573;
bb576:;
  goto bb575;
bb577:;
  l386 = lust_add_i64(l384, l387, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(579);
  {
    int64_t t194 = ((int64_t (*)(int64_t))f_cf77d6ac624225eb)(1);
    LUST_UNW(581);
    l389 = t194;
  }
  goto bb580;
bb578:;
  goto bb576;
bb579:;
  goto bb578;
bb580:;
  l388 = lust_add_i64(l386, l389, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(582);
  {
    int64_t t195 = ((int64_t (*)(int64_t))f_2d3296892bfdaa34)(1);
    LUST_UNW(584);
    l391 = t195;
  }
  goto bb583;
bb581:;
  goto bb579;
bb582:;
  goto bb581;
bb583:;
  l390 = lust_add_i64(l388, l391, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(585);
  {
    int64_t t196 = ((int64_t (*)(int64_t))f_ad0eed563d6710a5)(1);
    LUST_UNW(587);
    l393 = t196;
  }
  goto bb586;
bb584:;
  goto bb582;
bb585:;
  goto bb584;
bb586:;
  l392 = lust_add_i64(l390, l393, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(588);
  {
    int64_t t197 = ((int64_t (*)(int64_t))f_0a8b4f0ce09f0f96)(1);
    LUST_UNW(590);
    l395 = t197;
  }
  goto bb589;
bb587:;
  goto bb585;
bb588:;
  goto bb587;
bb589:;
  l394 = lust_add_i64(l392, l395, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(591);
  {
    int64_t t198 = ((int64_t (*)(int64_t))f_b595fd324556fbba)(1);
    LUST_UNW(593);
    l397 = t198;
  }
  goto bb592;
bb590:;
  goto bb588;
bb591:;
  goto bb590;
bb592:;
  l396 = lust_add_i64(l394, l397, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(594);
  {
    int64_t t199 = ((int64_t (*)(int64_t))f_133fab019df5590f)(1);
    LUST_UNW(596);
    l399 = t199;
  }
  goto bb595;
bb593:;
  goto bb591;
bb594:;
  goto bb593;
bb595:;
  l398 = lust_add_i64(l396, l399, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(597);
  {
    int64_t t200 = ((int64_t (*)(int64_t))f_8616e1dd2ab461d5)(1);
    LUST_UNW(599);
    l401 = t200;
  }
  goto bb598;
bb596:;
  goto bb594;
bb597:;
  goto bb596;
bb598:;
  l400 = lust_add_i64(l398, l401, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(600);
  {
    int64_t t201 = ((int64_t (*)(int64_t))f_bc6beedc491b2844)(1);
    LUST_UNW(602);
    l403 = t201;
  }
  goto bb601;
bb599:;
  goto bb597;
bb600:;
  goto bb599;
bb601:;
  l402 = lust_add_i64(l400, l403, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(603);
  {
    int64_t t202 = ((int64_t (*)(int64_t))f_856b31d595c4b589)(1);
    LUST_UNW(605);
    l405 = t202;
  }
  goto bb604;
bb602:;
  goto bb600;
bb603:;
  goto bb602;
bb604:;
  l404 = lust_add_i64(l402, l405, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(606);
  {
    int64_t t203 = ((int64_t (*)(int64_t))f_7c78f9001fb6fea4)(1);
    LUST_UNW(608);
    l407 = t203;
  }
  goto bb607;
bb605:;
  goto bb603;
bb606:;
  goto bb605;
bb607:;
  l406 = lust_add_i64(l404, l407, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(609);
  {
    int64_t t204 = ((int64_t (*)(int64_t))f_e61724f7935ea8eb)(1);
    LUST_UNW(611);
    l409 = t204;
  }
  goto bb610;
bb608:;
  goto bb606;
bb609:;
  goto bb608;
bb610:;
  l408 = lust_add_i64(l406, l409, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(612);
  {
    int64_t t205 = ((int64_t (*)(int64_t))f_dba6d5be34aaeffb)(1);
    LUST_UNW(614);
    l411 = t205;
  }
  goto bb613;
bb611:;
  goto bb609;
bb612:;
  goto bb611;
bb613:;
  l410 = lust_add_i64(l408, l411, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(615);
  {
    int64_t t206 = ((int64_t (*)(int64_t))f_adbf9fc271314305)(1);
    LUST_UNW(617);
    l413 = t206;
  }
  goto bb616;
bb614:;
  goto bb612;
bb615:;
  goto bb614;
bb616:;
  l412 = lust_add_i64(l410, l413, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(618);
  {
    int64_t t207 = ((int64_t (*)(int64_t))f_620f1bd5908429b9)(1);
    LUST_UNW(620);
    l415 = t207;
  }
  goto bb619;
bb617:;
  goto bb615;
bb618:;
  goto bb617;
bb619:;
  l414 = lust_add_i64(l412, l415, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(621);
  {
    int64_t t208 = ((int64_t (*)(int64_t))f_a75f823c083e9b55)(1);
    LUST_UNW(623);
    l417 = t208;
  }
  goto bb622;
bb620:;
  goto bb618;
bb621:;
  goto bb620;
bb622:;
  l416 = lust_add_i64(l414, l417, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(624);
  {
    int64_t t209 = ((int64_t (*)(int64_t))f_c64403f64f6c81b1)(1);
    LUST_UNW(626);
    l419 = t209;
  }
  goto bb625;
bb623:;
  goto bb621;
bb624:;
  goto bb623;
bb625:;
  l418 = lust_add_i64(l416, l419, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(627);
  {
    int64_t t210 = ((int64_t (*)(int64_t))f_aede0641cd502851)(1);
    LUST_UNW(629);
    l421 = t210;
  }
  goto bb628;
bb626:;
  goto bb624;
bb627:;
  goto bb626;
bb628:;
  l420 = lust_add_i64(l418, l421, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(630);
  {
    int64_t t211 = ((int64_t (*)(int64_t))f_81d4ea5193d167c0)(1);
    LUST_UNW(632);
    l423 = t211;
  }
  goto bb631;
bb629:;
  goto bb627;
bb630:;
  goto bb629;
bb631:;
  l422 = lust_add_i64(l420, l423, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(633);
  {
    int64_t t212 = ((int64_t (*)(int64_t))f_aef4380f706b52b0)(1);
    LUST_UNW(635);
    l425 = t212;
  }
  goto bb634;
bb632:;
  goto bb630;
bb633:;
  goto bb632;
bb634:;
  l424 = lust_add_i64(l422, l425, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(636);
  {
    int64_t t213 = ((int64_t (*)(int64_t))f_901569cf17c71ba8)(1);
    LUST_UNW(638);
    l427 = t213;
  }
  goto bb637;
bb635:;
  goto bb633;
bb636:;
  goto bb635;
bb637:;
  l426 = lust_add_i64(l424, l427, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(639);
  {
    int64_t t214 = ((int64_t (*)(int64_t))f_d7015c3f7e2c0086)(1);
    LUST_UNW(641);
    l429 = t214;
  }
  goto bb640;
bb638:;
  goto bb636;
bb639:;
  goto bb638;
bb640:;
  l428 = lust_add_i64(l426, l429, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(642);
  {
    int64_t t215 = ((int64_t (*)(int64_t))f_ddc7041e1c4192c8)(1);
    LUST_UNW(644);
    l431 = t215;
  }
  goto bb643;
bb641:;
  goto bb639;
bb642:;
  goto bb641;
bb643:;
  l430 = lust_add_i64(l428, l431, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(645);
  {
    int64_t t216 = ((int64_t (*)(int64_t))f_6a83568fec5e815a)(1);
    LUST_UNW(647);
    l433 = t216;
  }
  goto bb646;
bb644:;
  goto bb642;
bb645:;
  goto bb644;
bb646:;
  l432 = lust_add_i64(l430, l433, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(648);
  {
    int64_t t217 = ((int64_t (*)(int64_t))f_52b7748b7e03b126)(1);
    LUST_UNW(650);
    l435 = t217;
  }
  goto bb649;
bb647:;
  goto bb645;
bb648:;
  goto bb647;
bb649:;
  l434 = lust_add_i64(l432, l435, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(651);
  {
    int64_t t218 = ((int64_t (*)(int64_t))f_92b5c190df1d8477)(1);
    LUST_UNW(653);
    l437 = t218;
  }
  goto bb652;
bb650:;
  goto bb648;
bb651:;
  goto bb650;
bb652:;
  l436 = lust_add_i64(l434, l437, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(654);
  {
    int64_t t219 = ((int64_t (*)(int64_t))f_9c10ba922f7242ed)(1);
    LUST_UNW(656);
    l439 = t219;
  }
  goto bb655;
bb653:;
  goto bb651;
bb654:;
  goto bb653;
bb655:;
  l438 = lust_add_i64(l436, l439, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(657);
  {
    int64_t t220 = ((int64_t (*)(int64_t))f_c543dcb396a8aa3e)(1);
    LUST_UNW(659);
    l441 = t220;
  }
  goto bb658;
bb656:;
  goto bb654;
bb657:;
  goto bb656;
bb658:;
  l440 = lust_add_i64(l438, l441, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(660);
  {
    int64_t t221 = ((int64_t (*)(int64_t))f_d53ab81cf9d110cb)(1);
    LUST_UNW(662);
    l443 = t221;
  }
  goto bb661;
bb659:;
  goto bb657;
bb660:;
  goto bb659;
bb661:;
  l442 = lust_add_i64(l440, l443, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(663);
  {
    int64_t t222 = ((int64_t (*)(int64_t))f_24b8bd7af0f45da5)(1);
    LUST_UNW(665);
    l445 = t222;
  }
  goto bb664;
bb662:;
  goto bb660;
bb663:;
  goto bb662;
bb664:;
  l444 = lust_add_i64(l442, l445, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(666);
  {
    int64_t t223 = ((int64_t (*)(int64_t))f_8f70de8d9f99e53f)(1);
    LUST_UNW(668);
    l447 = t223;
  }
  goto bb667;
bb665:;
  goto bb663;
bb666:;
  goto bb665;
bb667:;
  l446 = lust_add_i64(l444, l447, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(669);
  {
    int64_t t224 = ((int64_t (*)(int64_t))f_38a0d0624b76abbb)(1);
    LUST_UNW(671);
    l449 = t224;
  }
  goto bb670;
bb668:;
  goto bb666;
bb669:;
  goto bb668;
bb670:;
  l448 = lust_add_i64(l446, l449, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(672);
  {
    int64_t t225 = ((int64_t (*)(int64_t))f_0bbf87d9ee5e1780)(1);
    LUST_UNW(674);
    l451 = t225;
  }
  goto bb673;
bb671:;
  goto bb669;
bb672:;
  goto bb671;
bb673:;
  l450 = lust_add_i64(l448, l451, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(675);
  {
    int64_t t226 = ((int64_t (*)(int64_t))f_726003d7a130b8a9)(1);
    LUST_UNW(677);
    l453 = t226;
  }
  goto bb676;
bb674:;
  goto bb672;
bb675:;
  goto bb674;
bb676:;
  l452 = lust_add_i64(l450, l453, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(678);
  {
    int64_t t227 = ((int64_t (*)(int64_t))f_c9d35363888b9352)(1);
    LUST_UNW(680);
    l455 = t227;
  }
  goto bb679;
bb677:;
  goto bb675;
bb678:;
  goto bb677;
bb679:;
  l454 = lust_add_i64(l452, l455, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(681);
  {
    int64_t t228 = ((int64_t (*)(int64_t))f_2ef263ab7f066864)(1);
    LUST_UNW(683);
    l457 = t228;
  }
  goto bb682;
bb680:;
  goto bb678;
bb681:;
  goto bb680;
bb682:;
  l456 = lust_add_i64(l454, l457, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(684);
  {
    int64_t t229 = ((int64_t (*)(int64_t))f_a14f74bd3e2d3b52)(1);
    LUST_UNW(686);
    l459 = t229;
  }
  goto bb685;
bb683:;
  goto bb681;
bb684:;
  goto bb683;
bb685:;
  l458 = lust_add_i64(l456, l459, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(687);
  {
    int64_t t230 = ((int64_t (*)(int64_t))f_84163f41f2e2fddd)(1);
    LUST_UNW(689);
    l461 = t230;
  }
  goto bb688;
bb686:;
  goto bb684;
bb687:;
  goto bb686;
bb688:;
  l460 = lust_add_i64(l458, l461, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(690);
  {
    int64_t t231 = ((int64_t (*)(int64_t))f_e2dd255ed5ba577c)(1);
    LUST_UNW(692);
    l463 = t231;
  }
  goto bb691;
bb689:;
  goto bb687;
bb690:;
  goto bb689;
bb691:;
  l462 = lust_add_i64(l460, l463, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(693);
  {
    int64_t t232 = ((int64_t (*)(int64_t))f_2fe4355853ebd629)(1);
    LUST_UNW(695);
    l465 = t232;
  }
  goto bb694;
bb692:;
  goto bb690;
bb693:;
  goto bb692;
bb694:;
  l464 = lust_add_i64(l462, l465, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(696);
  {
    int64_t t233 = ((int64_t (*)(int64_t))f_0c27d1821e7e4708)(1);
    LUST_UNW(698);
    l467 = t233;
  }
  goto bb697;
bb695:;
  goto bb693;
bb696:;
  goto bb695;
bb697:;
  l466 = lust_add_i64(l464, l467, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(699);
  {
    int64_t t234 = ((int64_t (*)(int64_t))f_c7beb8261d6b69cd)(1);
    LUST_UNW(701);
    l469 = t234;
  }
  goto bb700;
bb698:;
  goto bb696;
bb699:;
  goto bb698;
bb700:;
  l468 = lust_add_i64(l466, l469, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(702);
  {
    int64_t t235 = ((int64_t (*)(int64_t))f_f50cc8000839d113)(1);
    LUST_UNW(704);
    l471 = t235;
  }
  goto bb703;
bb701:;
  goto bb699;
bb702:;
  goto bb701;
bb703:;
  l470 = lust_add_i64(l468, l471, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(705);
  {
    int64_t t236 = ((int64_t (*)(int64_t))f_30d693ef8a8db365)(1);
    LUST_UNW(707);
    l473 = t236;
  }
  goto bb706;
bb704:;
  goto bb702;
bb705:;
  goto bb704;
bb706:;
  l472 = lust_add_i64(l470, l473, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(708);
  {
    int64_t t237 = ((int64_t (*)(int64_t))f_620db28fc978a369)(1);
    LUST_UNW(710);
    l475 = t237;
  }
  goto bb709;
bb707:;
  goto bb705;
bb708:;
  goto bb707;
bb709:;
  l474 = lust_add_i64(l472, l475, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(711);
  {
    int64_t t238 = ((int64_t (*)(int64_t))f_6e4405b3ba9ae8cd)(1);
    LUST_UNW(713);
    l477 = t238;
  }
  goto bb712;
bb710:;
  goto bb708;
bb711:;
  goto bb710;
bb712:;
  l476 = lust_add_i64(l474, l477, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(714);
  {
    int64_t t239 = ((int64_t (*)(int64_t))f_021870c95b651de6)(1);
    LUST_UNW(716);
    l479 = t239;
  }
  goto bb715;
bb713:;
  goto bb711;
bb714:;
  goto bb713;
bb715:;
  l478 = lust_add_i64(l476, l479, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(717);
  {
    int64_t t240 = ((int64_t (*)(int64_t))f_d6b19d45cc583106)(1);
    LUST_UNW(719);
    l481 = t240;
  }
  goto bb718;
bb716:;
  goto bb714;
bb717:;
  goto bb716;
bb718:;
  l480 = lust_add_i64(l478, l481, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(720);
  {
    int64_t t241 = ((int64_t (*)(int64_t))f_e54911916a943a85)(1);
    LUST_UNW(722);
    l483 = t241;
  }
  goto bb721;
bb719:;
  goto bb717;
bb720:;
  goto bb719;
bb721:;
  l482 = lust_add_i64(l480, l483, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(723);
  {
    int64_t t242 = ((int64_t (*)(int64_t))f_f8481ab24b3f511b)(1);
    LUST_UNW(725);
    l485 = t242;
  }
  goto bb724;
bb722:;
  goto bb720;
bb723:;
  goto bb722;
bb724:;
  l484 = lust_add_i64(l482, l485, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(726);
  {
    int64_t t243 = ((int64_t (*)(int64_t))f_4c12e097fbcce7de)(1);
    LUST_UNW(728);
    l487 = t243;
  }
  goto bb727;
bb725:;
  goto bb723;
bb726:;
  goto bb725;
bb727:;
  l486 = lust_add_i64(l484, l487, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(729);
  {
    int64_t t244 = ((int64_t (*)(int64_t))f_e01d5f31b4d85cfb)(1);
    LUST_UNW(731);
    l489 = t244;
  }
  goto bb730;
bb728:;
  goto bb726;
bb729:;
  goto bb728;
bb730:;
  l488 = lust_add_i64(l486, l489, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(732);
  {
    int64_t t245 = ((int64_t (*)(int64_t))f_d55eeee98958238e)(1);
    LUST_UNW(734);
    l491 = t245;
  }
  goto bb733;
bb731:;
  goto bb729;
bb732:;
  goto bb731;
bb733:;
  l490 = lust_add_i64(l488, l491, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(735);
  {
    int64_t t246 = ((int64_t (*)(int64_t))f_d3e6eb48954cf171)(1);
    LUST_UNW(737);
    l493 = t246;
  }
  goto bb736;
bb734:;
  goto bb732;
bb735:;
  goto bb734;
bb736:;
  l492 = lust_add_i64(l490, l493, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(738);
  {
    int64_t t247 = ((int64_t (*)(int64_t))f_7a53a66349ac8302)(1);
    LUST_UNW(740);
    l495 = t247;
  }
  goto bb739;
bb737:;
  goto bb735;
bb738:;
  goto bb737;
bb739:;
  l494 = lust_add_i64(l492, l495, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(741);
  {
    int64_t t248 = ((int64_t (*)(int64_t))f_695bb3edb1c10eb8)(1);
    LUST_UNW(743);
    l497 = t248;
  }
  goto bb742;
bb740:;
  goto bb738;
bb741:;
  goto bb740;
bb742:;
  l496 = lust_add_i64(l494, l497, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(744);
  {
    int64_t t249 = ((int64_t (*)(int64_t))f_fa713bfc79ead375)(1);
    LUST_UNW(746);
    l499 = t249;
  }
  goto bb745;
bb743:;
  goto bb741;
bb744:;
  goto bb743;
bb745:;
  l498 = lust_add_i64(l496, l499, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(747);
  {
    int64_t t250 = ((int64_t (*)(int64_t))f_2f2e9ac6ca7c78c1)(1);
    LUST_UNW(749);
    l501 = t250;
  }
  goto bb748;
bb746:;
  goto bb744;
bb747:;
  goto bb746;
bb748:;
  l500 = lust_add_i64(l498, l501, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(750);
  {
    int64_t t251 = ((int64_t (*)(int64_t))f_aeaa10c2868c2544)(1);
    LUST_UNW(752);
    l503 = t251;
  }
  goto bb751;
bb749:;
  goto bb747;
bb750:;
  goto bb749;
bb751:;
  l502 = lust_add_i64(l500, l503, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(753);
  {
    int64_t t252 = ((int64_t (*)(int64_t))f_e4e91ccae01e4b9c)(1);
    LUST_UNW(755);
    l505 = t252;
  }
  goto bb754;
bb752:;
  goto bb750;
bb753:;
  goto bb752;
bb754:;
  l504 = lust_add_i64(l502, l505, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(756);
  {
    int64_t t253 = ((int64_t (*)(int64_t))f_1c9278ae0079e571)(1);
    LUST_UNW(758);
    l507 = t253;
  }
  goto bb757;
bb755:;
  goto bb753;
bb756:;
  goto bb755;
bb757:;
  l506 = lust_add_i64(l504, l507, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(759);
  {
    int64_t t254 = ((int64_t (*)(int64_t))f_0c7edc7c286c654b)(1);
    LUST_UNW(761);
    l509 = t254;
  }
  goto bb760;
bb758:;
  goto bb756;
bb759:;
  goto bb758;
bb760:;
  l508 = lust_add_i64(l506, l509, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(762);
  {
    int64_t t255 = ((int64_t (*)(int64_t))f_99a5f75c4fcb0ec9)(1);
    LUST_UNW(764);
    l511 = t255;
  }
  goto bb763;
bb761:;
  goto bb759;
bb762:;
  goto bb761;
bb763:;
  l510 = lust_add_i64(l508, l511, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(765);
  {
    int64_t t256 = ((int64_t (*)(int64_t))f_d18a6c484a3658d5)(1);
    LUST_UNW(765);
    l512 = t256;
  }
  goto bb766;
bb764:;
  goto bb762;
bb765:;
  goto bb764;
bb766:;
  l2 = lust_add_i64(l510, l512, (LUST_SO(lust_so_dce795fb70dcd531) | 40ull));
  LUST_UNW(767);
  {
    int64_t t257 = ((int64_t (*)(int64_t))f_7646620f1a99865a)(l2);
    LUST_UNW(769);
    l1 = t257;
  }
  goto bb768;
bb767:;
  goto bb765;
bb768:;
  l513 = (&l1);
  {
    lust_sink t258k; { lust_print_begin(&t258k, 0); LUST_UNW(771); } lust_Formatter t258f; { lust_f_init(&t258f, &t258k); LUST_UNW(771); } int t258e = 0;
    { { lust_f_set(&t258f, 32, 3, 0, 0, 0); LUST_UNW(771); } t258e = lust_f_i64((&t258f), (int64_t)(*l513)); }
    { lust_f_write(&t258f, "\n", 1); LUST_UNW(771); }
    { lust_print_end(0); LUST_UNW(771); }
  }
  LUST_UNW(771);
  l0 = ((lust_Unit){});
  return l0;
bb769:;
  goto bb767;
bb770:;
  goto bb2;
bb771:;
  goto bb770;
}

lust_Unit tramp_dce795fb70dcd531(void) { return ((lust_Unit (*)(void))f_dce795fb70dcd531)(); }
void lustr_register_84adb7c9d2fb40fa(void) {
  lust_main_entry_p = 0;
}
