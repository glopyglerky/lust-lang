 
typedef signed char int8_t; typedef unsigned char uint8_t; typedef short int16_t; typedef unsigned short uint16_t;
typedef int int32_t; typedef unsigned int uint32_t;
#ifdef __INT64_TYPE__
typedef __INT64_TYPE__ int64_t; typedef unsigned __INT64_TYPE__ uint64_t;
#else
typedef long long int64_t; typedef unsigned long long uint64_t;
#endif
#ifdef __SIZE_TYPE__
typedef __SIZE_TYPE__ size_t; typedef __PTRDIFF_TYPE__ ptrdiff_t; typedef __UINTPTR_TYPE__ uintptr_t; typedef __INTPTR_TYPE__ intptr_t;
#else
typedef unsigned long size_t; typedef long ptrdiff_t; typedef unsigned long uintptr_t; typedef long intptr_t;
#endif
#define INT64_MIN (-9223372036854775807LL-1)
#ifndef NULL
#define NULL ((void*)0)
#endif
void free(void *);
void abort(void);
void *memset(void *, int, size_t);
void *memcpy(void *, const void *, size_t);
#define LUST_BODY(...) ;

 
#ifdef __TINYC__
#define lust_black_box(p) ((void)(p))
#else
#define lust_black_box(p) __asm__ __volatile__("" : : "r"(p) : "memory")
#endif

 
#ifdef __TINYC__
#define lust_copy_small(d, s, n) lust_memmove((d), (s), (n))
#else
static inline __attribute__((always_inline)) void lust_copy_small(void *d, const void *s, uint64_t n) {
    unsigned char *dp = (unsigned char *)d;
    const unsigned char *sp = (const unsigned char *)s;
    if (__builtin_expect(n > 32, 0)) {
        __builtin_memmove(d, s, (size_t)n);
    } else if (n > 16) {
        uint64_t a, b, c, e;
        __builtin_memcpy(&a, sp, 8);
        __builtin_memcpy(&b, sp + 8, 8);
        __builtin_memcpy(&c, sp + n - 16, 8);
        __builtin_memcpy(&e, sp + n - 8, 8);
        __builtin_memcpy(dp, &a, 8);
        __builtin_memcpy(dp + 8, &b, 8);
        __builtin_memcpy(dp + n - 16, &c, 8);
        __builtin_memcpy(dp + n - 8, &e, 8);
    } else if (n >= 8) {
        uint64_t a, e;
        __builtin_memcpy(&a, sp, 8);
        __builtin_memcpy(&e, sp + n - 8, 8);
        __builtin_memcpy(dp, &a, 8);
        __builtin_memcpy(dp + n - 8, &e, 8);
    } else if (n >= 4) {
        uint32_t a, e;
        __builtin_memcpy(&a, sp, 4);
        __builtin_memcpy(&e, sp + n - 4, 4);
        __builtin_memcpy(dp, &a, 4);
        __builtin_memcpy(dp + n - 4, &e, 4);
    } else if (n) {
        unsigned char a = sp[0], b = sp[n >> 1], c = sp[n - 1];
        dp[0] = a;
        dp[n >> 1] = b;
        dp[n - 1] = c;
    }
}
#endif

 
#ifdef __TINYC__
#define lust_vec_fits(n, elem) ((uint64_t)(n) <= 9223372036854775807ull / (uint64_t)(elem))
#else
static inline __attribute__((always_inline)) int lust_vec_fits(uint64_t n, uint64_t elem) {
    uint64_t bytes;
    if (__builtin_constant_p(elem)) return n <= 9223372036854775807ull / elem;
    return !__builtin_mul_overflow(n, elem, &bytes) && bytes <= 9223372036854775807ull;
}
#endif



 
typedef struct { _Alignas(16) uint64_t lo; uint64_t hi; } lust_u128;
typedef struct { _Alignas(16) uint64_t lo; uint64_t hi; } lust_i128;

 
typedef struct { } lust_Unit;
_Static_assert(sizeof(lust_Unit) == 0 && _Alignof(lust_Unit) == 1, "unit layout");

typedef struct { uint8_t *ptr; uint64_t len; } lust_str;
typedef struct { uint8_t *ptr; uint64_t len; uint64_t cap; } lust_String;
typedef struct { void *ptr; uint64_t len; uint64_t cap; } lust_Vec;
 
typedef struct { void *ptr; uint64_t len; uint64_t cap; uint64_t front; } lust_VecIter;
 
typedef struct { void *vec; uint64_t start; uint64_t front; uint64_t back; uint64_t tail_start; uint64_t tail_len; } lust_VecDrain;
 
typedef struct { void *data; const void *const *vt; } lust_dyn;

 
extern int lust_argc;
extern char **lust_argv;
extern const char *lust_file;

 
typedef void (*lust_fnptr)(void);
extern lust_fnptr lust_fns[];
 
extern lust_fnptr lust_tramps[];
 
extern int (*lust_main_entry_p)(void);
void lust_base_init(void);
 
int32_t lust_unw_try(void (*f)(void *), void *ctx);
int32_t lust_unw_main_caught(void);
void lust_unw_dtry(void (*f)(void *), void *arg, void **ux);
void lust_unw_reraise(void *ux);

 
typedef uint64_t lust_loc;
 
#define LUST_SO(x) (*(const volatile uint64_t *)&(x))
 
extern const uint64_t lust_so_none;
extern const uint32_t *lust_fn_line;
 
#define LUST_TLS_FAST 512

 
void *aligned_alloc(size_t alignment, size_t size);
int posix_memalign(void **memptr, size_t alignment, size_t size);

 
int32_t lust_bt_style(void) ;

 
void lust_bt_tail(int32_t style, int32_t off_note) ;

 
void lust_oom(void) ;

 
void lust_panic_std(const char *msg, const char *where);  
void lust_panic_std_lit(const char *msg, const char *where);
void lust_vec_capacity_overflow(void) ;

 
void lust_oom_size(uint64_t n) ;

 
void *lust_alloc(uint64_t size, uint64_t align) ;

 
void *lust_alloc_zeroed(uint64_t size, uint64_t align) ;

 
int32_t lust_is_zeroed(const void *p, uint64_t n) ;

void lust_dealloc(void *ptr, uint64_t size, uint64_t align) ;

 
#define lust_rc_free(ptr, align) lust_dealloc((void *)(ptr), 1, (align))

 
void *lust_realloc(void *ptr, uint64_t old_size, uint64_t align, uint64_t new_size) ;

 
void lust_memcpy(void *dst, const void *src, uint64_t n) ;
void lust_memmove(void *dst, const void *src, uint64_t n) ;
void lust_memset(void *dst, uint32_t byte, uint64_t n) ;
int32_t lust_memcmp(const void *a, const void *b, uint64_t n) ;
void lust_ptr_read(void *dst, const void *src, uint64_t size) ;
void lust_ptr_write(void *dst, const void *src, uint64_t size) ;
void *lust_ptr_offset(void *ptr, uint64_t offset) ;

 

 
lust_String lust_string_new(void) ;

 
void lust_string_reserve(lust_String *s, uint64_t extra) ;

void lust_string_reserve_exact(lust_String *s, uint64_t extra) ;

lust_String lust_string_with_capacity(uint64_t n) ;

void lust_string_push_bytes(lust_String *s, const void *p, uint64_t n) ;

void lust_string_push_str(lust_String *s, lust_str x) ;

void lust_string_push_cstr(lust_String *s, const char *c) ;

void lust_string_push_char(lust_String *s, uint32_t c) ;

lust_String lust_string_from(lust_str x) ;

lust_str lust_string_as_str(lust_String *s) ;
lust_String lust_string_clone(lust_String *s) ;
void lust_string_drop(lust_String *s) ;

int lust_str_cmp(lust_str a, lust_str b) ;
uint8_t lust_str_eq(lust_str a, lust_str b) ;

 


 
typedef struct {
    uint32_t kind;  
    lust_str s;     
    lust_dyn box;   
} lust_exc;
#define LUST_EXC_STR 0u
#define LUST_EXC_STRING 1u
#define LUST_EXC_BOX 2u
extern int32_t lust_unwind_mode;
extern int32_t lust_unw_pending;
 
#define LUST_UNW(b) if (lust_unw_pending && lust_unw_take(&ex)) goto bb##b
#define LUST_UNW_ABORT() if (lust_unw_pending && lust_unw_mine()) lust_unw_cleanup_abort()

 
int32_t lust_unw_take(lust_exc *ex) ;

 
void lust_unw_resume(lust_exc *ex) ;

 
uint8_t lust_unw_panicking(void) ;

 
int32_t lust_unw_mine(void) ;

 
void lust_unw_cleanup_abort(void) ;

 
void lust_unw_dstep(lust_exc *ex, int32_t *u) ;


 
void lust_unw_init(int32_t unwind, uint64_t str_lo, uint64_t str_hi, uint64_t string_lo, uint64_t string_hi) ;


 
void lust_hook_swap(void *v, uint64_t n) ;

 
void *lust_hook_slot(void) ;

 
void lust_hook_set_runner(lust_fnptr f) ;

 
lust_dyn lust_hook_payload(void) ;
void *lust_hook_location(void) ;

 
void lust_hook_custom(uint8_t on) ;

 
void lust_hook_default(lust_str file, uint32_t line, uint32_t col, lust_str msg) ;

 
lust_dyn lust_unw_catch(void) ;

 
struct lust_dguard { void (*drop)(void *); void *p; int32_t armed; };
void lust_dguard_end(struct lust_dguard *g) ;
 
struct lust_retain_guard { lust_Vec *v; uint64_t *r; uint64_t *w; uint64_t es; int32_t armed; };
void lust_retain_guard_end(struct lust_retain_guard *g) ;

 
int32_t lust_unw_main_caught(void) ;

 
void lust_unw_resume_box(lust_dyn b) ;

 
int32_t lust_unw_main_exit(void) ;

 
void lust_panic_at(const uint8_t *msg, uint64_t len, const char *file, uint32_t line, uint32_t col) ;

 
#define LUST_STD_SLOT 0xFFFF00u
#define LUST_STD_POW 0x40u

 
extern const char *const *lust_files;
extern const uint32_t *lust_slot_file;


 
void lust_panic(lust_String *msg, lust_loc loc) ;

 
void lust_panic_lit(lust_String *msg, lust_loc loc) ;

 
void lust_panic_begin(lust_loc loc) ;

void lust_panic_fmt(lust_String *msg, lust_loc loc) ;

 
void lust_panic_dyn(lust_String *msg, lust_loc loc) ;

void lust_panic_cstr_dyn(const char *msg, lust_loc loc) ;

void lust_panic_str(lust_str msg, lust_loc loc) ;

 
void lust_panic_cstr(const char *msg, lust_loc loc) ;

 
void lust_panic_cstr_owned(const char *msg, lust_loc loc) ;

 
void lust_ovf(const char *op, lust_loc loc) ;

 

 
void lust_panic_std(const char *msg, const char *where) ;

 
void lust_panic_std_lit(const char *msg, const char *where) ;

 
void lust_panic_read_buf_overrun(void) ;

 
void lust_panic_box(lust_dyn b, lust_loc loc) ;

 
void lust_loc_where(lust_loc loc, const char **file, uint32_t *line) ;

 

 
void lust_print_out(const uint8_t *p, uint64_t n) ;

 
void lust_print_flush(void) ;

 
int32_t lust_stdout_write_soft(const uint8_t *p, uint64_t n) ;
int32_t lust_stdout_flush_soft(void) ;

 

 
void lust_rt_init(void) ;

 
void lust_print_failed(int to_stderr, lust_String *s) ;
 

 
void *lust_tls_cell(uint64_t *key, uint64_t size, uint64_t align);
 
void lust_tls_register(void *cell, void (*dtor)(void *));
 
void lust_tls_exit(void);


void *lust_tls_cell(uint64_t *key, uint64_t size, uint64_t align) ;

void lust_tls_register(void *cell, void (*dtor)(void *)) ;

void lust_tls_exit(void) ;
 

const void *lust_kintern(const void **cache, const void *p, uint64_t n, uint64_t align, const uint64_t *desc);
void lust_kreg(const void *p, uint64_t n, uint64_t align, const uint64_t *desc);
void lust_kreg_h(const void *p, uint64_t n, uint64_t align, uint64_t kind, uint64_t hash);


 
const void *lust_kintern(const void **cache, const void *p, uint64_t n, uint64_t align, const uint64_t *desc) ;

 
void lust_kreg(const void *p, uint64_t n, uint64_t align, const uint64_t *desc) ;

 
void lust_kreg_h(const void *p, uint64_t n, uint64_t align, uint64_t kind, uint64_t hash) ;
 

void lust_fmt_u64(lust_String *out, uint64_t v) ;

void lust_fmt_i64(lust_String *out, int64_t v) ;

void lust_fmt_bool(lust_String *out, uint8_t v) ;


 
void lust_fmt_fnptr_debug(lust_String *out, const void *p) ;

void lust_fmt_escape(lust_String *out, uint32_t c, uint32_t quote) ;

 
uint32_t lust_utf8_next(const uint8_t *p, uint64_t *i) ;

void lust_fmt_str_debug(lust_String *out, lust_str s) ;

void lust_fmt_char_debug(lust_String *out, uint32_t c) ;

 
void lust_write(int to_stderr, lust_String *s) ;

void lust_flush(void) ;

 
void lust_exit(int32_t code) ;

 

 
void lust_vec_grow_to(lust_Vec *v, uint64_t new_cap, uint64_t elem, uint64_t align) ;

void lust_vec_set_zst(lust_Vec *v, uint64_t align) ;

void lust_vec_reserve(lust_Vec *v, uint64_t extra, uint64_t elem, uint64_t align) ;

void lust_vec_reserve_exact(lust_Vec *v, uint64_t extra, uint64_t elem, uint64_t align) ;

lust_Vec lust_vec_with_capacity(uint64_t n, uint64_t elem, uint64_t align) ;

 
lust_Vec lust_vec_with_capacity_zeroed(uint64_t n, uint64_t elem, uint64_t align) ;

void lust_vec_shrink_to(lust_Vec *v, uint64_t min_cap, uint64_t elem, uint64_t align) ;

void *lust_vec_push_slot(lust_Vec *v, uint64_t elem, uint64_t align) ;

 
void lust_panic_nn(const char *a, uint64_t n, const char *b, uint64_t m, const char *c, lust_loc loc) ;

 
uint64_t lust_slice_range(uint64_t lo, uint64_t hi, int inclusive, uint64_t len, lust_loc loc) ;


 
uint64_t lust_str_range(const uint8_t *ptr, uint64_t lo, uint64_t hi, int inclusive, uint64_t len, lust_loc loc) ;

 
static lust_loc lust_std_loc(uint32_t file, uint32_t line, uint32_t col) {
    return (((uint64_t)(LUST_STD_SLOT + file)) << 40) | ((uint64_t)line << 20) | (uint64_t)col;
}

 
static void lust_range_bounds_check(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t *out_s, uint64_t *out_e) ;

 
lust_VecDrain lust_vec_drain(lust_Vec *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) ;

 
lust_VecDrain lust_vec_drain_t(lust_Vec *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) ;

 
static lust_VecDrain lust_string_drain_in(lust_String *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc, int flag) ;

lust_VecDrain lust_string_drain(lust_String *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) ;

lust_VecDrain lust_string_drain_t(lust_String *v, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, lust_loc loc) ;

 
void lust_range_check(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t *out_s, uint64_t *out_e) ;

 
uint8_t lust_bytes_eq_ignore_ascii_case(const uint8_t *a, uint64_t an, const uint8_t *b, uint64_t bn) ;

 
#if !defined(__TINYC__) && defined(__x86_64__) && defined(__SSE2__)
typedef char lust_v16_ __attribute__((vector_size(16)));
typedef char lust_v16u_ __attribute__((vector_size(16), aligned(1)));
#endif
uint8_t lust_bytes_is_ascii(const uint8_t *p, uint64_t n) ;

 
void lust_slice_rotate_left(void *ptr, uint64_t len, uint64_t elem, uint64_t mid) ;

 
 
void lust_utf8_chunk_step(const uint8_t *p, uint64_t len, uint64_t *valid, uint64_t *used) ;

 
int lust_range_bounds_get(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t *out_s, uint64_t *out_e) ;

void lust_slice_copy_within(void *ptr, uint64_t len, uint64_t elem, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val, uint64_t dest, lust_loc loc) ;

 
double lust_fmod_f64(double x, double y) ;

float lust_fmod_f32(float x, float y) ;

uint64_t lust_bounds(uint64_t i, uint64_t len, lust_loc loc) ;

 

#define LUST_OVF(op) lust_ovf(op, loc)

 
#define LUST_SIGNED_NARROW(T, N, MINV, MAXV) \
T lust_add_##N(T a, T b, lust_loc loc) ; \
T lust_sub_##N(T a, T b, lust_loc loc) ; \
T lust_mul_##N(T a, T b, lust_loc loc) ; \
T lust_neg_##N(T a, lust_loc loc) ; \
T lust_div_##N(T a, T b, lust_loc loc) ; \
T lust_rem_##N(T a, T b, lust_loc loc) ;

#define LUST_UNSIGNED_NARROW(T, N, MAXV) \
T lust_add_##N(T a, T b, lust_loc loc) ; \
T lust_sub_##N(T a, T b, lust_loc loc) ; \
T lust_mul_##N(T a, T b, lust_loc loc) ; \
T lust_div_##N(T a, T b, lust_loc loc) ; \
T lust_rem_##N(T a, T b, lust_loc loc) ;

LUST_SIGNED_NARROW(int8_t, i8, -128, 127)
LUST_SIGNED_NARROW(int16_t, i16, -32768, 32767)
LUST_SIGNED_NARROW(int32_t, i32, -2147483647 - 1, 2147483647)
LUST_UNSIGNED_NARROW(uint8_t, u8, 255u)
LUST_UNSIGNED_NARROW(uint16_t, u16, 65535u)
LUST_UNSIGNED_NARROW(uint32_t, u32, 4294967295u)

int64_t lust_add_i64(int64_t a, int64_t b, lust_loc loc) ;
int64_t lust_sub_i64(int64_t a, int64_t b, lust_loc loc) ;
int64_t lust_mul_i64(int64_t a, int64_t b, lust_loc loc) ;
int64_t lust_neg_i64(int64_t a, lust_loc loc) ;
int64_t lust_div_i64(int64_t a, int64_t b, lust_loc loc) ;
int64_t lust_rem_i64(int64_t a, int64_t b, lust_loc loc) ;
uint64_t lust_add_u64(uint64_t a, uint64_t b, lust_loc loc) ;
uint64_t lust_sub_u64(uint64_t a, uint64_t b, lust_loc loc) ;
uint64_t lust_mul_u64(uint64_t a, uint64_t b, lust_loc loc) ;
uint64_t lust_div_u64(uint64_t a, uint64_t b, lust_loc loc) ;
uint64_t lust_rem_u64(uint64_t a, uint64_t b, lust_loc loc) ;

uint32_t lust_shift_amount(uint64_t b, uint32_t bits, const char *op, lust_loc loc) ;

#define LUST_POW(T, N) \
T lust_pow_##N(T a, uint32_t e, lust_loc loc) ;
#define LUST_ABS(T, N) T lust_abs_##N(T a, lust_loc loc) ;
LUST_POW(int8_t, i8) LUST_POW(int16_t, i16) LUST_POW(int32_t, i32) LUST_POW(int64_t, i64)
LUST_POW(uint8_t, u8) LUST_POW(uint16_t, u16) LUST_POW(uint32_t, u32) LUST_POW(uint64_t, u64)
LUST_ABS(int8_t, i8) LUST_ABS(int16_t, i16) LUST_ABS(int32_t, i32) LUST_ABS(int64_t, i64)

 

static uint64_t lust_mask64(unsigned bits) ;
static int64_t lust_sext64(uint64_t v, unsigned bits) ;

int lust_checked_op(uint64_t a, uint64_t b, unsigned bits, int is_signed, int op, uint64_t *out) ;

 
int lust_checked_pow(uint64_t a, uint32_t e, unsigned bits, int is_signed, uint64_t *out) ;

 
uint64_t lust_wrapping_pow(uint64_t a, uint32_t e, unsigned bits) ;

 
 
uint64_t lust_div_ceil(uint64_t a, uint64_t b, unsigned bits, lust_loc loc) ;

uint64_t lust_div_euclid(uint64_t a, uint64_t b, unsigned bits, int is_signed, lust_loc loc) ;
uint64_t lust_rem_euclid(uint64_t a, uint64_t b, unsigned bits, int is_signed, lust_loc loc) ;

uint64_t lust_isqrt64(uint64_t v) ;
uint32_t lust_count_ones64(uint64_t v) ;
uint32_t lust_leading_zeros64(uint64_t v, unsigned bits) ;
uint32_t lust_trailing_zeros64(uint64_t v, unsigned bits) ;

 

 

lust_u128 lust_u128_from_i128(lust_i128 a) ;
lust_i128 lust_i128_from_u128(lust_u128 a) ;

lust_u128 lust_u128_add(lust_u128 a, lust_u128 b) ;
lust_u128 lust_u128_sub(lust_u128 a, lust_u128 b) ;
lust_i128 lust_i128_add(lust_i128 a, lust_i128 b) ;
lust_i128 lust_i128_sub(lust_i128 a, lust_i128 b) ;

int32_t lust_u128_cmp(lust_u128 a, lust_u128 b) ;
int32_t lust_i128_cmp(lust_i128 a, lust_i128 b) ;

lust_u128 lust_u128_and(lust_u128 a, lust_u128 b) ;
lust_u128 lust_u128_or(lust_u128 a, lust_u128 b) ;
lust_u128 lust_u128_xor(lust_u128 a, lust_u128 b) ;
lust_u128 lust_u128_not(lust_u128 a) ;
lust_i128 lust_i128_and(lust_i128 a, lust_i128 b) ;
lust_i128 lust_i128_or(lust_i128 a, lust_i128 b) ;
lust_i128 lust_i128_xor(lust_i128 a, lust_i128 b) ;
lust_i128 lust_i128_not(lust_i128 a) ;

 
uint64_t lust_u128_mul64(uint64_t a, uint64_t b, uint64_t *hi) ;

lust_u128 lust_u128_mul(lust_u128 a, lust_u128 b) ;
lust_i128 lust_i128_mul(lust_i128 a, lust_i128 b) ;

lust_u128 lust_u128_shl(lust_u128 a, uint32_t n) ;
lust_u128 lust_u128_shr(lust_u128 a, uint32_t n) ;
lust_i128 lust_i128_shl(lust_i128 a, uint32_t n) ;
lust_i128 lust_i128_shr(lust_i128 a, uint32_t n) ;

uint32_t lust_u128_clz32(uint32_t x) ;

 
lust_u128 lust_u128_divmod(lust_u128 a, lust_u128 b, lust_u128 *rem) ;

 
lust_u128 lust_u128_divmod64(lust_u128 a, uint64_t b, uint64_t *rem) ;

lust_u128 lust_add_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;
lust_u128 lust_sub_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;
lust_u128 lust_mul_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;
lust_u128 lust_div_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;
lust_u128 lust_rem_u128(lust_u128 a, lust_u128 b, lust_loc loc) ;

lust_u128 lust_i128_mag(lust_i128 a) ;

lust_i128 lust_add_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;
lust_i128 lust_sub_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;
lust_i128 lust_neg_i128(lust_i128 a, lust_loc loc) ;
lust_i128 lust_mul_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;
lust_i128 lust_div_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;
lust_i128 lust_rem_i128(lust_i128 a, lust_i128 b, lust_loc loc) ;

lust_i128 lust_abs_i128(lust_i128 a, lust_loc loc) ;
lust_u128 lust_pow_u128(lust_u128 a, uint32_t e, lust_loc loc) ;
lust_i128 lust_pow_i128(lust_i128 a, uint32_t e, lust_loc loc) ;
 
lust_i128 lust_wrapping_abs_i128(lust_i128 a) ;
lust_u128 lust_wrapping_pow_u128(lust_u128 a, uint32_t e) ;
lust_i128 lust_wrapping_pow_i128(lust_i128 a, uint32_t e) ;

 
void lust_fmt_u128(lust_String *out, lust_u128 v) ;
void lust_fmt_i128(lust_String *out, lust_i128 v) ;

 
void lust_fmt_int_spec(lust_String *out, uint64_t lo, uint64_t hi, int negative, int mode, int plus, int alt, int zero_pad, uint32_t width, uint32_t fill, int align, int has_prec, uint32_t prec) ;

 
uint64_t lust_str_char_count(lust_str s) ;

 
void lust_fmt_pad(lust_String *out, lust_str body, uint32_t width, uint32_t fill, int align) ;

 
void lust_str_trunc_chars(lust_String *s, uint32_t chars) ;

 

void lust_vec_insert_at(lust_Vec *v, uint64_t i, uint64_t elem, uint64_t align, lust_loc loc) ;

void lust_vec_check_remove(lust_Vec *v, uint64_t i, lust_loc loc) ;

void lust_vec_remove_at(lust_Vec *v, uint64_t i, uint64_t elem) ;

 

uint8_t lust_str_starts_with(lust_str s, lust_str p) ;
uint8_t lust_str_ends_with(lust_str s, lust_str p) ;
 
uint64_t lust_memmem(const uint8_t *h, uint64_t hlen, const uint8_t *n, uint64_t nlen);
uint8_t lust_str_contains(lust_str s, lust_str p) ;

 
int64_t lust_str_find(lust_str s, lust_str p) ;
int64_t lust_str_rfind(lust_str s, lust_str p) ;

 
int lust_is_space(uint32_t c) ;

 
int lust_char_is_alphabetic(uint32_t c) ;
int lust_char_is_numeric(uint32_t c) ;
int lust_char_is_alphanumeric(uint32_t c) ;
int lust_char_is_lowercase(uint32_t c) ;
int lust_char_is_uppercase(uint32_t c) ;
int lust_char_is_control(uint32_t c) ;

lust_str lust_str_trim_start(lust_str s) ;

lust_str lust_str_trim_end(lust_str s) ;

 
 
lust_String lust_str_replacen(lust_str s, lust_str from, lust_str to, uint64_t count) ;

lust_String lust_str_replace(lust_str s, lust_str from, lust_str to) ;

lust_String lust_str_repeat(lust_str s, uint64_t n, lust_loc loc) ;

void lust_string_shrink_to(lust_String *s, uint64_t min_cap) ;

 
static uint64_t lust_str_prev_start(const uint8_t *p, uint64_t end) {
    uint64_t k = end - 1;
    while (k > 0 && (p[k] & 0xC0) == 0x80) k--;
    return k;
}

uint32_t lust_string_pop(lust_String *s) ;

 
static void lust_string_check_boundary(lust_String *s, uint64_t idx, const char *what, lust_loc loc) {
    if (idx > s->len || (idx < s->len && (s->ptr[idx] & 0xC0) == 0x80)) {
        lust_String m = lust_string_new();
        lust_string_push_cstr(&m, "assertion failed: self.is_char_boundary(");
        lust_string_push_cstr(&m, what);
        lust_string_push_cstr(&m, ")");
        lust_panic(&m, loc);
    }
}

 
uint32_t lust_string_remove(lust_String *s, uint64_t idx, lust_loc loc) ;

void lust_string_insert_bytes(lust_String *s, uint64_t idx, const uint8_t *p, uint64_t n, lust_loc loc) ;

void lust_string_insert_char(lust_String *s, uint64_t idx, uint32_t c, lust_loc loc) ;

void lust_string_truncate(lust_String *s, uint64_t n, lust_loc loc) ;

lust_String lust_string_split_off(lust_String *s, uint64_t at, lust_loc loc) ;

lust_str lust_str_trim(lust_str s) ;

 
lust_String lust_str_ascii_case(lust_str s, int upper) ;

typedef struct { lust_str s; uint64_t pos; } lust_Chars;
lust_Chars lust_chars(lust_str s) ;
uint64_t lust_chars_count(lust_Chars c) ;
 
uint32_t lust_utf8_prev(const uint8_t *p, uint64_t *end) ;

 
typedef struct { lust_str hay; uint64_t start, end, fpos, bpos, flags, count; } lust_split;
typedef struct {
    uint8_t kind;
    uint32_t ch;
    lust_str needle;
    const uint32_t *set;
    uint64_t n;
    uint8_t (*pred)(void *, uint32_t);
    void *env;
} lust_pat;
enum { LUST_PAT_CHAR, LUST_PAT_STR, LUST_PAT_SET, LUST_PAT_PRED, LUST_PAT_SPACE, LUST_PAT_ASCII_SPACE };
enum { LUST_SPLIT_FINISHED = 1, LUST_SPLIT_TRAILING = 2, LUST_SPLIT_MATCH_FW = 4, LUST_SPLIT_MATCH_BW = 8, LUST_SPLIT_EMPTY_DONE = 16 };

 
int lust_pat_hit(const lust_pat *p, uint32_t c) ;

 
int lust_split_match_fw(lust_split *s, const lust_pat *p, uint64_t *a, uint64_t *b) ;

 
int lust_split_match_bw(lust_split *s, const lust_pat *p, uint64_t *a, uint64_t *b) ;

lust_str lust_split_sub(lust_str h, uint64_t a, uint64_t b) ;

 
int lust_split_get_end(lust_split *s, lust_str *out) ;

 
int lust_split_fw(lust_split *s, const lust_pat *p, int incl, lust_str *out) ;

 
int lust_split_bw(lust_split *s, const lust_pat *p, int incl, lust_str *out) ;

 
int lust_split_step(lust_split *s, const lust_pat *p, uint8_t mode, int back, lust_str *out) ;

 
uint64_t lust_split_upper(const lust_split *s) ;

 
int lust_str_split_once(lust_str hay, const lust_pat *p, int back, lust_str *a, lust_str *b) ;

 

 
int lust_pat_match(lust_str hay, const lust_pat *p, int back, uint64_t *a, uint64_t *b) ;

 
int lust_pat_prefix(lust_str hay, const lust_pat *p, uint64_t *end) ;

 
int lust_pat_suffix(lust_str hay, const lust_pat *p, uint64_t *start) ;

 
lust_str lust_pat_trim_start(lust_str hay, const lust_pat *p) ;

 
lust_str lust_pat_trim_end(lust_str hay, const lust_pat *p) ;

 
int lust_matches_step(lust_split *s, const lust_pat *p, int back, uint64_t *idx, lust_str *out) ;

 
lust_String lust_pat_replacen(lust_str hay, const lust_pat *p, lust_str to, uint64_t count, uint64_t cap) ;

 
int lust_parse_int_radix(lust_str s, uint32_t radix, int is_signed, int bits, uint64_t *lo, uint64_t *hi, int *kind) ;

int lust_parse_int(lust_str s, int is_signed, int bits, uint64_t *lo, uint64_t *hi, int *kind) ;

 
void lust_radix_check(uint32_t radix, lust_loc loc) ;

 
int lust_parse_f64(lust_str s, double *out);
int lust_parse_f32(lust_str s, float *out);

 
int lust_str_parse_f64(lust_str s, double *out, int *kind) ;

int lust_str_parse_f32(lust_str s, float *out, int *kind) ;

 
int lust_parse_bool(lust_str s, uint8_t *out) ;

 
int lust_parse_char(lust_str s, uint32_t *out, int *kind) ;

 
lust_String lust_string_from_utf16_lossy(const uint16_t *v, uint64_t n) ;

 

static int lust_case_in(const uint32_t (*t)[2], uint64_t n, uint32_t c) ;
static const uint32_t *lust_case_map(const uint32_t (*t)[4], uint64_t n, uint32_t c) ;
 
static int lust_ci_then_cased(lust_str s, uint64_t i, int back) ;
lust_String lust_str_case(lust_str s, int upper) ;

 
lust_u128 lust_char_case(uint32_t c, uint8_t upper) ;

 
static void lust_encode_panic(const char *what, uint64_t need, uint32_t c, uint64_t have, lust_loc loc) ;

 
uint64_t lust_char_encode_utf8(uint32_t c, uint8_t *dst, uint64_t dst_len, lust_loc loc) ;

 
uint64_t lust_char_encode_utf16(uint32_t c, uint16_t *dst, uint64_t dst_len, lust_loc loc) ;

 
int lust_utf8_check(const uint8_t *v, uint64_t len, uint64_t *valid_up_to, uint8_t *error_len) ;

 
lust_String lust_env_arg(uint64_t i, int back) ;

 
void lust_fmt_utf8_error(lust_String *out, uint64_t valid_up_to, uint32_t has_len, uint64_t len) ;

 
uint32_t lust_digit(uint32_t c, uint32_t radix, lust_loc loc) ;

 
uint32_t lust_from_digit(uint32_t digit, uint32_t radix, lust_loc loc) ;

 
 
#ifndef LUST_RT_FLOAT_H
#define LUST_RT_FLOAT_H

 
#define LUST_FLOAT_DISPLAY 0
#define LUST_FLOAT_DEBUG 1
#define LUST_FLOAT_LOWER_EXP 2
#define LUST_FLOAT_UPPER_EXP 3

 
#define LUST_FLOAT_NO_PRECISION 0xFFFFFFFFu

 
typedef struct {
    uint32_t precision;
    uint32_t width;
    uint32_t fill;  
    uint8_t align;  
    uint8_t plus;   
    uint8_t zero_pad;
    uint8_t alt;
    uint8_t mode;
} lust_float_spec;

 
void lust_fmt_f64(lust_String *out, double v, lust_float_spec spec);
void lust_fmt_f32(lust_String *out, float v, lust_float_spec spec);

 
void lust_fmt_f64_display(lust_String *out, double v);
void lust_fmt_f64_debug(lust_String *out, double v);
void lust_fmt_f32_display(lust_String *out, float v);
void lust_fmt_f32_debug(lust_String *out, float v);

 
void lust_fmt_js_f64(lust_String *out, double v);
void lust_fmt_js_f32(lust_String *out, float v);
 
uint64_t lust_fmt_js_f64_buf(char *buf, double v);
uint64_t lust_fmt_js_f32_buf(char *buf, float v);

 
int lust_parse_f64(lust_str s, double *out);
int lust_parse_f32(lust_str s, float *out);

 
int8_t lust_f64_to_i8(double v);
int16_t lust_f64_to_i16(double v);
int32_t lust_f64_to_i32(double v);
int64_t lust_f64_to_i64(double v);
uint8_t lust_f64_to_u8(double v);
uint16_t lust_f64_to_u16(double v);
uint32_t lust_f64_to_u32(double v);
uint64_t lust_f64_to_u64(double v);
int8_t lust_f32_to_i8(float v);
int16_t lust_f32_to_i16(float v);
int32_t lust_f32_to_i32(float v);
int64_t lust_f32_to_i64(float v);
uint8_t lust_f32_to_u8(float v);
uint16_t lust_f32_to_u16(float v);
uint32_t lust_f32_to_u32(float v);
uint64_t lust_f32_to_u64(float v);
 
void lust_f64_to_i128(double v, uint64_t *lo, uint64_t *hi);
void lust_f64_to_u128(double v, uint64_t *lo, uint64_t *hi);
void lust_f32_to_i128(float v, uint64_t *lo, uint64_t *hi);
void lust_f32_to_u128(float v, uint64_t *lo, uint64_t *hi);

 
double lust_i64_to_f64(int64_t v);
double lust_u64_to_f64(uint64_t v);
float lust_i64_to_f32(int64_t v);
float lust_u64_to_f32(uint64_t v);
double lust_i128_to_f64(uint64_t lo, uint64_t hi);
double lust_u128_to_f64(uint64_t lo, uint64_t hi);
float lust_i128_to_f32(uint64_t lo, uint64_t hi);
float lust_u128_to_f32(uint64_t lo, uint64_t hi);

 
double lust_fmod_f64(double, double);
float lust_fmod_f32(float, float);

 
float lust_f64_to_f32(double v);
double lust_f32_to_f64(float v);


 
double sqrt(double);
float sqrtf(float);
double pow(double, double);
float powf(float, float);
double exp(double);
float expf(float);
double log(double);
float logf(float);
double log2(double);
float log2f(float);
double log10(double);
float log10f(float);
double floor(double);
float floorf(float);
double ceil(double);
float ceilf(float);
double round(double);
float roundf(float);
double trunc(double);
float truncf(float);
double fma(double, double, double);
float fmaf(float, float, float);
double fabs(double);
float fabsf(float);
double copysign(double, double);
float copysignf(float, float);

double lust_f64_powi(double a, int32_t e);
float lust_f32_powi(float a, int32_t e);
double lust_f64_min(double a, double b);
double lust_f64_max(double a, double b);
float lust_f32_min(float a, float b);
float lust_f32_max(float a, float b);
double lust_f64_signum(double a);
float lust_f32_signum(float a);
uint64_t lust_f64_to_bits(double v);
uint32_t lust_f32_to_bits(float v);
double lust_f64_from_bits_of(uint64_t b);
float lust_f32_from_bits_of(uint32_t b);


#endif


 
 
#ifndef LUST_RT_FMT_H
#define LUST_RT_FMT_H

 
#define LUST_ALIGN_LEFT 0u
#define LUST_ALIGN_RIGHT 1u
#define LUST_ALIGN_CENTER 2u
#define LUST_ALIGN_UNKNOWN 3u

 
#define LUST_FLAG_PLUS 1u
#define LUST_FLAG_MINUS 2u
#define LUST_FLAG_ALT 4u
#define LUST_FLAG_ZERO 8u
#define LUST_FLAG_DEBUG_LOWER_HEX 16u
#define LUST_FLAG_DEBUG_UPPER_HEX 32u
#define LUST_FLAG_WIDTH 64u
#define LUST_FLAG_PREC 128u

 
typedef struct lust_sink lust_sink;
struct lust_sink {
    int (*write)(lust_sink *self, const uint8_t *p, uint64_t n);
    lust_String *direct;
};

 
typedef struct {
    lust_sink base;
    lust_sink *inner;
    uint8_t *on_newline;
} lust_pad_sink;

 
typedef struct {
    lust_sink *buf;
    uint32_t fill;
    uint8_t align;
    uint8_t flags;
    uint16_t width;
    uint16_t prec;
} lust_Formatter;

 
typedef struct {
    lust_pad_sink pad;
    lust_Formatter f;
    uint8_t state;
} lust_fmt_slot;

 
typedef struct {
    lust_Formatter *fmt;
    uint8_t err;
    uint8_t has_fields;
} lust_DebugStruct;
typedef struct {
    lust_Formatter *fmt;
    uint64_t fields;
    uint8_t err;
    uint8_t empty_name;
} lust_DebugTuple;
 
typedef struct {
    lust_Formatter *fmt;
    uint8_t err;
    uint8_t has_fields;
    uint8_t set;
} lust_DebugList;
typedef struct {
    lust_Formatter *fmt;
    uint8_t err;
    uint8_t has_fields;
    uint8_t has_key;
    uint8_t state;
} lust_DebugMap;

 
typedef struct {
    int (*fmt)(const void *env, lust_sink *k);
    const void *env;
    const char *text;
    uint64_t len;
    uint64_t cap;
} lust_Arguments;

 
_Static_assert(sizeof(lust_Formatter) == 24 && sizeof(lust_DebugTuple) == 24, "fmt layout");
_Static_assert(sizeof(lust_Arguments) == 40, "fmt layout");
_Static_assert(sizeof(lust_DebugStruct) == 16 && sizeof(lust_DebugList) == 16 && sizeof(lust_DebugMap) == 16, "fmt layout");

 
void lust_sink_string(lust_sink *k, lust_String *s);
 
void lust_print_begin(lust_sink *k, int to_stderr);
void lust_print_end(int to_stderr);
 
typedef struct {
    lust_sink base;
    int32_t err;
} lust_io_sink;
void lust_io_begin(lust_io_sink *k, int to_stderr);
void lust_f_init(lust_Formatter *f, lust_sink *buf);
 
int lust_args_write(const lust_Arguments *a, lust_sink *k);
int lust_f_args(lust_Formatter *f, const lust_Arguments *a);
lust_String lust_args_to_string(const lust_Arguments *a);
 
void lust_f_set(lust_Formatter *f, uint32_t fill, uint32_t align, uint32_t flags, uint32_t width, uint32_t prec);

int lust_f_write(lust_Formatter *f, const void *p, uint64_t n);
int lust_f_write_str(lust_Formatter *f, lust_str s);
int lust_f_write_char(lust_Formatter *f, uint32_t c);
 
int lust_f_pad(lust_Formatter *f, lust_str s);
int lust_f_pad_integral(lust_Formatter *f, int nonneg, lust_str prefix, lust_str digits);

 
int lust_f_u64(lust_Formatter *f, uint64_t v);
int lust_f_i64(lust_Formatter *f, int64_t v);
int lust_f_u128(lust_Formatter *f, lust_u128 v);
int lust_f_i128(lust_Formatter *f, lust_i128 v);
int lust_f_radix(lust_Formatter *f, uint64_t lo, uint64_t hi, uint32_t mode);
int lust_f_dbg_u64(lust_Formatter *f, uint64_t v);
int lust_f_dbg_i64(lust_Formatter *f, int64_t v, uint64_t mask);
int lust_f_dbg_u128(lust_Formatter *f, lust_u128 v);
int lust_f_dbg_i128(lust_Formatter *f, lust_i128 v);
 
int lust_f_f64(lust_Formatter *f, double v, uint32_t mode);
int lust_f_f32(lust_Formatter *f, float v, uint32_t mode);
 
int lust_f_bool(lust_Formatter *f, uint8_t v);
int lust_f_char(lust_Formatter *f, uint32_t c);
int lust_f_dbg_char(lust_Formatter *f, uint32_t c);
int lust_f_dbg_str(lust_Formatter *f, lust_str s);
int lust_f_unit(lust_Formatter *f);
int lust_f_fnptr(lust_Formatter *f, const void *p);
int lust_f_pointer(lust_Formatter *f, const void *p);
uint32_t lust_f_count(uint64_t n, lust_loc loc);

 
void lust_dstruct_new(lust_DebugStruct *d, lust_Formatter *f, lust_str name);
lust_Formatter *lust_dstruct_field(lust_DebugStruct *d, lust_fmt_slot *s, lust_str name);
void lust_dstruct_field_end(lust_DebugStruct *d, lust_fmt_slot *s, int err);
int lust_dstruct_finish(lust_DebugStruct *d);
int lust_dstruct_finish_ne(lust_DebugStruct *d);
void lust_dtuple_new(lust_DebugTuple *d, lust_Formatter *f, lust_str name);
lust_Formatter *lust_dtuple_field(lust_DebugTuple *d, lust_fmt_slot *s);
void lust_dtuple_field_end(lust_DebugTuple *d, lust_fmt_slot *s, int err);
int lust_dtuple_finish(lust_DebugTuple *d);
int lust_dtuple_finish_ne(lust_DebugTuple *d);
void lust_dlist_new(lust_DebugList *d, lust_Formatter *f, int set);
lust_Formatter *lust_dlist_entry(lust_DebugList *d, lust_fmt_slot *s);
void lust_dlist_entry_end(lust_DebugList *d, lust_fmt_slot *s, int err);
int lust_dlist_finish(lust_DebugList *d);
int lust_dlist_finish_ne(lust_DebugList *d);
void lust_dmap_new(lust_DebugMap *d, lust_Formatter *f);
lust_Formatter *lust_dmap_key(lust_DebugMap *d, lust_fmt_slot *s, lust_loc loc);
void lust_dmap_key_end(lust_DebugMap *d, lust_fmt_slot *s, int err);
lust_Formatter *lust_dmap_value(lust_DebugMap *d, lust_fmt_slot *s, lust_loc loc);
void lust_dmap_value_end(lust_DebugMap *d, lust_fmt_slot *s, int err);
int lust_dmap_finish(lust_DebugMap *d, lust_loc loc);
int lust_dmap_finish_ne(lust_DebugMap *d, lust_loc loc);

 
void lust_fmt_failed(uint32_t what, lust_loc loc);


#endif


 
 

typedef uint8_t (*lust_less_fn)(void *ctx, const void *a, const void *b);

typedef struct {
    uint64_t size, align;
    uint8_t freeze, copy;
    void *ctx;
    lust_less_fn less;
} lust_sort_cx;

#define LS_AT(p, i) ((uint8_t *)(p) + (uint64_t)(i) * s->size)
#define LS_LESS(a, b) (s->less(s->ctx, (a), (b)) != 0)

uint32_t lust_sort_ilog2(uint64_t n) ;

void lust_sort_swap(lust_sort_cx *s, uint8_t *a, uint8_t *b) ;

void lust_sort_reverse(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 
typedef struct { uint8_t *p; uint8_t local[64] __attribute__((aligned(16))); } lust_sort_tmp;
uint8_t *lust_sort_tmp_get(lust_sort_cx *s, lust_sort_tmp *t) ;
void lust_sort_tmp_free(lust_sort_tmp *t) ;

 
uint64_t lust_sort_find_run(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *was_reversed) ;

 
void lust_sort_insert_tail(lust_sort_cx *s, uint8_t *begin, uint8_t *tail) ;

void lust_sort_insertion_shift_left(lust_sort_cx *s, uint8_t *v, uint64_t len, uint64_t offset) ;

 
void lust_sort_sort4_stable(lust_sort_cx *s, uint8_t *v, uint8_t *dst) ;

void lust_sort_ord_violation(void) ;

 
void lust_sort_bidir_merge(lust_sort_cx *s, uint8_t *src, uint64_t len, uint8_t *dst) ;

void lust_sort_sort8_stable(lust_sort_cx *s, uint8_t *v, uint8_t *dst, uint8_t *scratch) ;

 
void lust_sort_small_general(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch) ;

 
void lust_sort_swap_if_less(lust_sort_cx *s, uint8_t *v, uint64_t a_pos, uint64_t b_pos) ;

void lust_sort_net(lust_sort_cx *s, uint8_t *v, const uint8_t *pairs, int n) ;

 
void lust_sort_small_network(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 
uint8_t *lust_sort_median3(lust_sort_cx *s, uint8_t *a, uint8_t *b, uint8_t *c) ;
uint8_t *lust_sort_median3_rec(lust_sort_cx *s, uint8_t *a, uint8_t *b, uint8_t *c, uint64_t n) ;
uint64_t lust_sort_choose_pivot(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 

uint64_t lust_sort_stable_threshold(lust_sort_cx *s) ;

void lust_sort_stable_small(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch) ;

 
void lust_sort_merge(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint64_t mid) ;

void lust_sort_drift(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint8_t eager_sort);

 
uint64_t lust_sort_stable_partition(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len,
                                           uint64_t pivot_pos, uint8_t pivot_goes_left, uint8_t inv) ;

 
void lust_sort_stable_quick(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint32_t limit,
                                   uint8_t *left_ancestor_pivot) ;

void lust_sort_stable_quicksort(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len) ;

 
void lust_sort_drift(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *scratch, uint64_t scratch_len, uint8_t eager_sort) ;

 
void lust_sort_stable(void *v, uint64_t len, uint64_t size, uint64_t align, uint8_t freeze, void *ctx, lust_less_fn less) ;

 

uint8_t lust_sort_network_ok(lust_sort_cx *s) ;

uint64_t lust_sort_unstable_threshold(lust_sort_cx *s) ;

void lust_sort_unstable_small(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 
void lust_sort_sift_down(lust_sort_cx *s, uint8_t *v, uint64_t len, uint64_t node) ;
void lust_sort_heapsort(lust_sort_cx *s, uint8_t *v, uint64_t len) ;

 
uint8_t lust_sort_cmp(lust_sort_cx *s, uint8_t *a, uint8_t *b, uint8_t inv) ;

uint64_t lust_sort_lomuto(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *pivot, uint8_t inv) ;

uint64_t lust_sort_hoare(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *pivot, uint8_t inv) ;

uint64_t lust_sort_partition(lust_sort_cx *s, uint8_t *v, uint64_t len, uint64_t pivot, uint8_t inv) ;

void lust_sort_unstable_quick(lust_sort_cx *s, uint8_t *v, uint64_t len, uint8_t *ancestor_pivot, uint32_t limit) ;

 
void lust_sort_unstable(void *v, uint64_t len, uint64_t size, uint64_t align, uint8_t freeze, uint8_t copy, void *ctx, lust_less_fn less) ;

#undef LS_AT
#undef LS_LESS

 
typedef int32_t (*lust_cmp_fn)(void *ctx, const void *p);
int64_t lust_binary_search(void *v, uint64_t len, uint64_t size, void *ctx, lust_cmp_fn cmp) ;


 


 
 
#ifndef LUST_RT_DEPS_H
#define LUST_RT_DEPS_H

 
uint64_t lust_memchr(uint32_t needle, const uint8_t *p, uint64_t len);
uint64_t lust_memrchr(uint32_t needle, const uint8_t *p, uint64_t len);
uint64_t lust_memmem(const uint8_t *h, uint64_t hlen, const uint8_t *n, uint64_t nlen);
 
uint64_t lust_memchr3(uint32_t a, uint32_t b, uint32_t c, const uint8_t *p, uint64_t n);
uint64_t lust_memrchr3(uint32_t a, uint32_t b, uint32_t c, const uint8_t *p, uint64_t n);

 
uint64_t lust_xxh3_64(const uint8_t *p, uint64_t len, uint64_t seed);
lust_u128 lust_xxh3_128(const uint8_t *p, uint64_t len, uint64_t seed);


#endif


 

 
#define LUST_MO(o) ((o) == 0 ? 0 : (o) == 1 ? 3 : (o) == 2 ? 2 : (o) == 3 ? 4 : 5)
 
#define LUST_MO_CAS(s, f) (((f) == 4) ? 5 : ((f) == 2 && ((s) == 0 || (s) == 1)) ? ((s) == 0 ? 2 : 4) : LUST_MO(s))
 
#define LUST_MO_LOADPART(o) ((o) == 4 ? 5 : ((o) == 2 || (o) == 3) ? 2 : 0)


 
#define LUST_ATOMIC_RS "core/src/sync/atomic.rs:"

#define LUST_ATOMIC_WIDTH(N, U, S)                                                                                     \
    U lust_at_load_##N(U *p, uint32_t o, lust_loc loc) ;                                                                                                                 \
    void lust_at_store_##N(U *p, U v, uint32_t o, lust_loc loc) ;                                                                                                                 \
    U lust_at_swap_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    int lust_at_cas_##N(U *p, U cur, U nv, uint32_t s, uint32_t f, U *old, int weak) ;                                                                                                                 \
    U lust_at_fetch_add_##N(U *p, U v, uint32_t o) ;        \
    U lust_at_fetch_sub_##N(U *p, U v, uint32_t o) ;        \
    U lust_at_fetch_and_##N(U *p, U v, uint32_t o) ;        \
    U lust_at_fetch_or_##N(U *p, U v, uint32_t o) ;          \
    U lust_at_fetch_xor_##N(U *p, U v, uint32_t o) ;        \
    U lust_at_fetch_nand_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    U lust_at_fetch_umax_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    U lust_at_fetch_umin_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    U lust_at_fetch_smax_##N(U *p, U v, uint32_t o) ;                                                                                                                 \
    U lust_at_fetch_smin_##N(U *p, U v, uint32_t o) ;

LUST_ATOMIC_WIDTH(1, uint8_t, int8_t)
LUST_ATOMIC_WIDTH(2, uint16_t, int16_t)
LUST_ATOMIC_WIDTH(4, uint32_t, int32_t)
LUST_ATOMIC_WIDTH(8, uint64_t, int64_t)

 
uint8_t lust_at_fetch_bnand_1(uint8_t *p, uint8_t v, uint32_t o) ;

void lust_at_fence(uint32_t o, lust_loc loc) ;

void lust_at_compiler_fence(uint32_t o, lust_loc loc) ;

 

 
void lust_arc_inc(uint64_t *c) ;

 
int lust_arc_dec(uint64_t *c) ;

 
void *lust_arc_empty(void) ;

 
uint64_t lust_arc_load(uint64_t *c) ;

 
void lust_arc_downgrade(uint64_t *h) ;

 
int lust_arc_upgrade(uint64_t *h) ;

 
uint64_t lust_arc_weak_count(uint64_t *h) ;

 
uint64_t lust_arc_weak_weak_count(uint64_t *h) ;

 
int lust_arc_is_unique(uint64_t *h) ;

 
int lust_arc_make_mut_state(uint64_t *h) ;

 
int lust_arc_take_unique(uint64_t *h) ;

 

 
void lust_poison_enter(uint8_t *f) ;
void lust_poison_leave(uint8_t *f) ;

 
static void lust_lock_pause(void) {
#if !defined(__TINYC__) && (defined(__x86_64__) || defined(__i386__))
    __builtin_ia32_pause();
#elif !defined(__TINYC__) && defined(__aarch64__)
    __asm__ __volatile__("yield");
#endif
}

 
static uint32_t lust_lock_spin(uint32_t *st, uint32_t busy) {
    uint32_t s;
    for (int i = 0; i < 100; i++) {
        __atomic_load(st, &s, 0);
        if (s != busy) return s;
        lust_lock_pause();
    }
    __atomic_load(st, &s, 0);
    return s;
}

 
void lust_mutex_lock(uint32_t *st) ;

 
int lust_mutex_trylock(uint32_t *st) ;

void lust_mutex_unlock(uint32_t *st) ;

 
#define LUST_RW_WRITER 0xffffffffu
void lust_rw_read(uint32_t *st) ;

int lust_rw_tryread(uint32_t *st) ;

void lust_rw_read_unlock(uint32_t *st) ;

void lust_rw_write(uint32_t *st) ;

int lust_rw_trywrite(uint32_t *st) ;

void lust_rw_write_unlock(uint32_t *st) ;

 
typedef struct lust_ThreadInfo {
    uint64_t rc;
    uint64_t id;
    const uint8_t *name;
    uint64_t name_len;
     
    uint8_t *name_buf;
     
    uintptr_t guard_lo, guard_hi;
    void *alt;
} lust_ThreadInfo;

 
typedef struct lust_Scope {
    uint32_t live;
    uint32_t panicked;  
} lust_Scope;

typedef struct lust_JoinHdr {
    uintptr_t t;  
    lust_ThreadInfo *th;
    uint32_t rc;
    uint32_t done;
    void (*run)(struct lust_JoinHdr *);
    void (*drop_ret)(struct lust_JoinHdr *);
    lust_Scope *scope;  
    uint32_t panicked;  
    lust_dyn payload;
} lust_JoinHdr;

 
#ifdef __APPLE__
#define LUST_PTHREAD_ID_P(p) ((pthread_t *)(void *)(p))
#define LUST_PTHREAD_ID(v) ((pthread_t)(uintptr_t)(v))
#else
#define LUST_PTHREAD_ID_P(p) (p)
#define LUST_PTHREAD_ID(v) (v)
#endif


 
void lust_thread_spawn(lust_JoinHdr *h, lust_loc loc) ;

 
typedef struct lust_ThreadBuilder {
    lust_String name;
    uint64_t stack;
    uint8_t has_name;
    uint8_t has_stack;
} lust_ThreadBuilder;

#if !defined(__APPLE__) && !defined(_WIN32)
int pthread_attr_init(void *attr);
int pthread_attr_destroy(void *attr);
int pthread_attr_setstacksize(void *attr, uint64_t size);
int pthread_setname_np(uintptr_t t, const char *name);
#endif

 
int lust_thread_spawn_builder(lust_JoinHdr *h, const lust_ThreadBuilder *b) ;

 

 
uint64_t lust_avail_parallelism(int32_t *err) ;

 
void lust_thread_join(lust_JoinHdr *h) ;

void lust_join_free(lust_JoinHdr *h) ;

 
void lust_join_drop(lust_JoinHdr *h) ;

int lust_join_is_finished(lust_JoinHdr *h) ;

 
lust_ThreadInfo *lust_thread_current(void) ;

lust_ThreadInfo *lust_thread_clone(lust_ThreadInfo *t) ;

void lust_thread_drop(lust_ThreadInfo *t) ;

void lust_thread_yield(void) ;

 
void lust_scope_wait(lust_Scope *sc) ;

 
typedef struct lust_Chan {
    uint32_t lock;
    uint32_t seq;
    uint32_t sleepers;
    uint64_t senders;
    uint32_t rx_alive;
    uint32_t rx_waiting;
    uint32_t tx_waiting;
    uint32_t rx_claim;
    int64_t cap;
    uint64_t esize;
    uint64_t ealign;
    uint8_t *buf;
    uint64_t head, len, bufcap;
    uint64_t taken;
    void (*drop_elem)(void *);
} lust_Chan;



lust_Chan *lust_chan_new(uint64_t esize, uint64_t ealign, int64_t cap, void (*drop_elem)(void *)) ;

 
int lust_chan_send(lust_Chan *c, const void *v) ;

 
int lust_chan_try_send(lust_Chan *c, const void *v) ;

 
int lust_chan_recv(lust_Chan *c, void *out, int block) ;

lust_Chan *lust_chan_clone_sender(lust_Chan *c) ;

void lust_chan_drop_sender(lust_Chan *c) ;

void lust_chan_drop_receiver(lust_Chan *c) ;

 
void lust_cv_wait(uint32_t *cv, uint32_t *m) ;

void lust_cv_notify(uint32_t *cv, int all) ;

 
#if defined(__linux__)
#if defined(__x86_64__)
#define LUST_SYS_CLOCK_GETTIME 228
#elif defined(__aarch64__)
#define LUST_SYS_CLOCK_GETTIME 113
#endif
#endif

static void lust_mono_now(long ts[2]) ;

 
void lust_cv_start(long ts[2]) ;

 
int lust_cv_left(const long start[2], uint64_t secs, uint32_t nanos, uint64_t *rs, uint32_t *rn) ;

int lust_cv_wait_timeout(uint32_t *cv, uint32_t *m, uint64_t secs, uint32_t nanos) ;

 
int lust_chan_recv_timeout(lust_Chan *c, void *out, uint64_t secs, uint32_t nanos) ;

typedef struct lust_Barrier {
    uint32_t lock;
    uint32_t seq;
    uint64_t count;
    uint64_t gen;
    uint64_t n;
} lust_Barrier;

 
int lust_barrier_wait(lust_Barrier *b) ;

 
int lust_once_begin(uint32_t *st) ;

void lust_once_finish(uint32_t *st) ;

 
void lust_once_abort(uint32_t *st) ;

 
struct lust_once_guard { uint32_t *st; void *env; void (*drop)(void *); int32_t armed; };
void lust_once_guard_end(struct lust_once_guard *g) ;

int lust_once_is_done(uint32_t *st) ;

 
typedef struct lust_Duration {
    uint64_t secs;
    uint32_t nanos;
} lust_Duration;

 
lust_Duration lust_dur_new(uint64_t secs, uint32_t nanos, lust_loc loc) ;

 
lust_u128 lust_dur_as(lust_Duration d, uint64_t per_sec, uint64_t nanos_per) ;


 
void lust_thread_sleep(lust_Duration d) ;

 
 
#ifndef LUST_RT_SYS_H
#define LUST_RT_SYS_H

 
#ifdef __APPLE__
#define LUST_ST_ATIME(st) (st).st_atimespec
#define LUST_ST_MTIME(st) (st).st_mtimespec
#define LUST_ST_CTIME(st) (st).st_ctimespec
#define LUST_ST_BTIME(st) (st).st_birthtimespec
#else
#define LUST_ST_ATIME(st) (st).st_atim
#define LUST_ST_MTIME(st) (st).st_mtim
#define LUST_ST_CTIME(st) (st).st_ctim
#endif

 
int64_t lust_sys_write_std(int32_t fd, const uint8_t *p, uint64_t len);
int32_t lust_sys_flush_std(int32_t fd);

 
lust_Vec lust_sys_fmt_arguments_bytes(lust_Arguments args);

 
lust_str lust_sys_str_as_bytes(lust_str s);
lust_str lust_sys_bytes_as_str(const uint8_t *p, uint64_t len);
lust_String lust_sys_string_from_utf8_unchecked(lust_Vec v);
uint64_t lust_sys_utf8_valid_up_to(const uint8_t *p, uint64_t len);
void lust_sys_utf8_lossy(const uint8_t *p, uint64_t len, lust_String *out);

 
uint8_t lust_sys_getenv(const uint8_t *k, uint64_t klen, lust_Vec *out);

 
void lust_sys_environ(lust_Vec *out);
void lust_sys_argv(lust_Vec *out);
int32_t lust_sys_getcwd(lust_Vec *out);
int32_t lust_sys_chdir(const uint8_t *p, uint64_t len);
int32_t lust_sys_symlink(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen);
int32_t lust_sys_readlink(const uint8_t *p, uint64_t len, lust_Vec *out);

 
int32_t lust_sys_read_file(const uint8_t *p, uint64_t len, lust_Vec *out);
int32_t lust_sys_write_file(const uint8_t *p, uint64_t len, const uint8_t *d, uint64_t dlen);
int32_t lust_sys_path_op(const uint8_t *p, uint64_t len, int32_t op);
int32_t lust_sys_rename(const uint8_t *a, uint64_t alen, const uint8_t *b, uint64_t blen);
int32_t lust_sys_stat(const uint8_t *p, uint64_t len, uint8_t follow, lust_Vec *out);
int32_t lust_sys_realpath(const uint8_t *p, uint64_t len, lust_Vec *out);
int32_t lust_sys_read_dir(const uint8_t *p, uint64_t len, lust_Vec *out);
int32_t lust_sys_remove_dir_all(const uint8_t *p, uint64_t len);

 
int32_t lust_sys_btime_path(const char *path, int32_t follow, int64_t *sec, int64_t *nsec);
int32_t lust_sys_btime_fd(int32_t fd, int64_t *sec, int64_t *nsec);

uint32_t lust_sys_getpid(void);

 
int32_t lust_sys_current_exe(lust_Vec *out);

 
void lust_sys_os_error_text(int32_t code, lust_String *out);


#endif

 
 
#ifndef LUST_RT_SYSIO_H
#define LUST_RT_SYSIO_H

 
int64_t lust_sys_fd_read(int32_t fd, uint64_t max, lust_Vec *out);
 
int64_t lust_sys_fd_write(int32_t fd, const uint8_t *p, uint64_t len);
 
int32_t lust_sys_fd_close(int32_t fd);
 
int32_t lust_sys_fd_dup(int32_t fd);
 
int32_t lust_sys_fd_sync(int32_t fd);
 
int32_t lust_sys_fd_sync_data(int32_t fd);
 
int32_t lust_sys_fd_truncate(int32_t fd, uint64_t len);
 
int64_t lust_sys_fd_seek(int32_t fd, int64_t off, int32_t whence);
 
int64_t lust_sys_fd_pread(int32_t fd, uint64_t max, int64_t off, lust_Vec *out);
 
int64_t lust_sys_fd_pwrite(int32_t fd, const uint8_t *p, uint64_t len, int64_t off);
 
int32_t lust_sys_fd_isatty(int32_t fd);
 
int32_t lust_sys_fd_stat(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_fd_open(const uint8_t *p, uint64_t len, int32_t flags);
 
int32_t lust_sys_fd_open_ext(const uint8_t *p, uint64_t len, int32_t flags, int32_t custom, uint32_t mode);

 
int64_t lust_sys_stdin_read(uint64_t max, lust_Vec *out);
int64_t lust_sys_stdin_fill(lust_Vec *out);
void lust_sys_stdin_consume(uint64_t n);

 
int32_t lust_sys_proc_spawn(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                            const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                            const uint8_t *fds, uint64_t fdslen, lust_Vec *out);
 
int32_t lust_sys_proc_exec(const uint8_t *prog, uint64_t proglen, const uint8_t *args, uint64_t argslen,
                           const uint8_t *env, uint64_t envlen, const uint8_t *cwd, uint64_t cwdlen, uint32_t stdio,
                           const uint8_t *fds, uint64_t fdslen);
 
int64_t lust_sys_proc_wait(uint32_t pid, uint8_t block);
 
int32_t lust_sys_proc_kill(uint32_t pid);
 
int32_t lust_sys_fd_read_both(int32_t fd1, lust_Vec *out1, int32_t fd2, lust_Vec *out2);


#endif

 
 
#ifndef LUST_RT_SYSNET_H
#define LUST_RT_SYSNET_H

 
int32_t lust_sys_net_resolve(const uint8_t *host, uint64_t hostlen, uint64_t port, lust_Vec *out);
 
int32_t lust_sys_net_tcp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out);
 
int32_t lust_sys_net_udp_bind(const uint8_t *rec, uint64_t len, lust_Vec *out);
 
int32_t lust_sys_net_tcp_connect(const uint8_t *rec, uint64_t len, lust_Vec *out);
 
int32_t lust_sys_net_tcp_connect_timeout(const uint8_t *rec, uint64_t len, int64_t timeout_us, lust_Vec *out);
 
int32_t lust_sys_net_connect_fd(int32_t fd, const uint8_t *rec, uint64_t len);
 
int32_t lust_sys_net_accept(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_net_addr_of(int32_t fd, int32_t peer, lust_Vec *out);
 
int32_t lust_sys_net_shutdown(int32_t fd, int32_t how);
 
int32_t lust_sys_net_setopt(int32_t fd, int32_t opt, int64_t val);
int64_t lust_sys_net_getopt(int32_t fd, int32_t opt);
 
int64_t lust_sys_net_sendto(int32_t fd, const uint8_t *p, uint64_t len, const uint8_t *rec, uint64_t rlen);
 
int64_t lust_sys_net_recvfrom(int32_t fd, uint64_t max, int32_t flags, lust_Vec *out, lust_Vec *addrout);
 
 
int32_t lust_sys_net_unix_pair(lust_Vec *out);
 
int32_t lust_sys_net_unix_bind(const uint8_t *p, uint64_t len, int32_t abstract);
 
int32_t lust_sys_net_unix_connect(const uint8_t *p, uint64_t len, int32_t abstract);
 
int32_t lust_sys_net_unix_accept(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_net_unix_addr(int32_t fd, int32_t peer, lust_Vec *out);


#endif

 
 
#ifndef LUST_RT_SYSX_H
#define LUST_RT_SYSX_H

 
int32_t lust_sys_x_kill(int32_t pid, int32_t sig);
 
int32_t lust_sys_x_getppid(void);
 
int32_t lust_sys_x_prctl_deathsig(int32_t sig);
 
int32_t lust_sys_x_waitid(int32_t idtype, int32_t id, int32_t options, lust_Vec *out);
 
int32_t lust_sys_x_sigmask(int32_t how, uint64_t set);
 
int32_t lust_sys_x_prctl_thp(int32_t mode, int32_t val);
 
int32_t lust_sys_x_getrlimit(int32_t resource, lust_Vec *out);
 
int32_t lust_sys_x_setrlimit(int32_t resource, uint64_t current, uint64_t maximum);
 
int32_t lust_sys_x_openat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mode);
 
int32_t lust_sys_x_statat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out);
 
int32_t lust_sys_x_fstat(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_x_statx(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, uint32_t mask, lust_Vec *out);
 
int32_t lust_sys_x_accessat(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t mode, int32_t flags);
 
int32_t lust_sys_x_utimensat(int32_t dirfd, const uint8_t *p, uint64_t len, int64_t a_sec, int64_t a_nsec, int64_t m_sec, int64_t m_nsec, int32_t flags);
 
int32_t lust_sys_x_mknodat(int32_t dirfd, const uint8_t *p, uint64_t len, uint32_t mode, uint64_t dev);
 
int32_t lust_sys_x_fcntl_getfl(int32_t fd);
 
int32_t lust_sys_x_fcntl_setfl(int32_t fd, int32_t flags);
 
int32_t lust_sys_x_winsize(int32_t fd, lust_Vec *out);
 
 
int32_t lust_sys_sig_register(int32_t sig, int32_t kind, void *flag, uint64_t value);
 
int32_t lust_sys_sig_register_pipe(int32_t sig, int32_t write_fd);
 
void lust_sys_sig_unregister_pipe(int32_t write_fd);
 
int32_t lust_sys_sig_pipe(lust_Vec *out);
 
int32_t lust_sys_sig_poll_read(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_sig_read_now(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_sig_raise(int32_t sig);
 
int32_t lust_sys_sig_restore_raise(int32_t sig);
 
void lust_sys_sig_exit(int32_t status);
 
void lust_sys_sig_abort(void);
 
int32_t lust_sys_x_pipe(int32_t flags, lust_Vec *out);
 
int32_t lust_sys_x_dup2(int32_t oldfd, int32_t newfd);
 
int32_t lust_sys_x_poll(lust_Vec *recs, int64_t sec, int64_t nsec);
 
int32_t lust_sys_x_inotify_init1(int32_t flags);
 
int32_t lust_sys_x_inotify_add_watch(int32_t fd, const uint8_t *p, uint64_t len, uint32_t mask);
 
int32_t lust_sys_x_inotify_rm_watch(int32_t fd, int32_t wd);
 
int64_t lust_sys_x_getdents(int32_t fd, uint64_t max, lust_Vec *out);
 
int32_t lust_sys_x_statvfs(const uint8_t *p, uint64_t len, lust_Vec *out);
 
int32_t lust_sys_x_fstatvfs(int32_t fd, lust_Vec *out);
 
int32_t lust_sys_x_fanotify_init(uint32_t flags, uint32_t event_f_flags);
 
int32_t lust_sys_x_fanotify_mark(int32_t fd, uint32_t flags, uint64_t mask, int32_t dirfd, int32_t has_path, const uint8_t *p, uint64_t len);
 
int32_t lust_sys_x_name_to_handle_at(int32_t dirfd, const uint8_t *p, uint64_t len, int32_t flags, lust_Vec *out);
 
int32_t lust_sys_x_open_by_handle_at(int32_t mount_fd, int32_t handle_type, const uint8_t *p, uint64_t len, int32_t flags);
 
int32_t lust_sys_x_kqueue(void);
 
int32_t lust_sys_x_kevent(int32_t fd, const uint8_t *changes, uint64_t clen, lust_Vec *events, int32_t has_timeout, int64_t sec, int64_t nsec);


#endif

 
 
#ifndef LUST_RT_STDC_H
#define LUST_RT_STDC_H

 
lust_u128 lust_clock_now_raw(void);
lust_u128 lust_system_time_raw(void);

 
uint32_t lust_fmt_align(lust_Formatter *f);


#endif


/* Inline fast paths of the hottest small runtime helpers, for units an optimizing C
   compiler builds (release builds have no LTO, so each helper would be a call into the
   runtime unit: atomic loads, Once checks, leading_zeros, slice ranges and division were
   about 10% of a release tsgo's cycles). Each macro keeps its function's name, arguments
   and result; a slow path (a panic, a grow, a wait) calls that function, which a
   function-like macro does not expand inside its own body. cgen appends this text after
   the runtime declarations (`unit_header`); tcc units and the runtime unit itself call
   the functions, and so does a build with -DLUST_NO_INL (for A/B timing). */
#if !defined(__TINYC__) && !defined(LUST_IMPL) && !defined(LUST_NO_INL)
/* lust's atomic ordering (0 Relaxed, 1 Release, 2 Acquire, 3 AcqRel, 4 SeqCst) as a C
   memory order, as sync.c LUST_MO. A load's Release and AcqRel orders panic: the
   function does that. */
#define lust_inl_mo_(o) ((o) == 0 ? __ATOMIC_RELAXED : (o) == 1 ? __ATOMIC_RELEASE : (o) == 2 ? __ATOMIC_ACQUIRE : (o) == 3 ? __ATOMIC_ACQ_REL : __ATOMIC_SEQ_CST)
#define lust_inl_load_(N, U, p, o, loc)                                                                     \
    __extension__({                                                                                         \
        U *lust_p_ = (p);                                                                                   \
        uint32_t lust_o_ = (o);                                                                             \
        __builtin_expect(lust_o_ == 1 || lust_o_ == 3, 0) ? lust_at_load_##N(lust_p_, lust_o_, (loc))      \
                                                          : __atomic_load_n(lust_p_, lust_inl_mo_(lust_o_)); \
    })
#define lust_at_load_1(p, o, loc) lust_inl_load_(1, uint8_t, p, o, loc)
#define lust_at_load_2(p, o, loc) lust_inl_load_(2, uint16_t, p, o, loc)
#define lust_at_load_4(p, o, loc) lust_inl_load_(4, uint32_t, p, o, loc)
#define lust_at_load_8(p, o, loc) lust_inl_load_(8, uint64_t, p, o, loc)

/* A Once is set when its state is 2 (sync.c): no compare-exchange, no wait. */
#define lust_once_is_done(st) (__atomic_load_n((st), __ATOMIC_ACQUIRE) == 2)
#define lust_once_begin(st)                                                                         \
    __extension__({                                                                                 \
        uint32_t *lust_st_ = (st);                                                                  \
        __builtin_expect(__atomic_load_n(lust_st_, __ATOMIC_ACQUIRE) == 2, 1) ? 0 : lust_once_begin(lust_st_); \
    })

#define lust_leading_zeros64(v, bits)                                                                  \
    __extension__({                                                                                    \
        uint64_t lust_v_ = (v);                                                                        \
        unsigned lust_b_ = (bits);                                                                     \
        lust_v_ ? (uint32_t)(__builtin_clzll(lust_v_) - (64 - lust_b_)) : (uint32_t)lust_b_;           \
    })

/* A slice range in bounds; the function panics in Rust's order otherwise. */
#define lust_slice_range(lo, hi, inclusive, len, loc)                                                  \
    __extension__({                                                                                    \
        uint64_t lust_lo_ = (lo), lust_hi_ = (hi), lust_len_ = (len);                                  \
        int lust_inc_ = (inclusive);                                                                   \
        uint64_t lust_end_ = lust_inc_ ? lust_hi_ + 1 : lust_hi_;                                      \
        __builtin_expect(lust_lo_ <= lust_len_ && (lust_inc_ ? lust_hi_ < lust_len_ : lust_hi_ <= lust_len_) && lust_lo_ <= lust_end_, 1) \
            ? lust_end_                                                                                \
            : lust_slice_range(lust_lo_, lust_hi_, lust_inc_, lust_len_, (loc));                       \
    })

#define lust_div_u64(a, b, loc) \
    __extension__({ uint64_t lust_a_ = (a), lust_d_ = (b); __builtin_expect(lust_d_ != 0, 1) ? lust_a_ / lust_d_ : lust_div_u64(lust_a_, lust_d_, (loc)); })
#define lust_rem_u64(a, b, loc) \
    __extension__({ uint64_t lust_a_ = (a), lust_d_ = (b); __builtin_expect(lust_d_ != 0, 1) ? lust_a_ % lust_d_ : lust_rem_u64(lust_a_, lust_d_, (loc)); })
#define lust_div_i64(a, b, loc)                                                                         \
    __extension__({                                                                                     \
        int64_t lust_a_ = (a), lust_d_ = (b);                                                           \
        __builtin_expect(lust_d_ != 0 && !(lust_a_ == INT64_MIN && lust_d_ == -1), 1) ? lust_a_ / lust_d_ : lust_div_i64(lust_a_, lust_d_, (loc)); \
    })
#define lust_rem_i64(a, b, loc)                                                                         \
    __extension__({                                                                                     \
        int64_t lust_a_ = (a), lust_d_ = (b);                                                           \
        __builtin_expect(lust_d_ != 0 && !(lust_a_ == INT64_MIN && lust_d_ == -1), 1) ? lust_a_ % lust_d_ : lust_rem_i64(lust_a_, lust_d_, (loc)); \
    })

/* The C compiler's own memcpy and memmove: a small constant copy (a from_le_bytes, a
   moved value) becomes loads and stores instead of two calls. A macro whose arguments
   may be compound literals (`&(T){a, b}`, `(lust_u128){lo, hi}`: the comma in the braces
   splits a macro argument list) takes `...`; one that names them binds them with a
   struct initializer. */
#define lust_memcpy(...) ((void)__builtin_memcpy(__VA_ARGS__))
#define lust_memmove(...) ((void)__builtin_memmove(__VA_ARGS__))

/* A push or reserve that fits the capacity; growth (and zero-sized elements) take the
   function. A reserve_exact on an empty Vec (most of them: the first buffer of a collect or
   an extend) is one malloc here, as the function would do it: the element size is the call
   site's constant, so the size check (lust_vec_fits) folds. Any other case (an alignment
   over 16, an overflow, a failed malloc) is one call of the function. */
#define lust_vec_reserve_exact(v, extra, elem, align)                                                  \
    __extension__({                                                                                    \
        lust_Vec *lust_rv_ = (v);                                                                      \
        uint64_t lust_rx_ = (extra), lust_re_ = (elem), lust_ra_ = (align);                            \
        void *lust_rp_;                                                                                \
        if (lust_re_ == 0 || lust_rv_->cap - lust_rv_->len < lust_rx_) {                               \
            if (lust_re_ != 0 && lust_rv_->cap == 0 && lust_ra_ <= 16 && lust_vec_fits(lust_rx_, lust_re_) \
                && (lust_rp_ = __builtin_malloc(lust_rx_ * lust_re_)) != 0) {                          \
                lust_rv_->ptr = lust_rp_;                                                              \
                lust_rv_->cap = lust_rx_;                                                              \
            } else {                                                                                   \
                lust_vec_reserve_exact(lust_rv_, lust_rx_, lust_re_, lust_ra_);                        \
            }                                                                                          \
        }                                                                                              \
        (void)0;                                                                                       \
    })
#define lust_vec_push_slot(v, elem, align)                                                             \
    __extension__({                                                                                    \
        lust_Vec *lust_v_ = (v);                                                                       \
        uint64_t lust_e_ = (elem);                                                                     \
        __builtin_expect(lust_e_ != 0 && lust_v_->len < lust_v_->cap, 1)                              \
            ? (void *)((char *)lust_v_->ptr + (lust_v_->len++) * lust_e_)                              \
            : lust_vec_push_slot(lust_v_, lust_e_, (align));                                           \
    })
#define lust_vec_reserve(v, extra, elem, align)                                                        \
    __extension__({                                                                                    \
        lust_Vec *lust_v_ = (v);                                                                       \
        uint64_t lust_x_ = (extra), lust_e_ = (elem);                                                  \
        if (!__builtin_expect(lust_e_ != 0 && lust_v_->cap - lust_v_->len >= lust_x_, 1))             \
            lust_vec_reserve(lust_v_, lust_x_, lust_e_, (align));                                      \
        (void)0;                                                                                       \
    })
/* Atomic stores, swaps, compare-exchanges and fetch ops: the orders that panic take
   the function, as the narrow loads above. */
#define lust_inl_mo_cas_(s, f) (((f) == 4) ? __ATOMIC_SEQ_CST : ((f) == 2 && ((s) == 0 || (s) == 1)) ? ((s) == 0 ? __ATOMIC_ACQUIRE : __ATOMIC_ACQ_REL) : lust_inl_mo_(s))
#define lust_inl_store_(N, U, p, v, o, loc)                                                             \
    __extension__({                                                                                     \
        U *lust_p_ = (p);                                                                               \
        U lust_v_ = (v);                                                                                \
        uint32_t lust_o_ = (o);                                                                         \
        if (__builtin_expect(lust_o_ == 2 || lust_o_ == 3, 0)) lust_at_store_##N(lust_p_, lust_v_, lust_o_, (loc)); \
        else __atomic_store_n(lust_p_, lust_v_, lust_inl_mo_(lust_o_));                                 \
        (void)0;                                                                                        \
    })
#define lust_at_store_1(p, v, o, loc) lust_inl_store_(1, uint8_t, p, v, o, loc)
#define lust_at_store_2(p, v, o, loc) lust_inl_store_(2, uint16_t, p, v, o, loc)
#define lust_at_store_4(p, v, o, loc) lust_inl_store_(4, uint32_t, p, v, o, loc)
#define lust_at_store_8(p, v, o, loc) lust_inl_store_(8, uint64_t, p, v, o, loc)
#define lust_inl_cas_(N, U, p, cur, nv, s, f, old, weak)                                                \
    __extension__({                                                                                     \
        U *lust_p_ = (p);                                                                               \
        U lust_c_ = (cur), lust_n_ = (nv);                                                              \
        uint32_t lust_s_ = (s), lust_f_ = (f);                                                          \
        U *lust_old_ = (old);                                                                           \
        int lust_w_ = (weak), lust_ok_;                                                                 \
        if (__builtin_expect(lust_f_ == 1 || lust_f_ == 3, 0)) {                                        \
            lust_ok_ = lust_at_cas_##N(lust_p_, lust_c_, lust_n_, lust_s_, lust_f_, lust_old_, lust_w_); \
        } else {                                                                                        \
            U lust_e_ = lust_c_;                                                                        \
            lust_ok_ = __atomic_compare_exchange_n(lust_p_, &lust_e_, lust_n_, 0, lust_inl_mo_cas_(lust_s_, lust_f_), lust_inl_mo_(lust_f_)); \
            *lust_old_ = lust_e_;                                                                       \
        }                                                                                               \
        lust_ok_;                                                                                       \
    })
#define lust_at_cas_1(p, c, n, s, f, o, w) lust_inl_cas_(1, uint8_t, p, c, n, s, f, o, w)
#define lust_at_cas_2(p, c, n, s, f, o, w) lust_inl_cas_(2, uint16_t, p, c, n, s, f, o, w)
#define lust_at_cas_4(p, c, n, s, f, o, w) lust_inl_cas_(4, uint32_t, p, c, n, s, f, o, w)
#define lust_at_cas_8(p, c, n, s, f, o, w) lust_inl_cas_(8, uint64_t, p, c, n, s, f, o, w)
#define lust_at_swap_1(p, v, o) __atomic_exchange_n((p), (v), lust_inl_mo_(o))
#define lust_at_swap_2(p, v, o) __atomic_exchange_n((p), (v), lust_inl_mo_(o))
#define lust_at_swap_4(p, v, o) __atomic_exchange_n((p), (v), lust_inl_mo_(o))
#define lust_at_swap_8(p, v, o) __atomic_exchange_n((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_add_1(p, v, o) __atomic_fetch_add((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_add_2(p, v, o) __atomic_fetch_add((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_add_4(p, v, o) __atomic_fetch_add((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_add_8(p, v, o) __atomic_fetch_add((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_sub_1(p, v, o) __atomic_fetch_sub((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_sub_2(p, v, o) __atomic_fetch_sub((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_sub_4(p, v, o) __atomic_fetch_sub((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_sub_8(p, v, o) __atomic_fetch_sub((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_and_1(p, v, o) __atomic_fetch_and((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_and_2(p, v, o) __atomic_fetch_and((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_and_4(p, v, o) __atomic_fetch_and((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_and_8(p, v, o) __atomic_fetch_and((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_or_1(p, v, o) __atomic_fetch_or((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_or_2(p, v, o) __atomic_fetch_or((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_or_4(p, v, o) __atomic_fetch_or((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_or_8(p, v, o) __atomic_fetch_or((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_xor_1(p, v, o) __atomic_fetch_xor((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_xor_2(p, v, o) __atomic_fetch_xor((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_xor_4(p, v, o) __atomic_fetch_xor((p), (v), lust_inl_mo_(o))
#define lust_at_fetch_xor_8(p, v, o) __atomic_fetch_xor((p), (v), lust_inl_mo_(o))

/* Bit counts with the compiler's builtins (the runtime loops for tcc; same results). */
#define lust_count_ones64(v) ((uint32_t)__builtin_popcountll((uint64_t)(v)))
#define lust_trailing_zeros64(v, bits)                                                                 \
    __extension__({                                                                                    \
        uint64_t lust_v_ = (v);                                                                        \
        uint32_t lust_b_ = (bits), lust_n_ = lust_v_ ? (uint32_t)__builtin_ctzll(lust_v_) : lust_b_;   \
        lust_n_ < lust_b_ ? lust_n_ : lust_b_;                                                         \
    })

/* Narrow division and remainder: zero (and MIN / -1) take the function, which panics. */
#define lust_inl_divu_(T, N, op, a, b, loc) \
    __extension__({ T lust_a_ = (a), lust_d_ = (b); __builtin_expect(lust_d_ != 0, 1) ? (T)(lust_a_ op lust_d_) : N(lust_a_, lust_d_, (loc)); })
#define lust_inl_divs_(T, MINV, N, op, a, b, loc)                                                       \
    __extension__({                                                                                     \
        T lust_a_ = (a), lust_d_ = (b);                                                                 \
        __builtin_expect(lust_d_ != 0 && !(lust_a_ == (MINV) && lust_d_ == -1), 1) ? (T)(lust_a_ op lust_d_) : N(lust_a_, lust_d_, (loc)); \
    })
#define lust_div_u8(a, b, loc) lust_inl_divu_(uint8_t, lust_div_u8, /, a, b, loc)
#define lust_rem_u8(a, b, loc) lust_inl_divu_(uint8_t, lust_rem_u8, %, a, b, loc)
#define lust_div_u16(a, b, loc) lust_inl_divu_(uint16_t, lust_div_u16, /, a, b, loc)
#define lust_rem_u16(a, b, loc) lust_inl_divu_(uint16_t, lust_rem_u16, %, a, b, loc)
#define lust_div_u32(a, b, loc) lust_inl_divu_(uint32_t, lust_div_u32, /, a, b, loc)
#define lust_rem_u32(a, b, loc) lust_inl_divu_(uint32_t, lust_rem_u32, %, a, b, loc)
#define lust_div_i8(a, b, loc) lust_inl_divs_(int8_t, -128, lust_div_i8, /, a, b, loc)
#define lust_rem_i8(a, b, loc) lust_inl_divs_(int8_t, -128, lust_rem_i8, %, a, b, loc)
#define lust_div_i16(a, b, loc) lust_inl_divs_(int16_t, -32768, lust_div_i16, /, a, b, loc)
#define lust_rem_i16(a, b, loc) lust_inl_divs_(int16_t, -32768, lust_rem_i16, %, a, b, loc)
#define lust_div_i32(a, b, loc) lust_inl_divs_(int32_t, -2147483647 - 1, lust_div_i32, /, a, b, loc)
#define lust_rem_i32(a, b, loc) lust_inl_divs_(int32_t, -2147483647 - 1, lust_rem_i32, %, a, b, loc)

/* An uncontended Mutex lock or unlock: one compare-exchange; a contended one (a waiter to
   wake, a wait) takes the function. */
#define lust_mutex_lock(st)                                                                             \
    __extension__({                                                                                     \
        uint32_t *lust_st_ = (st), lust_z_ = 0;                                                         \
        if (!__builtin_expect(__atomic_compare_exchange_n(lust_st_, &lust_z_, 1, 0, __ATOMIC_ACQUIRE, __ATOMIC_RELAXED), 1)) \
            lust_mutex_lock(lust_st_);                                                                  \
        (void)0;                                                                                        \
    })
#define lust_mutex_unlock(st)                                                                           \
    __extension__({                                                                                     \
        uint32_t *lust_st_ = (st), lust_one_ = 1;                                                       \
        if (!__builtin_expect(__atomic_compare_exchange_n(lust_st_, &lust_one_, 0, 0, __ATOMIC_RELEASE, __ATOMIC_RELAXED), 1)) \
            lust_mutex_unlock(lust_st_);                                                                \
        (void)0;                                                                                        \
    })

/* An empty Vec with no allocation (its dangling pointer is the alignment). */
#define lust_vec_with_capacity(n, elem, align)                                                         \
    __extension__({                                                                                    \
        uint64_t lust_n_ = (n), lust_e_ = (elem), lust_al_ = (align);                                  \
        __builtin_expect(lust_n_ == 0 && lust_e_ != 0, 1)                                              \
            ? (lust_Vec){(void *)(uintptr_t)(lust_al_ ? lust_al_ : 1), 0, 0}                           \
            : lust_vec_with_capacity(lust_n_, lust_e_, lust_al_);                                      \
    })

/* A str slice range in bounds with both ends on char boundaries; the function panics in
   Rust's order otherwise. */
#define lust_str_range(ptr, lo, hi, inclusive, len, loc)                                               \
    __extension__({                                                                                    \
        const uint8_t *lust_sp_ = (ptr);                                                               \
        uint64_t lust_lo_ = (lo), lust_hi_ = (hi), lust_len_ = (len);                                  \
        int lust_inc_ = (inclusive);                                                                   \
        uint64_t lust_end_ = lust_inc_ && lust_hi_ < lust_len_ ? lust_hi_ + 1 : lust_hi_;              \
        __builtin_expect(lust_lo_ <= lust_end_ && lust_end_ <= lust_len_ && !(lust_inc_ && lust_hi_ == lust_len_) \
                             && (lust_lo_ == lust_len_ || (lust_sp_[lust_lo_] & 0xC0) != 0x80)        \
                             && (lust_end_ == lust_len_ || (lust_sp_[lust_end_] & 0xC0) != 0x80), 1)  \
            ? lust_end_                                                                                \
            : lust_str_range(lust_sp_, lust_lo_, lust_hi_, lust_inc_, lust_len_, (loc));               \
    })

#define lust_string_as_str(s) __extension__({ lust_String *lust_s_ = (s); (lust_str){lust_s_->ptr, lust_s_->len}; })
#define lust_str_eq(...)                                                                               \
    __extension__({                                                                                    \
        struct { lust_str a, b; } lust_x_ = {__VA_ARGS__};                                             \
        (uint8_t)(lust_x_.a.len == lust_x_.b.len                                                       \
                  && (lust_x_.a.len == 0 || __builtin_memcmp(lust_x_.a.ptr, lust_x_.b.ptr, lust_x_.a.len) == 0)); \
    })

/* A thread-local's cell once the thread made it: thread.c's lust_tls_fast holds the cell
   pointers of the slots below LUST_TLS_FAST (one indexed thread-local load); a slot past it,
   or a cell this thread has not made yet, takes the function. */
extern __thread void *lust_tls_fast[];
#define lust_tls_cell(key, size, align)                                                                \
    __extension__({                                                                                    \
        uint64_t *lust_k_ = (key), lust_s_ = *lust_k_;                                                 \
        void *lust_c_ = __builtin_expect(lust_s_ < LUST_TLS_FAST, 1) ? lust_tls_fast[lust_s_] : (void *)0; \
        __builtin_expect(lust_c_ != 0, 1) ? lust_c_ : lust_tls_cell(lust_k_, (size), (align));         \
    })

/* Checked add, sub and mul of 64-bit and narrower integers (op 0, 1, 2) with the
   compiler's overflow builtins; division and 128 bits take the function. As the
   function: the wrapped result, masked to `bits`, goes to *out; 1 when it fits. */
#define lust_checked_op(a, b, bits, is_signed, op, out)                                                \
    __extension__({                                                                                    \
        uint64_t lust_a_ = (a), lust_b_ = (b), *lust_o_ = (out);                                       \
        unsigned lust_n_ = (bits);                                                                     \
        int lust_sg_ = (is_signed), lust_op_ = (op), lust_ok_;                                         \
        if (lust_n_ == 64 && lust_op_ <= 2 && lust_sg_) {                                              \
            int64_t lust_r_, lust_x_ = (int64_t)lust_a_, lust_y_ = (int64_t)lust_b_;                   \
            lust_ok_ = !(lust_op_ == 0   ? __builtin_add_overflow(lust_x_, lust_y_, &lust_r_)           \
                         : lust_op_ == 1 ? __builtin_sub_overflow(lust_x_, lust_y_, &lust_r_)           \
                                         : __builtin_mul_overflow(lust_x_, lust_y_, &lust_r_));         \
            *lust_o_ = (uint64_t)lust_r_;                                                              \
        } else if (lust_n_ == 64 && lust_op_ <= 2) {                                                   \
            uint64_t lust_r_;                                                                          \
            lust_ok_ = !(lust_op_ == 0   ? __builtin_add_overflow(lust_a_, lust_b_, &lust_r_)           \
                         : lust_op_ == 1 ? __builtin_sub_overflow(lust_a_, lust_b_, &lust_r_)           \
                                         : __builtin_mul_overflow(lust_a_, lust_b_, &lust_r_));         \
            *lust_o_ = lust_r_;                                                                        \
        } else if (lust_n_ <= 32 && lust_op_ <= 2) {                                                   \
            /* Exact in 64 bits: the result fits when it is in the type's range. */                   \
            uint64_t lust_m_ = (1ull << lust_n_) - 1ull;                                               \
            lust_a_ &= lust_m_;                                                                        \
            lust_b_ &= lust_m_;                                                                        \
            if (lust_sg_) {                                                                            \
                uint64_t lust_h_ = 1ull << (lust_n_ - 1);                                              \
                int64_t lust_x_ = (int64_t)((lust_a_ ^ lust_h_) - lust_h_), lust_y_ = (int64_t)((lust_b_ ^ lust_h_) - lust_h_); \
                int64_t lust_r_ = lust_op_ == 0 ? lust_x_ + lust_y_ : lust_op_ == 1 ? lust_x_ - lust_y_ : lust_x_ * lust_y_; \
                *lust_o_ = (uint64_t)lust_r_ & lust_m_;                                                \
                lust_ok_ = lust_r_ >= -(int64_t)lust_h_ && lust_r_ < (int64_t)lust_h_;                 \
            } else {                                                                                   \
                uint64_t lust_r_ = lust_op_ == 0 ? lust_a_ + lust_b_ : lust_op_ == 1 ? lust_a_ - lust_b_ : lust_a_ * lust_b_; \
                *lust_o_ = lust_r_ & lust_m_;                                                          \
                lust_ok_ = lust_op_ == 1 ? lust_a_ >= lust_b_ : lust_r_ <= lust_m_;                    \
            }                                                                                          \
        } else                                                                                         \
            lust_ok_ = lust_checked_op(lust_a_, lust_b_, lust_n_, lust_sg_, lust_op_, lust_o_);         \
        lust_ok_;                                                                                      \
    })

#ifdef __SIZEOF_INT128__
/* 128-bit compares, products and shifts with the compiler's __int128 (the functions
   build them from 64-bit halves). A shift of 128 or more takes the function. */
#define lust_inl_w_(x) (((unsigned __int128)(x).hi << 64) | (x).lo)
#define lust_inl_u128_of_(v)                                                                           \
    __extension__({                                                                                    \
        unsigned __int128 lust_w_ = (v);                                                               \
        (lust_u128){(uint64_t)lust_w_, (uint64_t)(lust_w_ >> 64)};                                     \
    })
#define lust_u128_cmp(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_u128 a, b; } lust_x_ = {__VA_ARGS__};                                            \
        unsigned __int128 lust_l_ = lust_inl_w_(lust_x_.a), lust_r_ = lust_inl_w_(lust_x_.b);          \
        (int32_t)((lust_l_ > lust_r_) - (lust_l_ < lust_r_));                                          \
    })
#define lust_i128_cmp(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_i128 a, b; } lust_x_ = {__VA_ARGS__};                                            \
        __int128 lust_l_ = (__int128)lust_inl_w_(lust_x_.a), lust_r_ = (__int128)lust_inl_w_(lust_x_.b); \
        (int32_t)((lust_l_ > lust_r_) - (lust_l_ < lust_r_));                                          \
    })
#define lust_u128_mul(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_u128 a, b; } lust_x_ = {__VA_ARGS__};                                            \
        lust_inl_u128_of_(lust_inl_w_(lust_x_.a) * lust_inl_w_(lust_x_.b));                            \
    })
#define lust_i128_mul(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_i128 a, b; } lust_x_ = {__VA_ARGS__};                                            \
        lust_u128 lust_p_ = lust_inl_u128_of_(lust_inl_w_(lust_x_.a) * lust_inl_w_(lust_x_.b));        \
        (lust_i128){lust_p_.lo, lust_p_.hi};                                                           \
    })
#define lust_u128_shl(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_u128 a; uint32_t n; } lust_x_ = {__VA_ARGS__};                                   \
        __builtin_expect(lust_x_.n < 128, 1) ? lust_inl_u128_of_(lust_inl_w_(lust_x_.a) << lust_x_.n)  \
                                             : lust_u128_shl(lust_x_.a, lust_x_.n);                    \
    })
#define lust_u128_shr(...)                                                                             \
    __extension__({                                                                                    \
        struct { lust_u128 a; uint32_t n; } lust_x_ = {__VA_ARGS__};                                   \
        __builtin_expect(lust_x_.n < 128, 1) ? lust_inl_u128_of_(lust_inl_w_(lust_x_.a) >> lust_x_.n)  \
                                             : lust_u128_shr(lust_x_.a, lust_x_.n);                    \
    })
/* Wrapping 128-bit add and sub, and the bitwise ops. */
#define lust_inl_u128_op_(T, op, ...)                                                                  \
    __extension__({                                                                                    \
        struct { T a, b; } lust_x_ = {__VA_ARGS__};                                                    \
        lust_u128 lust_r_ = lust_inl_u128_of_(lust_inl_w_(lust_x_.a) op lust_inl_w_(lust_x_.b));       \
        (T){lust_r_.lo, lust_r_.hi};                                                                   \
    })
#define lust_u128_add(...) lust_inl_u128_op_(lust_u128, +, __VA_ARGS__)
#define lust_u128_sub(...) lust_inl_u128_op_(lust_u128, -, __VA_ARGS__)
#define lust_i128_add(...) lust_inl_u128_op_(lust_i128, +, __VA_ARGS__)
#define lust_i128_sub(...) lust_inl_u128_op_(lust_i128, -, __VA_ARGS__)
#define lust_u128_and(...) lust_inl_u128_op_(lust_u128, &, __VA_ARGS__)
#define lust_u128_or(...) lust_inl_u128_op_(lust_u128, |, __VA_ARGS__)
#define lust_u128_xor(...) lust_inl_u128_op_(lust_u128, ^, __VA_ARGS__)
#endif

/* Small helpers that every unit called out of line: on tsgo's pgo-train they ran 200 M
   calls of 2 to 40 instructions each. Each keeps its function's arguments and result;
   a panic or a slow case calls the function. */

/* A hash table's item count and capacity (hash.c). */
#define lust_hash_len(t) __extension__({ const lust_hash_table *lust_t_ = (t); lust_t_->items; })
#define lust_hash_capacity(t) __extension__({ const lust_hash_table *lust_t_ = (t); lust_t_->items + lust_t_->growth_left; })
#define lust_hash_is_empty(t) __extension__({ const lust_hash_table *lust_t_ = (t); (int)(lust_t_->items == 0); })
/* The empty table with no allocation, as the function makes it. */
#define lust_hash_init(t, size, align)                                                                 \
    __extension__({                                                                                    \
        lust_hash_table *lust_t_ = (t);                                                                \
        uint64_t lust_al_ = (align);                                                                   \
        lust_t_->elem_size = (size);                                                                   \
        lust_t_->elem_align = lust_al_ ? lust_al_ : 1;                                                 \
        lust_t_->ctrl = (uint8_t *)lust_hash_static_empty;                                             \
        lust_t_->data = 0;                                                                             \
        lust_t_->alloc_base = 0;                                                                       \
        lust_t_->bucket_mask = 0;                                                                      \
        lust_t_->items = 0;                                                                            \
        lust_t_->growth_left = 0;                                                                      \
        (void)0;                                                                                       \
    })
/* A table with no allocation is the empty one: nothing to drop or free. */
#define lust_hash_drop_table(t, drop, ctx)                                                             \
    __extension__({                                                                                    \
        lust_hash_table *lust_t_ = (t);                                                                \
        if (!(lust_t_->alloc_base == 0 && lust_t_->items == 0)) lust_hash_drop_table(lust_t_, (drop), (ctx)); \
        (void)0;                                                                                       \
    })

/* An index in bounds is the result; the function panics with Rust's message otherwise. */
#define lust_bounds(i, len, loc)                                                                       \
    __extension__({                                                                                    \
        uint64_t lust_i_ = (i), lust_n_ = (len);                                                       \
        __builtin_expect(lust_i_ < lust_n_, 1) ? lust_i_ : lust_bounds(lust_i_, lust_n_, (loc));       \
    })
#define lust_vec_check_remove(v, i, loc)                                                               \
    __extension__({                                                                                    \
        lust_Vec *lust_v_ = (v);                                                                       \
        uint64_t lust_i_ = (i);                                                                        \
        if (__builtin_expect(lust_i_ >= lust_v_->len, 0)) lust_vec_check_remove(lust_v_, lust_i_, (loc)); \
        (void)0;                                                                                       \
    })

/* The char at *i of valid UTF-8, and *i moved past it: an ASCII byte here, a wider char
   in the function. */
#define lust_utf8_next(p, i)                                                                           \
    __extension__({                                                                                    \
        const uint8_t *lust_p_ = (p);                                                                  \
        uint64_t *lust_i_ = (i);                                                                       \
        uint8_t lust_b_ = lust_p_[*lust_i_];                                                           \
        __builtin_expect(lust_b_ < 0x80, 1) ? (*lust_i_ += 1, (uint32_t)lust_b_) : lust_utf8_next(lust_p_, lust_i_); \
    })
#define lust_chars(...) __extension__({ struct { lust_str s; } lust_x_ = {__VA_ARGS__}; (lust_Chars){lust_x_.s, 0}; })
#define lust_str_starts_with(...)                                                                      \
    __extension__({                                                                                    \
        struct { lust_str s, p; } lust_x_ = {__VA_ARGS__};                                             \
        (uint8_t)(lust_x_.p.len <= lust_x_.s.len                                                       \
                  && (lust_x_.p.len == 0 || __builtin_memcmp(lust_x_.s.ptr, lust_x_.p.ptr, lust_x_.p.len) == 0)); \
    })
#define lust_str_ends_with(...)                                                                        \
    __extension__({                                                                                    \
        struct { lust_str s, p; } lust_x_ = {__VA_ARGS__};                                             \
        (uint8_t)(lust_x_.p.len <= lust_x_.s.len                                                       \
                  && (lust_x_.p.len == 0                                                               \
                      || __builtin_memcmp(lust_x_.s.ptr + lust_x_.s.len - lust_x_.p.len, lust_x_.p.ptr, lust_x_.p.len) == 0)); \
    })

/* A range's start and end in a slice of `len` (`get(range)`), as core.c's function: the
   tags give each end's kind (end: 0 included, 1 excluded, 2 none; start: 0 included,
   1 excluded, 2 none); 0 when the range does not fit. */
static inline int lust_inl_range_bounds_get_(uint64_t len, uint64_t s_tag, uint64_t s_val, uint64_t e_tag, uint64_t e_val,
                                             uint64_t *out_s, uint64_t *out_e) {
    uint64_t end, start;
    if (e_tag == 0) {
        if (e_val >= len) return 0;
        end = e_val + 1;
    } else if (e_tag == 1) {
        if (e_val > len) return 0;
        end = e_val;
    } else {
        end = len;
    }
    if (s_tag == 2) {
        start = 0;
    } else if (s_tag == 1) {
        if (s_val >= end) return 0;
        start = s_val + 1;
    } else {
        if (s_val > end) return 0;
        start = s_val;
    }
    *out_s = start;
    *out_e = end;
    return 1;
}
#define lust_range_bounds_get(...) lust_inl_range_bounds_get_(__VA_ARGS__)

/* Allocation: malloc for a nonzero size at an alignment malloc gives; zero sizes, larger
   alignments and a failed malloc (the function retries, then reports it) take the
   function. (__builtin_malloc calls malloc; units declare no malloc of their own, and a
   program's own extern malloc may declare it with other types.) free for a nonzero size,
   but Windows' over-aligned blocks. */
#define lust_alloc(size, align)                                                                        \
    __extension__({                                                                                    \
        uint64_t lust_sz_ = (size), lust_al_ = (align);                                                \
        void *lust_r_ = __builtin_expect(lust_sz_ != 0 && lust_al_ <= 16, 1) ? __builtin_malloc(lust_sz_) : 0; \
        __builtin_expect(lust_r_ != 0, 1) ? lust_r_ : lust_alloc(lust_sz_, lust_al_);                  \
    })
#ifdef _WIN32
#define lust_inl_aligned_free_(align) ((align) > 16)
#else
#define lust_inl_aligned_free_(align) 0
#endif
#define lust_dealloc(ptr, size, align)                                                                 \
    __extension__({                                                                                    \
        void *lust_p_ = (ptr);                                                                         \
        uint64_t lust_sz_ = (size), lust_al_ = (align);                                                \
        if (lust_sz_) {                                                                                \
            if (lust_inl_aligned_free_(lust_al_)) lust_dealloc(lust_p_, lust_sz_, lust_al_);           \
            else free(lust_p_);                                                                        \
        }                                                                                              \
        (void)0;                                                                                       \
    })

/* Strings: the empty one, drop, and a push that fits the capacity (growth takes the
   function). */
#define lust_string_new() ((lust_String){(uint8_t *)(uintptr_t)1, 0, 0})
#define lust_string_drop(s) __extension__({ lust_String *lust_s_ = (s); lust_dealloc(lust_s_->ptr, lust_s_->cap, 1); })
#define lust_string_push_str(s, ...)                                                                   \
    __extension__({                                                                                    \
        lust_String *lust_s_ = (s);                                                                    \
        struct { lust_str x; } lust_x_ = {__VA_ARGS__};                                                \
        if (__builtin_expect(lust_s_->cap - lust_s_->len >= lust_x_.x.len, 1)) {                       \
            if (lust_x_.x.len) __builtin_memcpy(lust_s_->ptr + lust_s_->len, lust_x_.x.ptr, lust_x_.x.len); \
            lust_s_->len += lust_x_.x.len;                                                             \
        } else                                                                                         \
            lust_string_push_str(lust_s_, lust_x_.x);                                                  \
        (void)0;                                                                                       \
    })
#define lust_string_push_char(s, c)                                                                    \
    __extension__({                                                                                    \
        lust_String *lust_s_ = (s);                                                                    \
        uint32_t lust_c_ = (c);                                                                        \
        if (__builtin_expect(lust_c_ < 0x80 && lust_s_->len < lust_s_->cap, 1))                        \
            lust_s_->ptr[lust_s_->len++] = (uint8_t)lust_c_;                                           \
        else                                                                                           \
            lust_string_push_char(lust_s_, lust_c_);                                                   \
        (void)0;                                                                                       \
    })

/* f64 and f32 min and max as float.c: a NaN loses to a number, and of two equal values
   (0.0 and -0.0) the second wins. The integer to float casts round to nearest, ties to
   even, as Rust's `as` (the runtime builds them from integer steps for tcc). */
static inline double lust_inl_f64_min_(double a, double b) { return a < b ? a : b < a ? b : a == b ? b : a == a ? a : b; }
static inline double lust_inl_f64_max_(double a, double b) { return a > b ? a : b > a ? b : a == b ? b : a == a ? a : b; }
static inline float lust_inl_f32_min_(float a, float b) { return a < b ? a : b < a ? b : a == b ? b : a == a ? a : b; }
static inline float lust_inl_f32_max_(float a, float b) { return a > b ? a : b > a ? b : a == b ? b : a == a ? a : b; }
#define lust_f64_min(a, b) lust_inl_f64_min_((a), (b))
#define lust_f64_max(a, b) lust_inl_f64_max_((a), (b))
#define lust_f32_min(a, b) lust_inl_f32_min_((a), (b))
#define lust_f32_max(a, b) lust_inl_f32_max_((a), (b))
#define lust_u64_to_f64(v) ((double)(uint64_t)(v))
#define lust_i64_to_f64(v) ((double)(int64_t)(v))
#endif

/* `p` is a reference made just before (Rust's validity invariant: never null). cgen states
   it only on the path that makes the reference, never on a pointer that may be null: a slice
   element `&ptr[i]` inside its bounds check, the payload of a `Some(r)` the program builds.
   A later niche check of the `Option<&T>` (`p != 0`) then folds. tcc ignores it. */
#if !defined(__TINYC__)
#define lust_ref_nn(p)                       \
    do {                                     \
        if (!(p)) __builtin_unreachable();   \
    } while (0)
#else
#define lust_ref_nn(p) ((void)0)
#endif

/* A release fn's constant data named by its content (cgen/kconst.rs `kdata_def`): each unit
   that uses it defines it, and the link keeps one definition, so equal constants share one
   address program-wide with no run-time interning. clang's selectany is a comdat (weak_odr):
   its value folds into the code that reads it, as a constant's does (a compare with a
   promoted enum constant is a compare with an immediate). A plain weak definition (gcc)
   keeps the identity but not the folding. */
#if defined(_WIN32)
#define LUST_KDATA __declspec(selectany)
#elif defined(__clang__)
#define LUST_KDATA __attribute__((selectany, visibility("hidden")))
#else
#define LUST_KDATA __attribute__((weak, visibility("hidden")))
#endif
void lust_loc_init(void);
void lust_kstatics_init(void);
void f_a35b468395d48f17(void);
int main(int argc, char **argv) {
  lust_argc = argc;
  lust_argv = argv;
  lust_loc_init();
  lust_unw_init(1, 13625622651032530182ull, 11243205069349058834ull, 16423417153420772762ull, 17288151483163425319ull);
  lust_rt_init();
  lust_base_init();
  lust_kstatics_init();
  if (lust_main_entry_p) { int rc = lust_main_entry_p(); if (lust_unw_main_exit()) rc = 101; lust_tls_exit(); lust_flush(); return rc; }
  f_a35b468395d48f17();
  int rc = lust_unw_main_exit();
  lust_tls_exit();
  lust_flush();
  return rc;
}
