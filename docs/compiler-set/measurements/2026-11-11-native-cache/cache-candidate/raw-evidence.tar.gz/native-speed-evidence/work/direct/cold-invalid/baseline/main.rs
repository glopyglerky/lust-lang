fn main() { let value: u32 = "wrong"; println!("{}", value); }
