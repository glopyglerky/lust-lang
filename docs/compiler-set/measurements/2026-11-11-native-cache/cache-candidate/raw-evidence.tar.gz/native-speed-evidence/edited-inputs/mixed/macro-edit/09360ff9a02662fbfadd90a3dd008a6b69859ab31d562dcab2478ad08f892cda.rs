macro_rules! lustr_edit { ($value:expr) => { $value + 7 }; }
fn helper(value: i32) -> i32 {
    lustr_edit!(value * 7)
}

fn main() {
    println!("left={} right={} local={}", left::combine(10, 1), right::combine(10, 1), helper(3));
}
