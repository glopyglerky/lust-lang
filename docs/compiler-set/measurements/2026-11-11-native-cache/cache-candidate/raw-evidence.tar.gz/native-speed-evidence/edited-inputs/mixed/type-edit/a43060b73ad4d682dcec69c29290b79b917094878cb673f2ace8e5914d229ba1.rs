fn helper(value: i32) -> i32 {
    let values: [i32; 3] = [value * 7; 3]; values[0] + values.len() as i32
}

fn main() {
    println!("left={} right={} local={}", left::combine(10, 1), right::combine(10, 1), helper(3));
}
