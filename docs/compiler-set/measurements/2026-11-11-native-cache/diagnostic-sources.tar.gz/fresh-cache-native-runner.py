from pathlib import Path
import json,hashlib,subprocess,os,time,statistics,platform
root=Path('/workspace/scratch/92a35dfe3ee0/native-cache-experiments/fresh-cache-native');root.mkdir(exist_ok=False)
compilers={'baseline':Path('/workspace/scratch/92a35dfe3ee0/native-cache-experiments/baseline-native'),'candidate':Path('/workspace/scratch/92a35dfe3ee0/native-diagnostic-build/gate/lustr-native')}
repo=Path('/workspace/scratch/92a35dfe3ee0/lustr')
sources={'generics-traits':((repo/'tests/native-qualification/existing-generics-traits.rs').read_text(),'14\n'),'unsafe-scalar':('unsafe fn add(value: i32) -> i32 { value + 1 }\nfn main() { println!("{}", unsafe { add(41) }); }\n','42\n'),'unsafe-generic':('unsafe fn id<T>(value: T) -> T { value }\nfn main() { println!("{}", unsafe { id(42) }); }\n','42\n')}
n=16;functions=''.join(f'fn f{i}(x: i64) -> i64 {{ x + {i} }}\n' for i in range(n));calls=' + '.join(f'f{i}(1)' for i in range(n));sources['unsafe-many-functions']=(f'unsafe fn id(value: i64) -> i64 {{ value }}\n{functions}\nfn main() {{ println!("{{}}", unsafe {{ id({calls}) }}); }}\n','136\n')
report={'scope':'Diagnostic before/after, same opt1 ThinLTO-off gate profile, not release qualification or parity against Lust/rustc. Fresh-cache enabled runs create empty runtime temporary and LUST_CACHE_DIR directories before every compile; output and dep-info are also removed. Includes first admission/store overhead. Timings exclude program execution.','qualified':False,'host':platform.platform(),'compilers':{k:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in compilers.items()},'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'crates/lustr-native/src').glob('*.rs')},'series':{},'commands':[]}
baseenv={k:v for k,v in os.environ.items() if not k.startswith(('LUST_','LUSTR_'))}
for name,(source,expected) in sources.items():
 for mode in ('fresh-cache',):
  directories={};envs={}
  for lane in compilers:
   d=root/name/mode/lane;d.mkdir(parents=True);(d/'main.rs').write_text(source);(d/'tmp').mkdir();directories[lane]=d
   env=dict(baseenv,LUST_NO_DAEMON='1',LUST_CACHE_DIR=str(d/'cache'),TMPDIR=str(d/'tmp'))
   # Caching stays enabled; every timed sample starts with a new cache.
   envs[lane]=env
  samples=[]
  for sample in range(-1,12):
   row={'sample':sample}
   for lane in (('baseline','candidate') if sample%2==0 else ('candidate','baseline')):
    d=directories[lane];env=envs[lane].copy()
    for p in (d/'cache_probe',d/'cache_probe.d'):p.unlink(missing_ok=True)
    if mode=='fresh-cache':
     tmp=d/'tmp'/str(sample+1);tmp.mkdir();env['TMPDIR']=str(tmp)
     cache=d/('cache-'+str(sample+1));cache.mkdir();env['LUST_CACHE_DIR']=str(cache)
    cmd=[str(compilers[lane]),'--crate-name','cache_probe','--crate-type','bin','--edition=2024','--emit=link,dep-info','--out-dir',str(d),str(d/'main.rs')]
    start=time.perf_counter_ns();p=subprocess.run(cmd,env=env,capture_output=True);elapsed=time.perf_counter_ns()-start
    run=subprocess.run([d/'cache_probe'],env=env,capture_output=True) if p.returncode==0 else None
    correct=p.returncode==0 and run.returncode==0 and run.stdout.decode()==expected and (d/'cache_probe.d').is_file()
    record={'case':name,'mode':mode,'sample':sample,'lane':lane,'argv':cmd,'elapsed_ns':elapsed,'exit_code':p.returncode,'stderr':p.stderr.decode(),'runtime_output':run.stdout.decode() if run else None,'correct':correct,'runtime_tmp':env['TMPDIR'],'cache_dir':env['LUST_CACHE_DIR'],'cache_disabled':env.get('LUST_NO_CACHE'),'admission_count':len(list(Path(env['LUST_CACHE_DIR']).glob('req-native-*')))}
    report['commands'].append(record);row[lane]=elapsed
    if not correct: raise RuntimeError(record)
   if sample>=0:samples.append(row)
  summary={'samples':samples,'baseline_median_ms':statistics.median(r['baseline'] for r in samples)/1e6,'candidate_median_ms':statistics.median(r['candidate'] for r in samples)/1e6,'slower_pairs':sum(r['candidate']>r['baseline'] for r in samples),'candidate_markers':len(list(directories['candidate'].glob('cache-*/req-native-*')))}
  report['series'][name+'/'+mode]=summary
  print(json.dumps({'case':name,'mode':mode,**{k:v for k,v in summary.items() if k!='samples'}}),flush=True)
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
