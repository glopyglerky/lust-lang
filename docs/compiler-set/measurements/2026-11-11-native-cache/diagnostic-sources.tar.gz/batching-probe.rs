#![allow(dead_code)]
#[path="/workspace/scratch/92a35dfe3ee0/lustr/compiler/native/src/tcc.rs"] mod tcc;
mod pool {
    pub fn threads() -> usize { std::thread::available_parallelism().map_or(1, usize::from) }
    pub fn stop() {}
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    tcc::use_mimalloc();
    let root=std::path::Path::new(&args[2]);
    let out=std::path::Path::new(&args[3]);
    std::fs::create_dir_all(out).unwrap();
    let mut paths: Vec<_>=std::fs::read_dir(root).unwrap().map(|r|r.unwrap().path()).filter(|p|p.extension().is_some_and(|e|e=="c")).collect(); paths.sort();
    let units: Vec<_>=paths.iter().enumerate().map(|(i,p)|(out.join(format!("u{i}.o")),std::fs::read_to_string(p).unwrap())).collect();
    let start=std::time::Instant::now();
    if args[1]=="batch" { for pair in units.chunks(2) { tcc::compile_units(pair,false).unwrap(); } }
    else { tcc::compile_units(&units,false).unwrap(); }
    println!("{}",start.elapsed().as_nanos());
}
