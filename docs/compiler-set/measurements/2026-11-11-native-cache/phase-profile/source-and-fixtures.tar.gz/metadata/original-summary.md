# Native request-cache phase diagnostic

Instrumented commit `5b98ffb63da0139d778ef4a26de28b1d38fd4a0e` completed 210 compiler invocations and 210 runtime-output checks. Every compile also produced dep-info. This is an opt1 diagnostic, not a release performance qualification. The instrumented compiler deliberately retains the old cache namespace; the parent process fixed that namespace separately after reproducing its nested Cargo invocation.

Only Lustr-owned Rust files were instrumented. The protected upstream tree is unchanged. The binary records `Instant` durations in fixed atomic slots, then writes one JSON line after the measured compiler phases. Nested subphases are included in their enclosing phase and must not be added to it.

## First admission without a Cargo manifest

Twelve timed observations per fixture, plus retained preflight. The source files have no ancestor Cargo.toml. Cache directories, compiler outputs and runtime temporary files were placed in a new owned `/tmp` directory for each invocation because the workspace filesystem was nearly full. These storage conditions differ from the earlier workspace-based cold comparison.

| Fixture | Source bytes | Artifact bytes | Cache setup ms | Miss lookup ms | Store ms | Total cache work ms | Native compile ms |
|---|---:|---:|---:|---:|---:|---:|---:|
| generics-traits | 486 | 402820 | 0.115 | 0.006 | 0.663 | 0.795 | 49.132 |
| unsafe-scalar | 97 | 401124 | 0.106 | 0.006 | 1.499 | 1.608 | 51.305 |
| unsafe-generic | 90 | 400916 | 0.107 | 0.006 | 0.575 | 0.737 | 46.080 |
| unsafe-many-functions | 729 | 409300 | 0.113 | 0.006 | 0.632 | 0.797 | 55.302 |

Values are medians. Total cache work is calculated per invocation before taking its median, so it need not equal the sum of phase medians.

Cache setup took about 0.106–0.115 ms. Within setup, protocol encoding took 0.046–0.051 ms, executable identity and umask inspection 0.030–0.033 ms, Args formatting 0.010–0.013 ms, hashing about 0.007 ms, and cloning 0.005–0.008 ms. These costs do not justify attributing several milliseconds to argument formatting or environment cloning.

Store took 0.575–1.499 ms at the median. The opaque upstream store call accounted for 0.282–1.146 ms; reading the executable and its permissions took 0.119–0.177 ms; constructing integrity fingerprints took about 0.087–0.089 ms. Dependency admission checks and the postcompile source read/compare each stayed below 0.009 ms at the median. These correctness checks are not the dominant measured work.

All observations remain in report.json. The largest measured total cache work was 6.147 ms on unsafe-scalar. Its store phase reached 6.045 ms. No outlier was discarded.

## Reproduced manifest re-entry

A separate fixture contains Cargo.toml and build.rs. A logging Cargo shell sentinel exits 97, so no real Cargo check or build script executes. The old cache invokes that sentinel once during first store and again during a warm lookup.

| Request | Native compile ms | Lookup ms | Store ms | Upstream store ms | Nested Cargo calls |
|---|---:|---:|---:|---:|---:|
| First compile | 52.305 | 0.005 | 3.144 | 2.882 | 1 |
| Warm hit | 0.000 | 2.764 | 0.000 | 0.000 | 1 |

The sentinel durations are diagnostic process-entry costs, not estimates of a real Cargo build. The parent fixed the cache-only package namespace to start with `file:` and added a regression preventing Cargo/build-script re-entry. This profile does not measure the fixed binary.

## Interpretation and next decision

The added request-cache work is measurable and mostly in store. The earlier 4–8 ms median cold differences cannot be assigned entirely to setup or to the cache from this run: the storage layout changed, native compilation varied, and the instrumented/uninstrumented whole-process controls differed in both directions. Cold invocations with LUST_NO_CACHE also disable the pre-existing unit cache, so their whole-process difference includes more than this request cache.

The confirmed namespace correction is necessary regardless of speed. No additional production optimization follows from this profile. Release CI should measure the corrected compiler with caching enabled and empty per-lane caches. If store remains material there, a separate experiment can test avoiding redundant scans/copies while keeping source revalidation, artifact integrity, permissions, umask, runtime identity and complete request identity. The current public upstream cache API does not accept prevalidated dependency information or already-read executable bytes.

## Retained identities

- Instrumented binary SHA256: `8224917ba4e62fa1da6b733f862331c191e20b901ef810c2df8b13bd98045bf3`.
- Uninstrumented control SHA256: `734d50867257bfd1e1105e58ccaf482aa79560007af2069cc22c383cb14720fa`.
- Exact runner: `runner.py`; SHA256 `b82a896a3c6a6348d5a58d17ba10fefd91bafb94badc98f670e992f5cafd7ad7`.
- Full owned Rust source snapshot: `instrumented-source/`, with hashes in `manifest.json`.
- Tracked source changes: `instrumentation.patch`; the added profiling module is retained in the source snapshot.
- Every compiler stderr record is retained under `logs/`; raw observations and phase summaries are in `report.json`.
- The instrumented build took 2m 23s. Its copied build target was removed after retaining the binary.
