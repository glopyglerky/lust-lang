//! Diagnostic-only phase instrumentation. Never ship this module.
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Instant;
use std::fmt::Write;

const NAMES: [&str; 22] = ["compile_total","cli_setup","cache_prepare_total","lookup_total","session_setup","native_compile","artifact_depinfo","store_total","cleanup","output_reporting","prepare_encode","prepare_identity_umask","prepare_args","prepare_hash","prepare_clone","lookup_marker_read","store_admission","store_source_read_verify","store_artifact_read_mode","store_fingerprint","store_upstream","store_marker_publish"];
static TIMES: [AtomicU64; 22] = [const { AtomicU64::new(0) }; 22];
static COUNTS: [AtomicU64; 22] = [const { AtomicU64::new(0) }; 22];
pub fn record(slot: usize, start: Instant) {
    TIMES[slot].fetch_add(start.elapsed().as_nanos() as u64, Ordering::Relaxed);
    COUNTS[slot].fetch_add(1, Ordering::Relaxed);
}
pub fn finish() {
    let mut line = String::with_capacity(2048);
    line.push_str("LUSTR_CACHE_PHASES {");
    for (at, name) in NAMES.iter().enumerate() {
        if at != 0 { line.push(','); }
        write!(&mut line, "\"{}\":{{\"ns\":{},\"count\":{}}}", name,
               TIMES[at].load(Ordering::Relaxed), COUNTS[at].load(Ordering::Relaxed)).unwrap();
    }
    line.push('}');
    eprintln!("{line}");
}
