unsafe fn id(value: i64) -> i64 { value }
fn f0(x: i64) -> i64 { x + 0 }
fn f1(x: i64) -> i64 { x + 1 }
fn f2(x: i64) -> i64 { x + 2 }
fn f3(x: i64) -> i64 { x + 3 }
fn f4(x: i64) -> i64 { x + 4 }
fn f5(x: i64) -> i64 { x + 5 }
fn f6(x: i64) -> i64 { x + 6 }
fn f7(x: i64) -> i64 { x + 7 }
fn f8(x: i64) -> i64 { x + 8 }
fn f9(x: i64) -> i64 { x + 9 }
fn f10(x: i64) -> i64 { x + 10 }
fn f11(x: i64) -> i64 { x + 11 }
fn f12(x: i64) -> i64 { x + 12 }
fn f13(x: i64) -> i64 { x + 13 }
fn f14(x: i64) -> i64 { x + 14 }
fn f15(x: i64) -> i64 { x + 15 }

fn main() { println!("{}", unsafe { id(f0(1) + f1(1) + f2(1) + f3(1) + f4(1) + f5(1) + f6(1) + f7(1) + f8(1) + f9(1) + f10(1) + f11(1) + f12(1) + f13(1) + f14(1) + f15(1)) }); }
