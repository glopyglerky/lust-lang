unsafe fn id<T>(value: T) -> T { value }
fn main() { println!("{}", unsafe { id(42) }); }
